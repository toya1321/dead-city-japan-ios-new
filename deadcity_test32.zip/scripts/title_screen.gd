extends Control
const HouseholdDialogue = preload("res://scripts/household_dialogue.gd")
signal new_game_requested(profile: Dictionary)
signal continue_requested
var save_exists := false
var continue_button: Button
var message: Label
var form: VBoxContainer
var name_input: LineEdit
var age_input: SpinBox
var address_input: LineEdit
var job_input: OptionButton
var home_input: OptionButton
var people_input: SpinBox
var companion_names: Array[LineEdit] = []
var companion_genders: Array[OptionButton] = []
var companion_rows: Array[BoxContainer] = []
var seed_input: SpinBox
var form_scroll: ScrollContainer
var heading_label: Label
var subtitle_label: Label
var title_buttons: HBoxContainer
var last_keyboard := -1
var margin: MarginContainer
var confirmation: ConfirmationDialog
var pending_profile: Dictionary = {}
var form_rows: Array[BoxContainer] = []
var title_art: TextureRect
var layout_viewport := Vector2.ZERO
var layout_insets := Vector4i.ZERO

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = Color("#080f19")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	margin = MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation",12)
	margin.add_child(column)
	var title := Label.new()
	heading_label=title
	title.text = "DEAD CITY JAPAN  —  CHRONICLE"
	title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	title.add_theme_font_size_override("font_size",34)
	column.add_child(title)
	var subtitle := Label.new()
	subtitle_label=subtitle
	subtitle.text = "いつもの暮らしから、その先へ。   /   TEST 32"
	subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	subtitle.add_theme_font_size_override("font_size",22)
	column.add_child(subtitle)
	var row := HBoxContainer.new()
	title_buttons=row
	column.add_child(row)
	var start := _button("はじめから",row)
	start.pressed.connect(_open_form)
	var resume := _button("続きから",row)
	continue_button=resume
	resume.disabled = not save_exists
	resume.pressed.connect(func(): continue_requested.emit())
	title_art = TextureRect.new()
	title_art.texture = preload("res://assets/photos/bedroom.jpg")
	title_art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	title_art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	title_art.clip_contents = true
	title_art.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(title_art)
	var scroll := ScrollContainer.new()
	form_scroll=scroll
	scroll.hide()
	scroll.follow_focus=true
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	column.add_child(scroll)
	form = VBoxContainer.new()
	form.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	form.add_theme_constant_override("separation",8)
	scroll.add_child(form)
	form.visible = false
	name_input = _text_field("名前", "トウヤ")
	name_input.max_length = 24
	age_input = _number_field("年齢",31,1,100)
	address_input = _text_field("居住地", "東京都渋谷区笹塚")
	address_input.max_length = 60
	job_input = _choice("職業",["無職","会社員","自営業","学生"])
	home_input = _choice("住まい",["一戸建て","集合住宅"])
	people_input = _number_field("同居人の人数",0,0,3)
	for index in range(int(people_input.max_value)):
		var person_row := _row("同居人%d" % (index + 1))
		companion_rows.append(person_row)
		var fields := HBoxContainer.new()
		fields.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		person_row.add_child(fields)
		var name_field := LineEdit.new()
		name_field.placeholder_text = "名前"
		name_field.max_length = 24
		name_field.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_field.custom_minimum_size.y = 46
		fields.add_child(name_field)
		companion_names.append(name_field)
		var gender_field := OptionButton.new()
		for gender in HouseholdDialogue.GENDERS:
			gender_field.add_item("性別未設定" if gender == "未設定" else gender)
		gender_field.custom_minimum_size.y = 46
		fields.add_child(gender_field)
		companion_genders.append(gender_field)
	people_input.value_changed.connect(_show_companion_rows)
	_show_companion_rows(people_input.value)
	seed_input = _number_field("世界シード（同じ値なら同じ世界進行）",481516,1,999999999)
	var randomize := _button("別の世界シードにする",form)
	randomize.pressed.connect(func(): seed_input.value = randi_range(1,999999999))
	var begin := _button("この設定で始める",form)
	begin.pressed.connect(_request_start)
	message = Label.new()
	message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	message.add_theme_font_size_override("font_size",20)
	message.text = "ごく普通の日本の朝から始まります。" if not save_exists else "保存した記録から再開できます。"
	column.add_child(message)
	confirmation = ConfirmationDialog.new()
	confirmation.title = "新しいゲームを始めますか"
	confirmation.dialog_text = "次に保存したとき、以前のセーブを置き換えます。"
	confirmation.get_label().autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	confirmation.ok_button_text = "はじめから"
	confirmation.cancel_button_text = "キャンセル"
	confirmation.confirmed.connect(func(): new_game_requested.emit(pending_profile))
	add_child(confirmation)
	get_viewport().size_changed.connect(_layout)
	_layout()

func _button(text: String,parent: Node) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size.y = 48
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(b)
	return b
func _open_form() -> void:
	form.show()
	form_scroll.show()
	title_art.hide()
	message.text = "主人公と住まいを設定してください。"

func _row(label: String) -> BoxContainer:
	var row := BoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	form_rows.append(row)
	form.add_child(row)
	var l := Label.new()
	l.text = label
	l.custom_minimum_size.x = 270
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	row.add_child(l)
	return row
func _text_field(label: String, text: String) -> LineEdit:
	var row := _row(label)
	var input := LineEdit.new()
	input.text = text
	input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	input.custom_minimum_size.y = 46
	row.add_child(input)
	return input
func _number_field(label: String, value: int, lo: int, hi: int) -> SpinBox:
	var row := _row(label)
	var input := SpinBox.new()
	input.min_value = lo
	input.max_value = hi
	input.value = value
	input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	input.custom_minimum_size.y = 46
	row.add_child(input)
	return input
func _choice(label: String, values: Array) -> OptionButton:
	var row := _row(label)
	var input := OptionButton.new()
	for value in values: input.add_item(str(value))
	input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	input.custom_minimum_size.y = 46
	row.add_child(input)
	return input

func _show_companion_rows(count: float) -> void:
	for index in range(companion_rows.size()):
		companion_rows[index].visible = index < int(count)

func _request_start() -> void:
	var focused:=get_viewport().gui_get_focus_owner()
	if focused!=null:focused.release_focus()
	if DisplayServer.has_feature(DisplayServer.FEATURE_VIRTUAL_KEYBOARD):
		DisplayServer.virtual_keyboard_hide()
	var names: Array[String] = []
	var genders: Array[String] = []
	for index in range(int(people_input.value)):
		names.append(companion_names[index].text.strip_edges())
		genders.append(HouseholdDialogue.GENDERS[companion_genders[index].selected])
	pending_profile = {"name":name_input.text.strip_edges(),"age":int(age_input.value),"address":address_input.text.strip_edges(),"job":job_input.get_item_text(job_input.selected),"housing":home_input.get_item_text(home_input.selected),"cohabitants":int(people_input.value),"companion_names":names,"companion_genders":genders,"seed":int(seed_input.value),"has_key":true}
	if pending_profile.name.is_empty() or pending_profile.address.is_empty():
		message.text = "名前と居住地を入力してください。"
		return
	if save_exists:
		confirmation.popup_centered(Vector2i(mini(680, int(get_viewport_rect().size.x) - 32), 220))
	else:
		new_game_requested.emit(pending_profile)
func _layout() -> void:
	if margin == null:
		return
	var vp := get_viewport_rect().size
	var portrait := vp.x < vp.y
	var scale_factor := vp.x / maxf(1.0, float(DisplayServer.window_get_size().x))
	var insets := Vector4i(16, 14, 16, 14) if portrait else Vector4i(24, 20, 24, 20)
	if OS.has_feature("mobile"):
		var safe := DisplayServer.get_display_safe_area()
		var screen := DisplayServer.screen_get_size()
		if safe.has_area():
			insets.x = maxi(insets.x, ceili(safe.position.x * scale_factor) + 4)
			insets.y = maxi(insets.y, ceili(safe.position.y * scale_factor) + 4)
			insets.z = maxi(insets.z, ceili((screen.x - safe.end.x) * scale_factor) + 4)
			insets.w = maxi(insets.w, ceili((screen.y - safe.end.y) * scale_factor) + 4)
	var keyboard := 0
	if DisplayServer.has_feature(DisplayServer.FEATURE_VIRTUAL_KEYBOARD):
		keyboard = ceili(DisplayServer.virtual_keyboard_get_height() * scale_factor)
	if vp == layout_viewport and insets == layout_insets and keyboard == last_keyboard:
		return
	layout_viewport = vp
	layout_insets = insets
	last_keyboard = keyboard
	margin.add_theme_constant_override("margin_left", insets.x)
	margin.add_theme_constant_override("margin_top", insets.y)
	margin.add_theme_constant_override("margin_right", insets.z)
	margin.add_theme_constant_override("margin_bottom", maxi(insets.w, keyboard + 6 if keyboard > 0 else 0))
	subtitle_label.visible = keyboard == 0
	title_buttons.visible = keyboard == 0
	message.visible = keyboard == 0
	title_art.visible = keyboard == 0 and not form.visible
	title_art.custom_minimum_size.y = clampf(vp.y * 0.38, 110, 320)
	heading_label.text = "DEAD CITY JAPAN\nCHRONICLE" if portrait and keyboard == 0 else ("CHRONICLE" if keyboard > 0 else "DEAD CITY JAPAN  —  CHRONICLE")
	heading_label.add_theme_font_size_override("font_size", 21 if keyboard > 0 else (29 if portrait else 34))
	subtitle_label.add_theme_font_size_override("font_size", 16 if portrait else 22)
	for row in form_rows:
		row.vertical = portrait
		row.get_child(0).custom_minimum_size.x = 0 if portrait else 270
	if keyboard > 0:
		var focused := get_viewport().gui_get_focus_owner()
		if focused != null and form.is_ancestor_of(focused):
			form_scroll.call_deferred("ensure_control_visible", focused)

func _process(_delta: float) -> void:
	if OS.has_feature("mobile"):
		_layout()
