extends RefCounted

const Navigation = preload("res://scripts/navigation.gd")
const HISTORY_LIMIT = 6
const REPLY_LIMIT = 300
const END = ["会話を終える", "会話をやめる", "話を終える"]
const GENDERS = ["未設定", "男性", "女性", "その他"]
const OFFLINE_VOICE = {"男性":1, "女性":2}
const SPEECH_STYLES = {
	"男性": {"first_person":"僕", "description":"気取らない、簡潔な話し方。自然なら「〜だよ」「〜しようか」を使う。"},
	"女性": {"first_person":"私", "description":"柔らかく親しみやすい話し方。自然なら「〜だね」「〜しておこうね」を使う。"},
	"neutral": {"first_person":"私", "description":"くだけすぎない自然な日常会話。語尾に性別を強調する表現は使わない。"},
}
const OFFLINE_LINES = {
	"call": ["うん、聞こえたよ。どうしたの？", "呼んだ？ 僕に何か用？", "はーい、聞こえたよ。どうしたの？"],
	"water": ["飲み水は使う前に残りを見ておこう。", "使う前に残りを見ておこうか。", "使う前に、残りを一緒に見ておこうね。"],
	"food": ["次に何を食べるか、一緒に考えようか。", "次に何を食べるか考えようか。", "何を食べるか、一緒に考えようね。"],
	"condition": ["。そっちは大丈夫？", "よ。そっちはどう？", "かな。あなたは大丈夫？"],
	"unheard_news": ["新しいことはまだ聞いていないよ。分かったことがあったら教えて。", "僕はまだ聞いてないよ。何か分かった？", "私はまだ聞いてないな。何か分かったら教えてね。"],
	"news": ["報道は気になるね。何が分かったか教えてくれる？", "僕も気になるよ。何が分かった？", "私も気になってた。どんな話だった？"],
	"power_on": ["家の電気は使えているよ。", "まだ電気は使えるよ。", "うん、家の電気は使えてるね。"],
	"power_off": ["家の電気が使えないね。明かりが必要なら、手元の物を確認しよう。", "停電だね。手元に使える明かりがあるか見ようか。", "電気が使えないね。何か明かりがないか、一緒に見てみようか。"],
	"outside": ["出るつもりなら、どこへ行くか教えて。今ここからは、外の様子までは分からないよ。", "どこへ行くつもり？ ここからだと外の様子は分からないよ。", "出かけるなら、行き先を教えてね。ここからだと外の様子は分からないから。"],
	"greeting": ["うん、いるよ。今日はどうする？", "うん、僕はここにいるよ。今日はどうする？", "いるよ。今日はどうしようか？"],
	"thanks": ["ううん。何かあればまた声をかけて。", "うん。また何かあったら呼んでよ。", "ううん。またいつでも声をかけてね。"],
	"default": ["聞いてるよ。何が一番気になっているか、もう少し教えてくれる？", "聞いてるよ。もう少し詳しく話してくれる？", "うん、聞いてるよ。何が一番気になってるのかな？"],
}

var partner := -1
var history: Dictionary = {}

func parse(raw: String, members: Array) -> Dictionary:
	var text := raw.strip_edges().trim_suffix("。")
	var matches: Array[Dictionary] = []
	for index in range(members.size()):
		var name := str(members[index].name)
		var aliases := ["同居人%d" % (index + 1), name, name + "さん", name + "ちゃん", name + "くん"]
		for alias in aliases:
			if alias.is_empty():
				continue
			if text in [alias, alias + "！", alias + "!", alias + "を呼ぶ", alias + "を呼び出す", alias + "に声をかける", alias + "に話しかける", alias + "と話す"]:
				matches.append({"index": index, "speech": "", "alias": alias})
				break
			for prefix in [alias + "、", alias + "：", alias + ":", alias + "に「"]:
				if text.begins_with(prefix):
					var speech: String = text.trim_prefix(prefix).strip_edges()
					if prefix.ends_with("「"):
						speech = speech.get_slice("」", 0)
					matches.append({"index": index, "speech": speech.trim_prefix("「").trim_suffix("」"), "alias": alias})
					break
			if not matches.is_empty() and matches[-1].index == index:
				break
	if matches.size() == 1:
		return matches[0]
	if matches.size() > 1:
		return {"error":"同じ呼び名の同居人がいます。「同居人1」のように番号で呼んでください。"}
	for ending in ["に話しかける", "を呼び出す", "に声をかける", "を呼ぶ", "と話す"]:
		if text.ends_with(ending):
			return {"error":"「%s」という名前の同居人はいない。" % text.trim_suffix(ending)}
	return {}

func obstacle(world, place: String, person: Dictionary) -> String:
	var name := str(person.name)
	if float(world.s.health) <= 0:
		return "死亡しているため話せない。"
	if not Navigation.indoor(place):
		return "自宅で%sに声をかけられる。" % name
	if float(person.health) <= 0:
		return "%sから返事はない。" % name
	if person.activity == "外出":
		return "%sは外出中だ。家の中に呼びかけても返事はない。" % name
	if person.activity == "睡眠":
		return "%sは寝室で眠っている。返事はない。" % name
	if not Navigation.indoor(str(person.location)):
		return "%sはここから声が届く場所にいない。" % name
	return ""

func recent(index: int) -> Array:
	return history.get(str(index), [])

func remember(index: int, speech: String, reply: String) -> void:
	var turns := recent(index)
	turns.append({"player":speech, "reply":reply})
	if turns.size() > HISTORY_LIMIT:
		turns.pop_front()
	history[str(index)] = turns

static func valid_history(value: Variant, member_count: int) -> bool:
	if not value is Dictionary or value.size() > member_count:
		return false
	for key in value:
		if not key is String or key not in ["0", "1", "2"] or int(key) >= member_count:
			return false
		var turns = value[key]
		if not turns is Array or turns.size() > HISTORY_LIMIT:
			return false
		for turn in turns:
			if not turn is Dictionary or not turn.get("player") is String or not turn.get("reply") is String:
				return false
			if turn.player.length() > 1200 or turn.reply.length() > REPLY_LIMIT:
				return false
	return true

func context(world, place: String, index: int, heard_news: String, speech: String) -> Dictionary:
	var person: Dictionary = world.s.household_members[index]
	var gender := gender_for(world.s.profile, index)
	var style: Dictionary = SPEECH_STYLES.get(gender, SPEECH_STYLES.neutral)
	return {
		"name": person.name, "place": place, "time": world.clock(),
		"gender": gender, "first_person": style.first_person, "speaking_style": style.description,
		"condition": _condition(person), "water": _water(world), "food": _food(world),
		"power": "家の電気は使える" if world.has_home_power() else "家の電気が使えない",
		"reported_to_player": heard_news.left(500), "recent_dialogue": recent(index),
		"spoken_by_player": speech,
	}

func offline_reply(world, index: int, speech: String, heard_news: String) -> String:
	var person: Dictionary = world.s.household_members[index]
	var voice := int(OFFLINE_VOICE.get(gender_for(world.s.profile, index), 0))
	if speech.is_empty():
		return OFFLINE_LINES.call[voice]
	var topic := _topic(speech)
	if topic.is_empty() and (speech.contains("それ") or speech.contains("どうして") or speech.contains("あとどれくらい")):
		var turns := recent(index)
		for i in range(turns.size() - 1, -1, -1):
			topic = _topic(turns[i].player)
			if not topic.is_empty():
				break
	match topic:
		"water": return _water(world) + "。" + str(OFFLINE_LINES.water[voice])
		"food": return _food(world) + "。" + str(OFFLINE_LINES.food[voice])
		"condition": return _condition(person) + str(OFFLINE_LINES.condition[voice])
		"news":
			if heard_news in ["まだ確認していない", "新しい報道は確認できない。"]:
				return OFFLINE_LINES.unheard_news[voice]
			return OFFLINE_LINES.news[voice]
		"power":
			return OFFLINE_LINES.power_on[voice] if world.has_home_power() else OFFLINE_LINES.power_off[voice]
	return OFFLINE_LINES.get(topic, OFFLINE_LINES.default)[voice]

static func gender_for(profile: Dictionary, index: int) -> String:
	var genders: Array = profile.get("companion_genders", [])
	return str(genders[index]) if index >= 0 and index < genders.size() else "未設定"

static func _topic(speech: String) -> String:
	for entry in [
		["thanks", ["ありがとう", "助かった"]],
		["news", ["ニュース", "報道", "感染"]],
		["power", ["停電", "電気", "電力"]],
		["water", ["水", "喉"]],
		["food", ["食料", "ご飯", "食べ", "備蓄", "お腹"]],
		["condition", ["体調", "元気", "大丈夫", "疲れ"]],
		["outside", ["外出", "買い物", "出かけ", "外の"]],
		["greeting", ["おはよう", "こんばんは", "こんにちは"]],
	]:
		for word in entry[1]:
			if speech.contains(word):
				return entry[0]
	return ""

static func _condition(person: Dictionary) -> String:
	if float(person.health) < 70.0:
		return "少し具合が悪い"
	if float(person.thirst) >= 35.0:
		return "喉が渇いてきた"
	if float(person.hunger) >= 35.0:
		return "お腹が空いてきた"
	if float(person.fatigue) >= 65.0:
		return "少し疲れている"
	return "体調は今のところ大丈夫"

static func _water(world) -> String:
	return "家の飲料水は残り%.1fリットル。水道は%s" % [float(world.s.water), "使える" if world.tap_available() else "今は使えない"]

static func _food(world) -> String:
	return "家の食料は残り%.1f人日分" % float(world.s.food)
