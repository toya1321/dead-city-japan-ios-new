extends SceneTree

const Main = preload("res://main.tscn")
const Actions = preload("res://scripts/household_actions.gd")
const Errands = preload("res://scripts/household_errands.gd")
var failures := 0

func _initialize() -> void:
	call_deferred("run")

func check(ok: bool, label: String) -> void:
	print(("PASS " if ok else "FAIL ") + label)
	if not ok: failures += 1

func run() -> void:
	var game = Main.instantiate()
	root.add_child(game)
	await process_frame
	var profile: Dictionary = game.world.DEFAULT_PROFILE.duplicate(true)
	profile.cohabitants = 2
	profile.companion_names = ["詩音", "美咲"]
	game._start_new_game(profile)
	game._finish_intro()
	var world = game.world
	var shion: Dictionary = world.s.household_members[0]

	await game._on_command("詩音、水やりのやり方を教えて")
	check(game.log_entries[-1].contains("台所で「水やり」") and world.s.plots.is_empty(), "how-to question answers without performing a task")
	await game._on_command("詩音、今何時？")
	check(game.log_entries[-1].contains("08:"), "ordinary time question reads the game clock")
	await game._on_command("詩音、食料もお願いできる？")
	check(game.log_entries[-1].contains("何個") and shion.get("water_errand", {}).get("item") == "food", "food request opens a quantity question")
	await game._on_command("2個でいいよ")
	check(shion.get("water_errand", {}).get("quantity") == 2, "follow-up resolves the selected item")
	await game._on_command("詩音、木材を買ってきて")
	check(shion.get("water_errand", {}).get("item") == "food", "another item cannot silently replace a queued purchase")
	await game._on_command("美咲、帰りに包帯を2個買ってきて")
	check(world.s.household_members[1].get("water_errand", {}).get("item") == "bandage", "another companion can take a different request")
	var labels: Dictionary = Errands.LABELS
	for item in world.CATALOG:
		check(Errands.intent("帰りに%sを1個買ってきて" % labels[item], {}).get("item") == item, "request parser covers " + item)

	world.s.plots.append({"growth":0.0,"water":0.0})
	await game._on_command("詩音、台所に行って水やりしてくれる？")
	check(shion.location == "台所" and game.location == "寝室" and float(world.s.plots[0].water) > 0.99, "compound request moves and works as the NPC without moving player")
	shion.thirst = 30.0
	var player_thirst := float(world.s.thirst)
	await game._on_command("詩音、水を飲んで")
	check(float(shion.thirst) < 30.0 and float(world.s.thirst) >= player_thirst, "needs are applied to the addressed actor")
	await game._on_command("詩音、玄関を補強しないで")
	check(int(world.s.barricade) == 0, "negative request does not change the door")
	await game._on_command("詩音、頼み：保存")
	check(game.log_entries[-1].contains("プレイヤーの操作"), "save is handled as a player-only command")

	var due := int(shion.get("water_errand", {}).get("due", -1))
	check(due > int(world.s.minute), "morning conversation keeps the original shopping schedule")
	if due > int(world.s.minute):
		world.advance_safe(due - int(world.s.minute) - 11)
		var food := float(world.s.food)
		var bandages := int(world.s.inventory.bandage)
		var cash := float(world.s.cash)
		world.step(false)
		check(shion.location == "食品店" and world.s.household_members[1].location == "薬局" and float(world.s.cash) == cash - 1800, "food and bandages are charged at the corresponding shops")
		await game._on_command("10分待つ")
		check(float(world.s.food) > food + 1.0 and int(world.s.inventory.bandage) == bandages + 2, "different purchases are delivered on return")

	game._start_new_game(profile)
	game._finish_intro()
	shion = world.s.household_members[0]
	world.s.door_locked = false
	await game._on_command("詩音、頼み：食品店へ行く、食料を2個買う、家に帰る")
	check(game.location == "寝室" and shion.location == "玄関" and float(world.s.food) == 7.0, "explicit shop trip purchases and delivers while player remains home")
	check(not shion.has("request_goods"), "delivered purchases cannot be duplicated by another tick")
	await game._on_command("詩音、水を1本渡す")
	check(float(world.s.water) == 4.0 and float(shion.request_bag.water) == 2.0, "giving water moves it from household stock into the addressed NPC bag")
	await game._on_command("詩音、水を1本渡して")
	check(float(world.s.water) == 6.0 and float(shion.request_bag.water) == 0.0, "receiving water transfers from the NPC bag without duplicating it")
	await game._on_command("詩音、一緒に台所に行こう")
	check(game.location == "台所" and shion.location == "台所", "invitation moves both actors through the same route")
	await game._on_command("詩音、一緒に屋外に行こう")
	check(game.location == "屋外" and shion.location == "屋外" and shion.activity == "外出", "companion can follow the player outside")
	world.s.district.bag.water = 2.0
	await game._on_command("詩音、水を1本渡す")
	check(float(world.s.water) == 6.0 and float(world.s.district.bag.water) == 0.0 and float(shion.request_bag.water) == 2.0, "outdoor transfer uses carried water rather than home stock")
	check(game._save() == "保存した。" and game._load() == "保存データを読み込んだ。", "extended actor state round-trips through save")
	game.queue_free()
	await process_frame
	quit(0 if failures == 0 else 1)
