extends RefCounted
# Offline parsing is intentionally bounded. Unknown clauses reject the WHOLE
# plan before mutation. AI plans use the same validation and action executor.
const District = preload("res://scripts/district.gd")
const QUERIES = ["持ち物","状態","主人公情報","生存記録","世界の出来事","配送状況","同居人の様子を見る","店の在庫を見る","住居を点検","近くの住民を観察","街の地図を見る","拠点の状態を見る"]
const COMMANDS = ["周囲を見る","窓から外を見る","ニュースを見る","テレビを見る","SNSを見る","ラジオを聞く","寝る","食事する","水を飲む","1時間休息","玄関を補強","玄関の補強を外す","住居を修繕","浄水する","プランターを作る","種を植える","水やり","収穫","物資を探索する","街を観察する","鍵を開ける","鍵を閉める","玄関の扉を開ける","扉を閉める","傷を手当てする","在宅で仕事をする","勉強する"]
const DRINK_ALIASES = ["水を飲む", "喉を潤す", "喉をうるおす", "水分補給する", "水分を取る"]
const NEWS_ALIASES = ["ニュースをチェック", "ニュースをチェックする", "報道をチェック", "報道をチェックする", "報道を確認する"]

static func failure(message: String) -> Dictionary:return {"ok":false,"actions":[],"clarification":message}
static func wait_action(raw: String) -> Dictionary:
	if raw in ["ここで一晩過ごす", "一晩過ごす", "ここで一晩泊まる"]:
		return {"kind":"wait", "minutes":480, "care":true}
	var re:=RegEx.new()
	re.compile("^(?:自宅で|家で|その場で|ここで|拠点で)?(?:時間を)?([0-9]{1,5})\\s*(分|時間|日|週間)(?:間)?(?:だけ)?(?:待つ|待機する|過ごす|生活する|進める)$")
	var m:=re.search(raw)
	if m==null:return {}
	var amount:=int(m.get_string(1))*(int({"分":1,"時間":60,"日":1440,"週間":10080}[m.get_string(2)]))
	return {"kind":"wait","minutes":amount,"care":amount>=360}
static func allowed(game, command: String, ai: bool = false) -> bool:
	if command in COMMANDS or command in QUERIES or command in District.COMMANDS:return true
	if not game.Navigation.destination(command).is_empty():return true
	var re:=RegEx.new()
	re.compile("^(?:(?:食品店|金物店|薬局|コンビニ|デパート)で)?(?:食料|水|飲料水|木材|部品|種|包帯|浄水器|ソーラーパネル|蓄電池)を(?:[0-9]{1,2}(?:個|箱|セット))?(?:買う|購入する)$")
	if re.search(command)!=null:return true
	var canonical:String=game._canonical_command(command)
	if canonical.begins_with("通販で") or canonical=="invalid_order":return true
	if not ai and canonical in ["保存","読込"]:return true
	return false
static func validate(game, data, ai: bool = false) -> Dictionary:
	if not data is Dictionary:return failure("行動の解釈を読み取れませんでした。何も実行していません。")
	if not data.get("clarification","") is String:return failure("解釈形式が不正です。")
	if not str(data.get("clarification","")).is_empty():return failure(str(data.clarification).left(400))
	if not data.get("actions") is Array or data.actions.is_empty() or data.actions.size()>12:return failure("一度に1～12個の行動を指定してください。")
	var total:=0
	var actions:Array=[]
	for item in data.actions:
		if not item is Dictionary:return failure("解釈した行動の形式が不正です。")
		if str(item.get("kind",""))=="command":
			if not item.get("command") is String or not allowed(game,item.command,ai):return failure("対応できない行動が含まれています。何も実行していません："+str(item.get("command","")).left(120))
			actions.append({"kind":"command","command":item.command})
		elif str(item.get("kind",""))=="wait":
			if not (item.get("minutes") is int or item.get("minutes") is float):return failure("待機時間が不正です。")
			var n:float=item.minutes
			if not is_finite(n) or n!=floor(n) or n<1 or n>10080 or not item.get("care") is bool:return failure("待機は1分～7日で指定してください。")
			total+=int(n)
			if total>10080:return failure("一度の指示で待機できる合計は7日までです。")
			actions.append({"kind":"wait","minutes":int(n),"care":item.care})
		else:return failure("解釈した行動の種類が不正です。何も実行していません。")
	# Loading/saving mixed with other actions makes the sequence ambiguous.
	for item in actions:
		if item.get("command","") in ["保存","読込"] and actions.size()!=1:return failure("保存・読込は単独で指定してください。")
	return {"ok":true,"actions":actions,"clarification":""}
static func local(game, raw: String) -> Dictionary:
	var text:=raw.strip_edges().replace("　"," ").replace("\n","、").trim_suffix("。")
	if text.length()>1200:return failure("文章は1200文字以内で入力してください。")
	# Questions, alternatives, negative and conditional clauses are never guessed.
	for token in ["？","?","かもしれ","できる","だろう","しない","しません","するな","待たない","食べない","飲まない","行かない","寝ない","買わない","または","それとも"]:
		if text.contains(token):return failure("質問・否定・選択を含む指示です。実行したい内容を具体的に確認してください。何も実行していません。")
	text=text.replace("異変があれば中断する","").replace("異変があれば中断","").replace("危険なら中断する","")
	text=text.replace("食事と水分を取りながら","").replace("食事と水分補給をしながら","").replace("飲食しながら","")
	for ending in ["してください","して下さい","してほしい"]:
		if text.ends_with(ending):text=text.trim_suffix(ending)+"する"
	for pair in [["行って","行く、"],["入って","入る、"],["歩いて","歩く、"],["拠点にして","拠点にする、"],["探索して","探索する、"],["出て","出る、"],["食事をして","食事する、"],["買って","買う、"],["移動して","移動する、"],["戻って","戻る、"],["帰って","帰る、"],["食べて","食べる、"],["食事して","食事する、"],["飲んで","飲む、"],["潤して","潤す、"],["うるおして","うるおす、"],["見て","見る、"],["開けて","開ける、"],["閉めて","閉める、"],["確認して","確認する、"],["それから","、"],["そのあと","、"],["その後","、"],["続けて","、"],["。","、"],["、から","、"]]:
		text=text.replace(pair[0],pair[1])
	var actions:Array=[]
	for part in text.split("、",false):
		var cmd:String=part.strip_edges().trim_prefix("そして").strip_edges()
		if cmd.is_empty():continue
		# Conjugated 食事し、 / 確認し、 etc.
		if cmd.ends_with("し"):cmd=cmd.trim_suffix("し")+"する"
		for suffix in ["に籠城する", "にこもる", "を拠点にする"]:
			if cmd.ends_with(suffix):
				var place := game.Navigation.destination(cmd.trim_suffix(suffix) + "へ行く") as String
				if District.SITES.has(place):
					actions.append({"kind":"command","command":place + "へ行く"})
					cmd = "ここを拠点にする"
					break
		var wait:=wait_action(cmd)
		if not wait.is_empty():actions.append(wait);continue
		# A kitchen prefix on a drinking action also specifies where to go.
		# Keep this an exact match so questions and conditions never become actions.
		for kitchen in ["台所で", "キッチンで"]:
			if cmd.begins_with(kitchen) and cmd.trim_prefix(kitchen) in DRINK_ALIASES:
				actions.append({"kind":"command","command":"台所へ行く"})
				cmd = "水を飲む"
				break
		if cmd in DRINK_ALIASES:
			cmd = "水を飲む"
		elif cmd in NEWS_ALIASES:
			cmd = "ニュースを見る"
		var synonyms:Dictionary={"外を歩く":"街を歩く","街を探索する":"街を歩く","外を徘徊する":"街を歩く","地図を見る":"街の地図を見る","周辺地図を見る":"街の地図を見る","備蓄を持っていく":"物資を持っていく","食料と水を持っていく":"物資を持っていく","備蓄を置く":"物資を置く","ここに籠城する":"ここを拠点にする","籠城する":"ここを拠点にする","食事を取る":"食事する","ご飯を食べる":"食事する","ごはんを食べる":"食事する","ニュースを確認する":"ニュースを見る","周りを見回す":"周囲を見る","少し休む":"1時間休息","寝室で寝る":"寝る","台所で食事する":"食事する","玄関を補強する":"玄関を補強","水やりする":"水やり","作物に水をやる":"水やり","収穫する":"収穫"}
		cmd=str(synonyms.get(cmd,cmd))
		var canonical:String=game._canonical_command(cmd)
		if not canonical.is_empty() and canonical!="invalid_order":cmd=canonical
		# Exact safe aliases from legacy execution (not substring matching).
		cmd=str({"家に戻る":"家に帰る","日誌":"生存記録","注文履歴":"配送状況","家を修理":"住居を修繕","住民を観察":"近くの住民を観察","NPCを観察":"近くの住民を観察","収穫する":"収穫","水をやる":"水やり","施錠する":"鍵を閉める","出来事の記録":"世界の出来事","スマホでニュースを見る":"SNSを見る"}.get(cmd,cmd))
		if not allowed(game,cmd):return failure("この部分を正確に解釈できませんでした：「%s」。何も実行していません。AI解釈の接続設定、または具体的な行動の書き直しが必要です。"%part)
		actions.append({"kind":"command","command":cmd})
	return validate(game,{"actions":actions})
