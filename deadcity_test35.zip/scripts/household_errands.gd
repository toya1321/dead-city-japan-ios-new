extends RefCounted

const MAX_QUANTITY := 12
const ITEMS := {"食料":"food", "食べ物":"food", "飲料水":"water", "お水":"water", "水":"water", "木材":"wood", "部品":"parts", "種":"seeds", "包帯":"bandage", "浄水器":"filter", "ソーラーパネル":"solar", "蓄電池":"battery"}
const LABELS := {"food":"食料", "water":"水", "wood":"木材", "parts":"部品", "seeds":"種", "bandage":"包帯", "filter":"浄水器", "solar":"ソーラーパネル", "battery":"蓄電池"}
const SHOP_PLACES := {"grocer":"食品店", "hardware":"金物店", "pharmacy":"薬局"}
const COUNT := "[0-9一二三四五六七八九十]+"
const UNITS := "本|個|袋|箱|台"
const GEAR := ["filter", "solar", "battery"]

static func unit(item: String) -> String:
	if item in GEAR:
		return "台"
	return "本" if item == "water" else "個"
const STOP_BEFORE_RETURN := 10
const PHASES := ["quantity", "queued", "carrying", "returning", "done", "failed"]
const FAILURES := ["closed", "stock", "cash", "rationed", "stayed_home", "owned"]

static func intent(speech: String, person: Dictionary) -> Dictionary:
	var text := speech.strip_edges().trim_prefix("「").trim_suffix("」")
	for i in range(10):
		text = text.replace("０１２３４５６７８９"[i], str(i))
	var order: Dictionary = person.get("water_errand", {})
	var phase := str(order.get("phase", ""))
	var item := str(order.get("item", "water"))
	var names := "|".join(ITEMS.keys())
	var active := phase in ["quantity", "queued", "carrying", "returning"]
	var cancel := RegEx.new()
	cancel.compile("^(?:(?:やっぱり|やはり|あ、)[、 ]*)?(?:(%s|買い物|頼み事|お願い)(?:のこと)?(?:は|を)?[、 ]*)?(?:やめ(?:て|といて|ておいて)|なし(?:で)?|いらない|要らない|買わなくていい(?:よ)?|キャンセル(?:して)?)[。！!]*$" % names)
	var cancelled := cancel.search(text)
	if active and cancelled != null and str(ITEMS.get(cancelled.get_string(1), item)) == item:
		return {"kind":"cancel"}
	var status := RegEx.new()
	status.compile("^(?:(?:昨日|さっき|頼んだ)の?)?(?:(%s|買い物|頼み事)(?:は|のこと|の件)?[、 ]*)?(?:どうだった|買えた|買ってきた|買えなかった|どうなった|持って帰れた)(?:の)?[。？！?!]*$" % names)
	var asked_status := status.search(text)
	if not order.is_empty() and asked_status != null and str(ITEMS.get(asked_status.get_string(1), item)) == item:
		return {"kind":"status"}
	var request := RegEx.new()
	request.compile("^(?:(?:もし)?(?:買い物に?行くなら|買い物に?行くとき|買い物のついでに|出かけるなら|帰りに|ついでに|今日)[、 ]*)?(?:ペットボトルの)?(%s)(?:を|も|は|、| )?(?:(%s)(?:%s)(?:を|だけ|ほど|くらい)?[、 ]*)?(?:お願い(?:できる|してもいい|できないかな|できるかな|します|ね)?|頼(?:む|める|んでもいい)|買って(?:(?:きて|来て)(?:くれる|もらえる|くれない|もらえない|ほしい|ほしいな)?|くれる|もらえる|ほしい))[。？！?!]*$" % [names, COUNT, UNITS])
	var requested := request.search(text)
	if requested != null:
		item = str(ITEMS[requested.get_string(1)])
		var raw := requested.get_string(2)
		return {"kind":"request", "item":item} if raw.is_empty() else {"kind":"set", "item":item, "quantity":_number(raw)}
	var amount := RegEx.new()
	amount.compile("^(?:(?:じゃあ|やっぱり|うん)[、 ]*)?(?:(%s)(?:を|は|も)?[、 ]*)?(%s)(?:%s)(?:だけ|くらい|ほど)?(?:で(?:いい(?:よ|です)?|十分(?:だよ|です)?|お願い(?:します|ね)?)|にして|お願い(?:します|ね)?|で)?[。！!]*$" % [names, COUNT, UNITS])
	var count_match := amount.search(text)
	if count_match != null and phase in ["quantity", "queued"] and str(ITEMS.get(count_match.get_string(1), item)) == item:
		return {"kind":"set", "item":item, "quantity":_number(count_match.get_string(2))}
	return {}

static func _number(raw: String) -> int:
	return int(raw) if raw.is_valid_int() else ["零","一","二","三","四","五","六","七","八","九","十","十一","十二"].find(raw)

static func reply(world, person: Dictionary, action: Dictionary) -> String:
	var order: Dictionary = person.get("water_errand", {})
	var phase := str(order.get("phase", ""))
	var active := phase in ["quantity", "queued", "carrying", "returning"]
	var old_item := str(order.get("item", "water"))
	var item := str(action.get("item", old_item))
	var label := str(LABELS[item])
	var counter := unit(item)
	match action.kind:
		"status":
			if active:
				if phase == "quantity":
					return "まだ数を聞いてなかったね。%sは何%sいる？" % [label, counter]
				return "%s%d%s、帰りに寄ってみる予定だよ。" % [label, int(order.quantity), counter]
			order.reported = true
			return report_text(order)
		"cancel":
			if phase in ["carrying", "returning"]:
				return "もう店に寄ったよ。帰ってから結果を話すね。"
			person.erase("water_errand")
			return "分かった。%sの頼みは取り消しておくね。" % label
	if phase in ["carrying", "returning"]:
		return "さっきの分はもう店に寄ったよ。"
	if phase in ["quantity", "queued"] and item != old_item:
		return "%sの頼みが残ってるよ。先に数を決めるか、取り消してから頼んでね。" % LABELS[old_item]
	if action.kind == "request" and phase == "queued":
		return "%sは%d%sの予定だよ。変えるなら数を教えて。" % [label, int(order.quantity), counter]
	var current := int(world.s.minute)
	var hour: float = world.hour_of_day()
	var until_return: int = world.HOUSEHOLD_RETURN * 60 - int(round(hour * 60))
	if world.household_activity_at(world.HOUSEHOLD_LEAVE) != "外出" or until_return <= STOP_BEFORE_RETURN:
		return "このあと買い物に寄る予定がないんだ。今日は引き受けられないよ。"
	var return_minute: int = current + until_return
	if action.kind == "request":
		person.water_errand = {"phase":"quantity", "item":item, "quantity":0, "due":return_minute, "failure":"", "reported":false}
		return "うん。%s、何%sくらい？" % [label, counter]
	var quantity := int(action.quantity)
	var maximum := 1 if item in GEAR else MAX_QUANTITY
	if quantity < 1 or quantity > maximum:
		return "%sは%d%sまでなら頼めるよ。いくつにする？" % [label, maximum, counter]
	person.water_errand = {"phase":"queued", "item":item, "quantity":quantity, "due":return_minute, "failure":"", "reported":false}
	return "分かった。%s%d%sね。帰りに寄ってみるよ。" % [label, quantity, counter]

static func step(world, person: Dictionary) -> void:
	var order: Dictionary = person.get("water_errand", {})
	if order.is_empty():
		return
	var item := str(order.get("item", "water"))
	var now := int(world.s.minute)
	var due := int(order.due)
	if order.phase == "quantity" and now >= due - STOP_BEFORE_RETURN:
		person.erase("water_errand")
		return
	if float(person.health) <= 0:
		return
	if order.phase == "queued" and now >= due - STOP_BEFORE_RETURN:
		order.failure = "stayed_home"
		if person.activity == "外出":
			person.location = SHOP_PLACES[world.CATALOG[item].shop]
			order.failure = world.buy_household_item(item, int(order.quantity))
		order.phase = "carrying" if order.failure.is_empty() else "returning"
	if now >= due and person.activity == "在宅":
		if order.phase == "carrying":
			world.add_household_purchase(item, int(order.quantity))
			order.phase = "done"
		elif order.phase == "returning":
			order.phase = "failed"

static func report_text(order: Dictionary) -> String:
	var item := str(order.get("item", "water"))
	var label := str(LABELS[item])
	if order.get("phase") == "done":
		return "%s、%d%s買えたよ。家に持って帰った。" % [label, int(order.quantity), unit(item)]
	match str(order.get("failure", "")):
		"closed": return "店まで行ったけど、閉まってて%sは買えなかった。" % label
		"stock": return "店に必要な数が残ってなくて、%sは買えなかったよ。" % label
		"cash": return "%sを買うには手持ちのお金が足りなかったよ。" % label
		"rationed": return "店で購入数に制限があって、頼まれた数は買えなかったよ。"
		"stayed_home": return "今日は外出を見送ったから、%sは買えてないよ。" % label
		"owned": return "%sはもう手に入ってるから、追加では買わなかったよ。" % label
		"equipment_quantity": return "%sは1台ずつ買えるよ。" % label
	return ""

static func valid(order: Variant) -> bool:
	if not order is Dictionary or order.get("phase") not in PHASES or not order.get("reported") is bool:
		return false
	for key in ["quantity", "due"]:
		var n = order.get(key)
		if (not n is int and not n is float) or not is_finite(float(n)) or floorf(float(n)) != float(n):
			return false
	var item = order.get("item", "water")
	if not item is String or not LABELS.has(item):
		return false
	var maximum := 1 if item in GEAR else MAX_QUANTITY
	if int(order.due) < 0 or (int(order.quantity) != 0 if order.phase == "quantity" else int(order.quantity) < 1 or int(order.quantity) > maximum):
		return false
	return order.get("failure") in FAILURES if order.phase in ["returning", "failed"] else order.get("failure") == ""
