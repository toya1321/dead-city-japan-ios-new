extends RefCounted

const Plan = preload("res://scripts/action_plan.gd")
const Navigation = preload("res://scripts/navigation.gd")
const District = preload("res://scripts/district.gd")
const Errands = preload("res://scripts/household_errands.gd")
const Dialogue = preload("res://scripts/household_dialogue.gd")
const HOME_TASKS := {
	"玄関を補強":["fortify","玄関",0], "玄関の補強を外す":["unfortify","玄関",0],
	"プランターを作る":["craft","台所",0], "種を植える":["plant","台所",0],
	"水やり":["tend","台所",10], "収穫":["harvest","台所",30],
}
const SUCCESS := ["最初の鉢", "収穫した"]
const NEWS := ["ニュースを見る","テレビを見る","SNSを見る","ラジオを聞く"]
const DOOR := ["鍵を開ける","鍵を閉める","玄関の扉を開ける","扉を閉める"]
const POLITE := "ください|くれる|くれないかな|くれない|もらっていい|もらえる|もらえないかな|もらえない|ほしいな|ほしい|くれますか|くれ|ね|よ"

static func joint_destination(speech: String) -> String:
	var joint := RegEx.new()
	joint.compile("^(?:一緒に|ついてきて[、 ]*)(.+?)(?:に|へ)(?:行こう|行かない|来て|行ってくれる)[。？！?!]*$")
	var matched := joint.search(speech.strip_edges())
	return Navigation.destination(matched.get_string(1) + "へ行く") if matched != null else ""

static func handoff(speech: String) -> Dictionary:
	var transfer := RegEx.new()
	transfer.compile("^(水|飲料水|食料)を([0-9０-９一二三四五六七八九十]+)(本|L|リットル|個|日分)(?:だけ)?(渡す|あげる|渡して(?:くれる)?|ちょうだい|くれる)[。？！?!]*$")
	var matched := transfer.search(speech.strip_edges())
	if matched == null:
		return {}
	var unit := matched.get_string(3)
	var item := "food" if matched.get_string(1) == "食料" else "water"
	if (item == "water" and unit not in ["本","L","リットル"]) or (item == "food" and unit not in ["個","日分"]):
		return {}
	var raw := matched.get_string(2)
	for i in range(10):
		raw = raw.replace("０１２３４５６７８９"[i], str(i))
	var amount := float(Errands._number(raw)) * (2.0 if unit == "本" else 1.0)
	var verb := matched.get_string(4)
	return {"item":item, "amount":amount, "give":verb in ["渡す","あげる"]}

static func execute_handoff(world, person: Dictionary, transfer: Dictionary, at_home: bool) -> String:
	var bag: Dictionary = person.get("request_bag", {"food":0.0,"water":0.0})
	var player_stock: Dictionary = world.s if at_home else world.s.district.bag
	var item: String = transfer.item
	var amount: float = transfer.amount
	var label: String = Errands.LABELS[item]
	var limit := District.WATER_LIMIT if item == "water" else District.FOOD_LIMIT
	if amount <= 0:
		return "%sをどれくらい渡すか教えて。" % label
	if transfer.give:
		if float(player_stock[item]) < amount or float(bag[item]) + amount > limit:
			return "渡せる量か、私が持てる量が足りないよ。"
		player_stock[item] -= amount
		bag[item] += amount
	else:
		if float(bag[item]) < amount:
			return "いま手元にそれだけの%sはないよ。" % label
		if not at_home and float(player_stock[item]) + amount > limit:
			return "持てる量を超えちゃうよ。"
		bag[item] -= amount
		player_stock[item] += amount
	person.request_bag = bag
	return "うん、受け取ったよ。" if transfer.give else ("はい、家の備蓄に戻しておいたよ。" if at_home else "はい、受け取って。")

# Explicit requests enter the action interpreter. Ordinary questions and
# small talk continue through the dialogue engine without changing the world.
static func request_text(speech: String) -> String:
	var text := speech.strip_edges().trim_prefix("「").trim_suffix("」")
	if text.begins_with("頼み：") or text.begins_with("頼み:"):
		return text.substr(3).strip_edges()
	if text in ["聞いて","ちょっと聞いて","話を聞いて","ねえ、聞いて"] or "どうやって" in text or "やり方" in text or "方法" in text:
		return ""
	var ending := RegEx.new()
	ending.compile("((?:し|っ|い|ん|け|め|べ|え|て|み|寝|見)て|して|いて|って|んで|いで)(?:%s)?[。？！?!]*$" % POLITE)
	if ending.search(text) != null:
		return text
	return ""

static func local(game, raw: String) -> Dictionary:
	var text := raw.strip_edges().trim_suffix("。").trim_suffix("？").trim_suffix("?").trim_suffix("！").trim_suffix("!")
	if text.contains("ないで") or text.contains("なら") or text.contains("たら"):
		return {"ok":false,"blocked":true}
	var pattern := RegEx.new()
	pattern.compile("(?:%s)$" % POLITE)
	text = pattern.sub(text, "")
	var forms := {
		"して":"する", "見て":"見る", "聞いて":"聞く", "作って":"作る",
		"開けて":"開ける", "閉めて":"閉める", "植えて":"植える",
		"飲んで":"飲む", "行って":"行く", "歩いて":"歩く", "寝て":"寝る",
		"食べて":"食べる", "買って":"買う", "戻って":"戻る", "帰って":"帰る",
		"取って":"取る", "置いて":"置く", "出して":"出す", "出て":"出る",
		"待って":"待つ", "休んで":"1時間休息", "過ごして":"過ごす", "教えて":"見る",
	}
	var aliases := {
		"玄関の鍵を開ける":"鍵を開ける", "玄関の鍵を閉める":"鍵を閉める",
		"作物に水をやる":"水やり", "水をやる":"水やり",
		"在庫を見る":"店の在庫を見る", "休む":"1時間休息",
		"玄関を補強する":"玄関を補強", "水やりする":"水やり", "収穫する":"収穫",
	}
	if text == "休んで":
		text = "1時間休息"
	else:
		for form in forms:
			if form == "休んで":
				continue
			if text.ends_with(form):
				text = text.trim_suffix(form) + forms[form]
				break
	text = aliases.get(text, text)
	return Plan.local(game, text)

static func execute(game, person: Dictionary, plan: Dictionary) -> String:
	var lines: Array[String] = []
	for action in plan.actions:
		if game.cancel_requested:
			lines.append("ここで作業を中断したよ。")
			break
		if float(person.health) <= 0 or person.activity == "睡眠":
			lines.append("今は続けられないよ。")
			break
		var result: Dictionary = await _wait(game, person, int(action.minutes), false) if action.kind == "wait" else await _command(game, person, str(action.command))
		lines.append(result.text)
		if not result.ok:
			break
	return "\n".join(lines)

static func _result(text: String, ok: bool = false) -> Dictionary:
	return {"text":text,"ok":ok}

static func _wait(game, person: Dictionary, minutes: int, rest: bool) -> Dictionary:
	var world = game.world
	var before := str(person.activity)
	var place := str(person.location)
	var elapsed := 0
	while elapsed < minutes and float(person.health) > 0 and person.activity == before and person.location == place:
		if game.cancel_requested or int(world.advance_safe(1)) == 0:
			break
		elapsed += 1
		if elapsed % 30 == 0:
			await game.get_tree().process_frame
	if rest:
		person.fatigue = maxf(0.0, float(person.fatigue) - 12.5 * elapsed / 60.0)
	return _result("%d分%sよ。%s" % [elapsed, "休んだ" if rest else "待った", "" if elapsed == minutes else "予定が変わったから、そこで切り上げたよ。"], elapsed == minutes)

static func _move(world, person: Dictionary, destination: String) -> Dictionary:
	var path := Navigation.route(str(person.location), destination, str(world.s.profile.housing))
	if path.is_empty():
		return _result("%sへはここから行けないよ。" % destination)
	for i in range(1, path.size()):
		var from := path[i - 1]
		var to := path[i]
		if District.SITES.has(to) and not District.can_enter(world, to):
			return _result("%sは今は入れないよ。" % to)
		if (from == "玄関" and not Navigation.indoor(to)) or (to == "玄関" and not Navigation.indoor(from)):
			if int(world.s.barricade) > 0 or bool(world.s.door_locked):
				return _result("玄関が通れないよ。")
		person.location = to
		person.activity = "在宅" if Navigation.indoor(to) else "外出"
		if int(world.advance_safe(Navigation.duration(from, to))) == 0 or person.location != to:
			return _result("移動の途中で予定が変わったよ。")
	return _result("%sに着いたよ。" % destination, true)

static func _command(game, person: Dictionary, cmd: String) -> Dictionary:
	var world = game.world
	var place := str(person.location)
	var home := Navigation.indoor(place)
	var destination := Navigation.destination(cmd)
	if not destination.is_empty():
		return _move(world, person, destination)
	if cmd in ["保存","読込","主人公情報"]:
		return _result("それはプレイヤーの操作だよ。「行動：%s」と入力してね。" % cmd)
	if cmd == "食事する" or cmd == "水を飲む":
		return _consume(world, person, cmd == "水を飲む")
	if cmd in ["寝る", "1時間休息"]:
		if cmd == "寝る" and place != "寝室" and not District.prepared(world, place):
			return _result("寝るなら寝室か整えた拠点に行くね。")
		return await _wait(game, person, 480 if cmd == "寝る" else 60, true)
	if cmd in HOME_TASKS or cmd in ["住居を修繕","浄水する"]:
		return _home_task(world, person, cmd)
	if cmd in DOOR:
		if place not in ["玄関","共用廊下","建物前"]:
			return _result("玄関のそばに行ってからだね。")
		if not home and cmd != "扉を閉める":
			return _result("外から使える鍵は持っていないよ。")
		world.s.door_locked = cmd == "鍵を閉める" or (cmd == "扉を閉める" and bool(world.s.door_locked))
		world.s.door_open = cmd == "玄関の扉を開ける"
		world.advance_safe(1)
		return _result("%s、済ませたよ。" % cmd, true)
	if cmd in NEWS:
		if not home:
			return _result("いま家の受信機は使えないよ。")
		return _result(game._read_news(cmd), true)
	if cmd == "街を歩く":
		var i := Navigation.STREETS.find(place)
		return _move(world, person, Navigation.STREETS[(i + 1) % Navigation.STREETS.size()])
	if cmd in District.COMMANDS or (cmd == "物資を探索する" and District.SITES.has(place)):
		var bag: Dictionary = person.get("request_bag", {"food":0.0,"water":0.0})
		var before := int(world.s.minute)
		var report := District.act(world, place, cmd, home, bag)
		if int(world.s.minute) > before:
			person.request_bag = bag
		return _result(report, int(world.s.minute) > before)
	if cmd == "物資を探索する" and place == "屋外":
		if world.s.society == "normal" or float(person.fatigue) > 85.0:
			return _result("今はこの辺りで物資を探せる状況じゃないよ。")
		return _result(world.longplay_action("scavenge", true), true)
	if cmd == "物資を探索する":
		return _result("屋外か探索できる建物に着いてからだね。")
	var purchase := RegEx.new()
	purchase.compile("^(?:(食品店|金物店|薬局|コンビニ|デパート)で)?(.+?)を(?:(\\d{1,2})(?:個|箱|セット))?(?:買う|購入する)$")
	var sale := purchase.search(cmd)
	if sale != null and Errands.ITEMS.has(sale.get_string(2)):
		var item: String = Errands.ITEMS[sale.get_string(2)]
		var quantity := 1 if sale.get_string(3).is_empty() else int(sale.get_string(3))
		if not sale.get_string(1).is_empty() and sale.get_string(1) != place:
			return _result("指定した店まで行ってからだね。")
		if home:
			var report := Errands.reply(world, person, {"kind":"set","item":item,"quantity":quantity})
			return _result(report, report.begins_with("分かった。"))
		if District.SITES.has(place):
			var bag: Dictionary = person.get("request_bag", {"food":0.0,"water":0.0})
			var report := District.buy(world, place, item, quantity, bag)
			if report.begins_with("購入した"):
				person.request_bag = bag
			return _result(report, report.begins_with("購入した"))
		var shop: String = Errands.SHOP_PLACES[world.CATALOG[item].shop]
		if place != shop or quantity < 1 or quantity > Errands.MAX_QUANTITY:
			return _result("%sで必要な数を確かめてからだね。" % shop)
		var goods: Dictionary = person.get("request_goods", {})
		var maximum := 1 if item in Errands.GEAR else Errands.MAX_QUANTITY
		if int(goods.get(item, 0)) + quantity > maximum:
			return _result("いま持っている分で手いっぱいだよ。")
		var failure: String = world.buy_household_item(item, quantity)
		if not failure.is_empty():
			return _result(Errands.report_text({"item":item,"failure":failure}))
		goods[item] = int(goods.get(item, 0)) + quantity
		person.request_goods = goods
		world.advance_safe(5)
		return _result("%s%d%sを買ったよ。家に持って帰るね。" % [Errands.LABELS[item], quantity, Errands.unit(item)], true)
	if cmd.begins_with("通販で"):
		if place not in ["寝室","居間"]:
			return _result("注文端末がある寝室か居間に行ってからだね。")
		var number := RegEx.new()
		number.compile("([0-9]+)個")
		var found := number.search(cmd)
		if found != null:
			var report: String = world.place_order("water" if "水" in cmd else "food", int(found.get_string(1)))
			return _result(report, report.contains("注文した"))
	if cmd == "傷を手当てする":
		if not home or place != game.location:
			return _result("傷を見せてくれるなら、家で同じ部屋に来て。")
		var report: String = world.action("bandage", true)
		if report.begins_with("傷を手当てした"):
			world.advance_safe(10)
		return _result(report, report.begins_with("傷を手当てした"))
	if cmd in ["在宅で仕事をする","勉強する"]:
		return _result("あなたの仕事や勉強の予定は、あなた自身で進めてね。")
	if cmd in Plan.QUERIES or cmd in ["周囲を見る","窓から外を見る","街を観察する"]:
		return _report(game, person, cmd)
	return _result("「%s」は今の私には実行できないよ。" % cmd)

static func _home_task(world, person: Dictionary, cmd: String) -> Dictionary:
	var spec: Array = HOME_TASKS.get(cmd, [])
	if not spec.is_empty():
		if person.location != spec[1]:
			return _result("%sに行ってから作業するね。" % spec[1])
		var before := int(world.s.minute)
		var text: String = world.action(spec[0], true)
		for prefix in SUCCESS:
			if text.begins_with(prefix):
				world.advance_safe(int(spec[2]))
		return _result(text, int(world.s.minute) > before or text.begins_with("植え付けた"))
	if (cmd == "浄水する" and person.location != "台所") or person.location not in ["台所","玄関"]:
		return _result("家の%sに行ってから作業するね。" % ("台所" if cmd == "浄水する" else "台所か玄関"))
	var before := int(world.s.minute)
	var text: String = world.longplay_action("purify" if cmd == "浄水する" else "maintain", true)
	return _result(text, int(world.s.minute) > before)

static func _consume(world, person: Dictionary, drink: bool) -> Dictionary:
	if not Navigation.indoor(str(person.location)):
		var bag: Dictionary = person.get("request_bag", {"food":0.0,"water":0.0})
		var eaten := District.consume(world, str(person.location), "water" if drink else "food", person, bag)
		if eaten:
			person.request_bag = bag
			world.advance_safe(2 if drink else 15)
			return _result("水を飲んだよ。" if drink else "食事したよ。", true)
		return _result("いま使える持ち物がないか、もう十分だよ。")
	var key := "thirst" if drink else "hunger"
	var factor := 3.0 if drink else 1.0
	var amount := minf(0.25 * factor, float(person[key]) * factor / 100.0)
	if amount <= 0:
		return _result("いまは大丈夫だよ。")
	var stock := "water" if drink else "food"
	if drink and bool(world.s.water_online):
		world.s.tap_water_used += amount
	elif float(world.s[stock]) >= amount:
		world.s[stock] -= amount
	else:
		return _result("いま家の%sが足りないよ。" % ("飲み水" if drink else "食料"))
	person[key] = maxf(0.0, float(person[key]) - amount * 100.0 / factor)
	var used := "water_used" if drink else "food_used"
	person[used] += amount
	world.advance_safe(2 if drink else 15)
	return _result("水を飲んだよ。" if drink else "食事したよ。", true)

static func _report(game, person: Dictionary, cmd: String) -> Dictionary:
	var world = game.world
	var place := str(person.location)
	match cmd:
		"状態": return _result(Dialogue._condition(person) + "。", true)
		"持ち物":
			var bag: Dictionary = person.get("request_bag", {"food":0.0,"water":0.0})
			return _result("いま持っているのは食料%.1f日分と水%.1fLだよ。" % [bag.food, bag.water], true)
		"店の在庫を見る":
			if District.SITES.has(place): return _result(District.describe(world, place), true)
			if place in Errands.SHOP_PLACES.values(): return _result(game._shop_inventory(place), true)
			return _result("店に着いてから在庫を確認するよ。")
		"拠点の状態を見る":
			if District.SITES.has(place): return _result(District.describe(world, place), true)
			return _result("ここは外の拠点じゃないよ。")
		"周囲を見る","窓から外を見る","街を観察する","近くの住民を観察":
			if place != game.location:
				return _result("同じ場所まで来てくれたら、一緒に確認できるよ。")
		"配送状況","住居を点検":
			if not Navigation.indoor(place): return _result("家に戻ってから確認できるよ。")
	return _result(game._interpret(cmd), true)
