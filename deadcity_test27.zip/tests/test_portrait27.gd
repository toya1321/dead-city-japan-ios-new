extends SceneTree

const Main = preload("res://main.tscn")
var failures := 0

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, description: String) -> void:
	print(("PASS " if condition else "FAIL ") + description)
	if not condition:
		failures += 1

func settle() -> void:
	Input.flush_buffered_events()
	for i in range(5):
		await process_frame

func tap(control: Control) -> void:
	var point := root.get_screen_transform() * control.get_global_transform_with_canvas() * (control.size * 0.5)
	for down in [true, false]:
		var event := InputEventScreenTouch.new()
		event.index = 0
		event.position = point
		event.pressed = down
		Input.parse_input_event(event)
	await settle()

func fit(control: Control, width: float, bottom: float) -> bool:
	var rect := control.get_global_rect()
	return rect.position.x >= 0 and rect.end.x <= width + 1 and rect.end.y <= bottom + 1

func run() -> void:
	Input.emulate_mouse_from_touch = true
	root.content_scale_size = Vector2i.ZERO
	root.size = Vector2i(390, 844)
	var game = Main.instantiate()
	root.add_child(game)
	await settle()
	var title = game.title_screen
	await tap(title.title_buttons.get_child(0))
	check(title.form_scroll.visible and title.form_rows[0].vertical, "portrait onboarding uses stacked scrollable fields")
	check(fit(title.name_input, 390, 844) and fit(title.form_scroll, 390, 844), "profile form fits the phone width")
	game._start_new_game(game.world.DEFAULT_PROFILE.duplicate(true))
	await settle()
	check(game.intro_actions.columns == 2 and fit(game.intro_actions, 390, 844), "portrait prologue controls fit")
	game._finish_intro()
	await settle()
	for geometry in [Vector2i(360, 640), Vector2i(375, 667), Vector2i(390, 844), Vector2i(402, 874), Vector2i(440, 956)]:
		root.size = geometry
		await settle()
		check(game.main_layout.vertical and game.picture.is_visible_in_tree() and game.picture.size.y >= 135, "scene and chronicle stack at " + str(geometry))
		check(game.picture.get_global_rect().end.y < game.log_scroll.get_global_rect().position.y and game.log_scroll.get_global_rect().end.y < game.command_input.get_global_rect().position.y, "illustration, log, input order at " + str(geometry))
		check(fit(game.send_button, geometry.x, geometry.y - 8) and game.send_button.size.y >= 44 and game.log_scroll.size.y >= 110, "reachable send button and usable reading area at " + str(geometry))
		var keyboard := roundi(geometry.y * 0.57)
		game.safe_margin.add_theme_constant_override("margin_top", 45 if geometry.y >= 800 else 22)
		game.safe_margin.add_theme_constant_override("margin_bottom", keyboard + 6)
		game._apply_responsive_layout(Vector2(geometry), keyboard)
		await settle()
		check(not game.picture.is_visible_in_tree() and game.log_scroll.is_visible_in_tree() and game.log_scroll.size.y >= 90, "keyboard leaves a usable log at " + str(geometry))
		check(fit(game.send_button, geometry.x, geometry.y - keyboard) and fit(game.command_input, geometry.x, geometry.y - keyboard), "composer clears simulated keyboard at " + str(geometry))
		game.layout_keyboard = -1
		game._update_layout()
		await settle()

	await tap(game.tools_button)
	check(game.drawer.visible and game.menu_box.visible, "one tap opens portrait tools")
	await tap(game.menu_box.get_child(0))
	check(game.drawer.visible and game.inventory_status.visible and not game.menu_box.visible, "inventory and body status remain reachable")
	game._close_drawer()
	await settle()
	await tap(game.preview_button)
	check(game.image_preview.visible and game.preview_texture.texture == game.picture.texture, "illustration tap opens the current image")
	game._close_image_preview()
	await settle()

	await tap(game.command_input)
	check(game.command_input.has_focus(), "tap focuses the multiline composer")
	game.command_input.text = "書きかけの行動"
	var before_dismiss := int(game.world.s.minute)
	game._dismiss_command_keyboard()
	check(game.command_input.text == "書きかけの行動" and not game.command_input.has_focus() and int(game.world.s.minute) == before_dismiss, "closing keyboard preserves draft and time")
	await tap(game.command_input)
	var start := int(game.world.s.minute)
	game.command_input.text = "キッチンで喉を潤して、"
	game.command_input.set_caret_column(game.command_input.text.length())
	var enter := InputEventKey.new()
	enter.pressed = true
	enter.keycode = KEY_ENTER
	Input.parse_input_event(enter)
	await settle()
	check(game.command_input.text.contains("\n") and int(game.world.s.minute) == start, "Return inserts a line without executing")
	game.command_input.insert_text_at_caret("それから報道をチェック")
	await tap(game.send_button)
	check(game.last_plan.ok and game.location == "台所" and int(game.world.s.minute) > start and game.log_entries[-1].contains("情報源"), "portrait send executes the existing three-action plan")
	check(not game.command_input.has_focus() and game.command_input.text.is_empty(), "send clears focus and draft")
	game.queue_free()
	await settle()
	quit(0 if failures == 0 else 1)
