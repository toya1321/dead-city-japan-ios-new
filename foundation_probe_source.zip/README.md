# DCJ Local AI Probe v1

Appleの端末内Foundation Modelsを呼べるか確認する、ゲーム本体とは別の検証アプリ。

- Bundle ID: `com.deadcityjapan.foundationprobe`
- Version: 1.0 / build 1
- 対象: iOS 26以降。AI生成にはApple Intelligence対応端末と準備済みモデルが必要。
- 利用モデル: `SystemLanguageModel.default` のみ。PCC、ChatGPT、外部AI API、APIキーは使用しない。
- 未署名IPAで配布。既存の方法でLiveContainerへ読み込むか、SideStore等で再署名して単体導入する。
- DEAD CITY JAPANのセーブやファイルにアクセスしない。

## 端末での確認手順

1. iPhoneのApple Intelligenceを有効にし、モデルの準備を完了する。
2. `DCJ-Local-AI-Probe-v1-unsigned.ipa` をLiveContainerに追加して起動する。
3. 画面上部の起動方法を `LiveContainer` に設定する。自動検出ではなく、手動の記録用。
4. 「利用状態を再確認」を押す。利用可能でも生成成功とは限らない。
5. 「1. 日本語の応答」を押し、アプリを開いたまま応答を待つ。
6. 「AI呼出し成功」が出たら、続いて「2. 複数行動」「3. 否定」「4. 長期待機」を各1回押す。
7. 「結果をコピー」を押して結果をチャットに貼る。スクリーンショットでも可。
8. 同じIPAをSideStoreで再署名して単体導入し、起動方法を `SideStore単体` に変えて同じ手順を試す。単体導入には通常のアプリ枠が必要。
9. モデル準備後、機内モードでもテスト1を試すとオフラインで応答できるか比較できる。

端末内AIの利用に外部API料金は発生しない。モデル準備のダウンロード通信は別。

## 結果の読み方

- **利用可能**: OSの利用状態チェックのみ成功。まだ生成を確認していない。
- **AI呼出し成功** / `response_received`: Foundation Modelsから実際の応答が返った。
- **出力検査：一致**: 決められたテストの期待値に一致した。
- **出力検査：不一致**: 応答自体は返ったが、指定した日本語/JSON/行動順序等が期待と違う。
- **AI呼出し失敗** / `failed`: エラーの型・domain・code・説明・取得できた範囲の原因を表示する。
- **対象外 / 無効 / 準備中**: 表示理由を確認し、端末設定やモデル準備後に再確認する。
- **timeout**: 45秒を超えたため待機を中断。必要なら再起動して再試行する。
- **startedのままでアプリが落ちる**: 次回起動時に開始記録が残る。どの起動方法・どのテストで落ちたかも伝える。

ゲーム内の行動・物資・時間は一切変更しない。自由入力の正しさは自動判定しない。

結果はアプリ内 `Documents/FoundationProbe-result.json` に自動保存。直近30イベントを保存し、コピー・共有できる。自由入力した文章と応答も含むため、検証用の内容で試す。

## ビルドと検証

macOSとXcode 26以降が必要。`bash build-probe.sh` で、出力判定のSwiftテスト15項目・ソース検査・iPhoneOS arm64コンパイル・IPA構造検査を実行する。`bash simulator-smoke.sh` はインストール済みiOS 26以降のSimulatorがあれば画面起動と利用状態の記録を確認する。

Simulatorで起動できても、実機のAI生成やLiveContainerでの動作を確認したことにはならない。実際にAIを呼べるかは、このIPAを端末で動かして確認する。

参照: https://developer.apple.com/documentation/foundationmodels/generating-content-and-performing-tasks-with-foundation-models
