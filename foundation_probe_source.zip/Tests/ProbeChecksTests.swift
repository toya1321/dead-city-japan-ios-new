import Foundation
@main struct ProbeChecksTests {
    static func main() {
        var checks = 0
        func check(_ condition: Bool, _ label: String) {
            checks += 1
            guard condition else { fatalError("FAIL: " + label) }
            print("PASS: " + label)
        }
        check(ProbeChecks.assess(.greeting,response:"端末内AIの動作確認に成功しました。").passed,"Japanese expected phrase")
        check(!ProbeChecks.assess(.greeting,response:"Hello").passed,"English response is not Japanese success")
        check(ProbeChecks.assess(.compound,response:"{\"actions\":[\"台所へ行く\",\"食事する\",\"水を飲む\",\"ニュースを見る\"]}").passed,"correct four actions")
        check(!ProbeChecks.assess(.compound,response:"{\"actions\":[\"水を飲む\",\"食事する\"]}").passed,"wrong order rejected")
        check(ProbeChecks.assess(.negation,response:"```json\n{\"actions\":[\"ニュースを見る\"]}\n```").passed,"fenced JSON accepted")
        check(!ProbeChecks.assess(.negation,response:"{\"actions\":[\"水を飲む\",\"ニュースを見る\"]}").passed,"negated action rejected")
        check(!ProbeChecks.assess(.negation,response:"{\"actions\":[\"ニュースを見る\",\"ニュースを見る\"]}").passed,"duplicate action rejected")
        check(!ProbeChecks.assess(.negation,response:"not json").passed,"malformed response rejected")
        check(ProbeChecks.assess(.routine,response:"{\"minutes\":10080,\"care\":true}").passed,"seven days and care")
        check(!ProbeChecks.assess(.routine,response:"{\"minutes\":10080,\"care\":1}").passed,"numeric care is not true")
        check(!ProbeChecks.assess(.routine,response:"{\"minutes\":true,\"care\":true}").passed,"boolean duration rejected")
        check(!ProbeChecks.assess(.routine,response:"{\"minutes\":10080.5,\"care\":true}").passed,"fractional duration rejected")
        check(!ProbeChecks.assess(.routine,response:"{\"minutes\":10080,\"care\":false}").passed,"missing care rejected")
        check(!ProbeChecks.assess(.custom,response:" \n ").passed,"empty response rejected")
        check(ProbeChecks.assess(.custom,response:"応答あり").passed,"nonempty custom response")
        print("ALL \(checks) PROBE CHECKS PASSED")
    }
}
