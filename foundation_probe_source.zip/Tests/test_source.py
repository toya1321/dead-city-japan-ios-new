from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'Sources/ProbeApp.swift').read_text()
assert 'SystemLanguageModel.default' in s
assert 'URLSession' not in s and 'PrivateCloudComputeLanguageModel(' not in s
assert 'Bearer ' not in s and 'https://' not in s
assert 'response_received' in s and 'ProbeChecks.assess' in s
assert 'Task.sleep(for: .seconds(45))' in s and 'activeID == id' in s
assert 'options: .atomic' in s and 'NSUnderlyingErrorKey' in s
assert 'guard !busy' in s and 'appleIntelligenceNotEnabled' in s
print('PASS: on-device-only code path, no API keys/network/PCC, separate output checks, deadline/cancellation and persistent diagnostics')
