import zipfile,plistlib,struct,json,hashlib,sys
from pathlib import Path
p=Path(sys.argv[1]);r={'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None
    info=plistlib.loads(z.read('Payload/FoundationProbe.app/Info.plist'))
    assert info['CFBundleIdentifier']=='com.deadcityjapan.foundationprobe'
    assert info['CFBundleShortVersionString']=='1.0' and str(info['CFBundleVersion'])=='1'
    assert info['CFBundleSupportedPlatforms']==['iPhoneOS'] and info['MinimumOSVersion']=='26.0'
    assert not any('/_CodeSignature/' in n or n.endswith('embedded.mobileprovision') for n in z.namelist())
    exe=z.read('Payload/FoundationProbe.app/FoundationProbe')
    h=struct.unpack_from('<8I',exe);assert h[0]==0xfeedfacf and h[1]==0x100000c
    cursor=32;frameworks=[];platforms=[]
    for i in range(h[4]):
        cmd,size=struct.unpack_from('<II',exe,cursor);assert size>=8
        assert cmd!=0x1d,'Executable signed'
        if cmd==0x32:platforms.append(struct.unpack_from('<I',exe,cursor+8)[0])
        if cmd in (0xc,0x18,0x80000018,0x8000001f):
            off=struct.unpack_from('<I',exe,cursor+8)[0];frameworks.append(exe[cursor+off:cursor+size].split(b'\0')[0].decode())
        cursor+=size
    assert 2 in platforms,'Not iOS device binary'
    assert any('FoundationModels.framework/' in x for x in frameworks),'FoundationModels not linked'
    assert not any(n.endswith('.pck') for n in z.namelist()),'Game data should not be in probe'
    r.update(bundle_id=info['CFBundleIdentifier'],version=info['CFBundleShortVersionString'],build=info['CFBundleVersion'],architecture='arm64',platform='iPhoneOS',minimum_os=info['MinimumOSVersion'],code_signature='absent',embedded_profile='absent',frameworks=frameworks,game_included=False)
Path(sys.argv[2]).write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False,indent=2))
