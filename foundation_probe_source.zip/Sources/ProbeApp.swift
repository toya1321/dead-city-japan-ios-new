import SwiftUI
import UIKit
import FoundationModels
import Combine

struct ProbeEvent: Codable, Identifiable {
    let id: UUID
    let date: Date
    let kind: String
    let status: String
    let detail: String
    let response: String?
    let seconds: Double?
    let assessment: ProbeAssessment?
}
struct ProbeReport: Codable {
    let app: String
    let build: String
    let os: String
    let deviceClass: String
    let bundleID: String
    let launchMethod: String
    let availability: String
    let model: String
    let events: [ProbeEvent]
}

@MainActor final class ProbeStore: ObservableObject {
    @Published var availability = "未確認"
    @Published var available = false
    @Published var busy = false
    @Published var current = "まず利用状態を確認してください。"
    @Published var events: [ProbeEvent] = []
    @Published var method = UserDefaults.standard.string(forKey: "launchMethod") ?? "LiveContainer"
    @Published var customPrompt = "台所へ行って水を飲んでから、ニュースを見る。行動を順番に短く書いてください。"
    @Published var reportText = ""
    @Published var copyNotice = ""
    private var requestTask: Task<Void, Never>?
    private var timeoutTask: Task<Void, Never>?
    private var activeID: UUID?
    private var activeKind = ""
    private var startUptime = 0.0
    private let reportURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("FoundationProbe-result.json")

    init() {
        if let data = try? Data(contentsOf: reportURL), let report = try? JSONDecoder.isoDates.decode(ProbeReport.self, from: data) {
            events = Array(report.events.suffix(30))
        }
    }
    func changedMethod() {
        UserDefaults.standard.set(method, forKey: "launchMethod")
        saveReport()
    }
    func refresh() {
        guard !busy else { return }
        switch SystemLanguageModel.default.availability {
        case .available:
            available = true
            availability = "利用可能（まだ応答テストはしていません）"
        case .unavailable(let reason):
            available = false
            switch reason {
            case .deviceNotEligible: availability = "この端末または起動環境は対象外です（deviceNotEligible）"
            case .appleIntelligenceNotEnabled: availability = "Apple Intelligenceが有効になっていません（appleIntelligenceNotEnabled）"
            case .modelNotReady: availability = "モデルが準備できていません。ダウンロード等の完了後に再確認してください（modelNotReady）"
            @unknown default: availability = "利用不可：\(String(describing: reason))"
            }
        @unknown default:
            available = false
            availability = "不明な利用状態です。"
        }
        current = availability
        record(kind: "availability", status: available ? "available" : "unavailable", detail: availability)
    }
    func run(_ kind: ProbeKind) {
        guard !busy else { return }
        let prompt = (kind == .custom ? customPrompt : kind.prompt).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !prompt.isEmpty, prompt.count <= 1200 else {
            current = "入力は1～1200文字にしてください。"; return
        }
        // Availability can change after entering the foreground or preparing a model.
        refresh()
        guard available else { return }
        let id = UUID()
        activeID = id; activeKind = kind.rawValue
        busy = true; current = "\(kind.title)：端末内AIに問い合わせています…"
        startUptime = ProcessInfo.processInfo.systemUptime
        record(kind: kind.rawValue, status: "started", detail: "入力：" + prompt)
        requestTask = Task { [weak self] in
            guard let self else { return }
            do {
                // Explicitly the on-device system model. No PCC or external API.
                let session = LanguageModelSession(model: SystemLanguageModel.default, instructions: "You are a Japanese-language test assistant. Follow the player's requested output format. Do not claim to execute game actions. Respond briefly. 日本語で答えてください。")
                let response = try await session.respond(to: prompt, options: GenerationOptions(temperature: 0, maximumResponseTokens: 512))
                guard !Task.isCancelled, self.activeID == id else { return }
                let seconds = ProcessInfo.processInfo.systemUptime - self.startUptime
                let check = ProbeChecks.assess(kind, response: response.content)
                self.current = "AI呼出し成功（\(String(format: "%.2f", seconds))秒） / 出力検査：\(check.passed ? "一致" : "不一致")"
                self.record(kind: kind.rawValue, status: "response_received", detail: self.current, response: response.content, seconds: seconds, assessment: check)
                self.finish(id)
            } catch {
                guard self.activeID == id else { return }
                let seconds = ProcessInfo.processInfo.systemUptime - self.startUptime
                let ns = error as NSError
                var detail = "\(String(reflecting: error))\n\(ns.domain) / code \(ns.code)\n\(ns.localizedDescription)"
                if let underlying = ns.userInfo[NSUnderlyingErrorKey] as? NSError {
                    detail += "\n原因：\(underlying.domain) / code \(underlying.code) / \(underlying.localizedDescription)"
                }
                self.current = "AI呼出し失敗。下のエラー詳細を確認してください。"
                self.record(kind: kind.rawValue, status: "failed", detail: detail, seconds: seconds)
                self.finish(id)
            }
        }
        timeoutTask = Task { [weak self] in
            do { try await Task.sleep(for: .seconds(45)) } catch { return }
            guard let self, self.activeID == id else { return }
            self.cancel(reason: "45秒以内に応答が返りませんでした（timeout）。再試行前に必要に応じてアプリを再起動してください。", status: "timeout")
        }
    }
    private func finish(_ id: UUID) {
        guard activeID == id else { return }
        activeID = nil; busy = false; requestTask = nil
        timeoutTask?.cancel(); timeoutTask = nil
        saveReport()
    }
    func cancel(reason: String = "操作で中断しました。", status: String = "canceled") {
        guard activeID != nil else { return }
        let seconds = ProcessInfo.processInfo.systemUptime - startUptime
        activeID = nil
        requestTask?.cancel(); timeoutTask?.cancel()
        requestTask = nil; timeoutTask = nil; busy = false
        current = reason
        record(kind: activeKind, status: status, detail: reason, seconds: seconds)
    }
    private func record(kind: String, status: String, detail: String, response: String? = nil, seconds: Double? = nil, assessment: ProbeAssessment? = nil) {
        events.append(ProbeEvent(id: UUID(), date: Date(), kind: kind, status: status, detail: detail, response: response, seconds: seconds, assessment: assessment))
        events = Array(events.suffix(30))
        saveReport()
    }
    private func saveReport() {
        let report = ProbeReport(app: "DCJ Local AI Probe", build: "1.0 (1)", os: UIDevice.current.systemVersion, deviceClass: UIDevice.current.model, bundleID: Bundle.main.bundleIdentifier ?? "unknown", launchMethod: method, availability: availability, model: "Apple SystemLanguageModel.default (on-device)", events: events)
        guard let data = try? JSONEncoder.isoDates.encode(report) else { return }
        reportText = String(data: data, encoding: .utf8) ?? ""
        do { try data.write(to: reportURL, options: .atomic) }
        catch { copyNotice = "結果ファイルを保存できませんでした：\(error.localizedDescription)" }
    }
    func copyReport() {
        saveReport()
        UIPasteboard.general.string = reportText
        copyNotice = "結果をコピーしました。チャットに貼り付けられます。"
    }
}

extension JSONEncoder {
    static var isoDates: JSONEncoder { let e = JSONEncoder(); e.outputFormatting = [.prettyPrinted, .sortedKeys]; e.dateEncodingStrategy = .iso8601; return e }
}
extension JSONDecoder {
    static var isoDates: JSONDecoder { let d = JSONDecoder(); d.dateDecodingStrategy = .iso8601; return d }
}

@main struct FoundationProbeApp: App {
    @StateObject private var store = ProbeStore()
    @Environment(\.scenePhase) private var scenePhase
    var body: some Scene {
        WindowGroup { ProbeView(store: store).task { store.refresh() } }
            .onChange(of: scenePhase) { _, phase in
                if phase == .active { store.refresh() }
                else if phase == .background { store.cancel(reason: "アプリがバックグラウンドになったため中断しました。") }
            }
    }
}

struct ProbeView: View {
    @ObservedObject var store: ProbeStore
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Appleの端末内AIを、この起動方法から呼べるか確認します。APIキー・外部AIサービス・利用料は不要です。")
                        .font(.subheadline).foregroundStyle(.secondary)
                    GroupBox("起動環境") {
                        VStack(alignment: .leading, spacing: 12) {
                            Picker("今回の起動方法", selection: $store.method) {
                                Text("LiveContainer").tag("LiveContainer")
                                Text("SideStore単体").tag("SideStore standalone")
                                Text("その他").tag("Other")
                            }.pickerStyle(.menu).disabled(store.busy)
                            Text("起動方法は自動判定しません。実際の方法を選んでください。").font(.caption).foregroundStyle(.secondary)
                            Text("iOS \(UIDevice.current.systemVersion) / Probe 1.0 (1)").font(.caption.monospaced())
                            Text(store.availability).font(.callout).textSelection(.enabled)
                            Button("利用状態を再確認") { store.refresh() }.buttonStyle(.bordered).disabled(store.busy)
                        }.frame(maxWidth: .infinity, alignment: .leading)
                    }
                    VStack(alignment: .leading, spacing: 10) {
                        if store.busy { ProgressView() }
                        Text(store.current).font(.headline).textSelection(.enabled)
                        if store.busy { Button("中断") { store.cancel() }.buttonStyle(.bordered) }
                    }
                    GroupBox("応答テスト") {
                        VStack(alignment: .leading, spacing: 12) {
                            ForEach([ProbeKind.greeting, .compound, .negation, .routine]) { kind in
                                Button(kind.title) { store.run(kind) }
                                    .buttonStyle(.borderedProminent).frame(maxWidth: .infinity, alignment: .leading)
                                    .disabled(store.busy || !store.available)
                            }
                            Text("呼出し成功と出力検査の一致は別々に表示します。ゲームの行動や時間は実行しません。").font(.caption).foregroundStyle(.secondary)
                        }.frame(maxWidth: .infinity, alignment: .leading)
                    }
                    GroupBox("自由入力（1200文字まで）") {
                        VStack(alignment: .leading, spacing: 12) {
                            TextEditor(text: $store.customPrompt).frame(minHeight: 100).disabled(store.busy)
                            Button("この文章で試す") { store.run(.custom) }.buttonStyle(.bordered).disabled(store.busy || !store.available)
                        }
                    }
                    HStack {
                        Button("結果をコピー") { store.copyReport() }
                        ShareLink("結果を共有", item: store.reportText)
                    }.buttonStyle(.bordered).disabled(store.busy)
                    if !store.copyNotice.isEmpty { Text(store.copyNotice).font(.caption).foregroundStyle(.secondary) }
                    ForEach(store.events.reversed()) { event in
                        GroupBox {
                            VStack(alignment: .leading, spacing: 8) {
                                Text("\(event.kind) / \(event.status)").font(.caption.monospaced()).foregroundStyle(.secondary)
                                Text(event.date, style: .time).font(.caption)
                                Text(event.detail).font(.callout).textSelection(.enabled)
                                if let response = event.response { Text(response).font(.body).textSelection(.enabled) }
                                if let check = event.assessment {
                                    Label(check.passed ? "出力検査：一致" : "出力検査：不一致", systemImage: check.passed ? "checkmark.circle" : "exclamationmark.circle")
                                        .foregroundStyle(check.passed ? .green : .orange)
                                    Text(check.detail).font(.caption).foregroundStyle(.secondary)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    Text("Apple Intelligenceを有効にし、モデルの準備を完了してから試してください。生成中はアプリを開いたままにします。機内モードでも試すと、端末内で応答できることを確認できます。結果はアプリのDocuments内にも自動保存します。")
                        .font(.caption).foregroundStyle(.secondary)
                }.padding()
            }
            .navigationTitle("DCJ Local AI Probe")
            .navigationBarTitleDisplayMode(.inline)
        }
        .onChange(of: store.method) { _, _ in store.changedMethod() }
    }
}
