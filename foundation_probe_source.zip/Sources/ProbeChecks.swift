import Foundation
import CoreFoundation

enum ProbeKind: String, CaseIterable, Identifiable {
    case greeting, compound, negation, routine, custom
    var id: String { rawValue }
    var title: String {
        switch self {
        case .greeting: return "1. 日本語の応答"
        case .compound: return "2. 複数行動の解釈"
        case .negation: return "3. 否定の解釈"
        case .routine: return "4. 長期待機の解釈"
        case .custom: return "自由入力"
        }
    }
    var prompt: String {
        switch self {
        case .greeting:
            return "日本語で短く一文だけ、『端末内AIの動作確認に成功しました』と返してください。"
        case .compound:
            return "生活ゲームの行動入力を解釈してください。入力は『台所へ行って食事し、水を飲んでからニュースを見る』です。行動を順番に分解し、JSONオブジェクトだけを返してください。形式は{\"actions\":[\"行動名\"]}です。使用可能な行動名は『台所へ行く』『食事する』『水を飲む』『ニュースを見る』。入力にない行動は追加しないでください。実際の行動を実行したという文章は書かないでください。"
        case .negation:
            return "生活ゲームの行動入力を解釈してください。入力は『水は飲まずに、ニュースだけ見る』です。実行する行動だけをJSONオブジェクトで返してください。形式は{\"actions\":[\"行動名\"]}です。使用可能な行動名は『食事する』『水を飲む』『ニュースを見る』。否定された行動は含めないでください。入力にない行動は追加しないでください。"
        case .routine:
            return "生活ゲームの行動入力を解釈してください。入力は『自宅で食事と水分を取りながら7日間過ごす』です。JSONオブジェクトだけを返してください。形式は{\"minutes\":整数,\"care\":真偽値}です。minutesは待機する分数。1日は1440分です。careは食事・水分補給・睡眠を含む日常生活ならtrueです。実際には時間を進めず、入力内容だけを解釈してください。"
        case .custom: return ""
        }
    }
}

struct ProbeAssessment: Codable {
    let passed: Bool
    let detail: String
}

enum ProbeChecks {
    static func jsonObject(_ raw: String) -> [String: Any]? {
        var text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if text.hasPrefix("```"), text.hasSuffix("```") {
            let lines = text.components(separatedBy: .newlines)
            guard lines.count >= 3 else { return nil }
            text = lines.dropFirst().dropLast().joined(separator: "\n")
        }
        guard let data = text.data(using: .utf8),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        return object
    }
    static func assess(_ kind: ProbeKind, response: String) -> ProbeAssessment {
        switch kind {
        case .greeting:
            return ProbeAssessment(passed: response.contains("端末内AIの動作確認に成功しました"), detail: "指定した日本語の一文が含まれるか。AI呼出しの成否とは別の出力検査です。")
        case .compound, .negation:
            let expected = kind == .compound ? ["台所へ行く", "食事する", "水を飲む", "ニュースを見る"] : ["ニュースを見る"]
            let actual = jsonObject(response)?["actions"] as? [String]
            return ProbeAssessment(passed: actual == expected, detail: "期待する順序：" + expected.joined(separator: " → "))
        case .routine:
            guard let object = jsonObject(response), let minutes = object["minutes"] as? NSNumber,
                  let care = object["care"] as? NSNumber else {
                return ProbeAssessment(passed: false, detail: "期待値：minutes=10080、care=true（JSON）")
            }
            let valid = CFGetTypeID(minutes) != CFBooleanGetTypeID() && minutes.doubleValue == 10080 && CFGetTypeID(care) == CFBooleanGetTypeID() && care.boolValue
            return ProbeAssessment(passed: valid, detail: "期待値：minutes=10080、care=true（JSON）")
        case .custom:
            return ProbeAssessment(passed: !response.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, detail: "空でない応答の有無だけを確認。内容の正しさは自動判定していません。")
        }
    }
}
