#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
# Use an installed Apple Xcode SDK; no third-party build dependencies.
if [[ "$(uname -s)" != Darwin ]]; then
  echo 'iOS compilation requires macOS and Xcode 26 or later.' >&2; exit 1
fi
SDK_VERSION="$(xcrun --sdk iphoneos --show-sdk-version)"
if [[ "${SDK_VERSION%%.*}" -lt 26 ]]; then
  CHOSEN="$(python3 - <<'PY'
from pathlib import Path
import subprocess,re
candidates=[]
for p in Path('/Applications').glob('Xcode*.app/Contents/Developer'):
    r=subprocess.run(['env','DEVELOPER_DIR='+str(p),'xcrun','--sdk','iphoneos','--show-sdk-version'],capture_output=True,text=True)
    if r.returncode==0:
        v=tuple(map(int,re.findall(r'\d+',r.stdout)))
        if v and v[0]>=26:candidates.append((v,str(p)))
if candidates:print(max(candidates)[1])
PY
)"
  if [[ -z "$CHOSEN" ]]; then echo 'No installed Xcode with iOS 26 SDK or newer.' >&2; exit 1; fi
  export DEVELOPER_DIR="$CHOSEN"
fi
if [[ -n "${DEVELOPER_DIR:-}" && -n "${GITHUB_ENV:-}" ]]; then printf 'DEVELOPER_DIR=%s\n' "$DEVELOPER_DIR" >> "$GITHUB_ENV"; fi
xcodebuild -version | tee build/xcode-version.log
xcrun --sdk iphoneos --show-sdk-version | tee build/sdk-version.log
xcrun swiftc -swift-version 5 -parse-as-library Sources/ProbeChecks.swift Tests/ProbeChecksTests.swift -o build/probe-checks
build/probe-checks | tee build/checks.log
python3 Tests/test_source.py | tee build/source-checks.log
APP="$PWD/build/Payload/FoundationProbe.app"
mkdir -p "$APP/Frameworks"
python3 - "$APP" <<'PY'
import plistlib,sys
from pathlib import Path
p=Path(sys.argv[1])
info={
 'CFBundleName':'DCJ Local AI Probe','CFBundleDisplayName':'DCJ Local AI Probe',
 'CFBundleIdentifier':'com.deadcityjapan.foundationprobe','CFBundleExecutable':'FoundationProbe',
 'CFBundlePackageType':'APPL','CFBundleShortVersionString':'1.0','CFBundleVersion':'1',
 'CFBundleInfoDictionaryVersion':'6.0','CFBundleDevelopmentRegion':'ja','CFBundleLocalizations':['ja','en'],
 'MinimumOSVersion':'26.0','CFBundleSupportedPlatforms':['iPhoneOS'],
 'UIDeviceFamily':[1,2],'LSRequiresIPhoneOS':True,
 'UISupportedInterfaceOrientations':['UIInterfaceOrientationPortrait','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight'],
 'UILaunchScreen':{},'UIApplicationSceneManifest':{'UIApplicationSupportsMultipleScenes':False},
 'UIFileSharingEnabled':True,'LSSupportsOpeningDocumentsInPlace':True,
 'ITSAppUsesNonExemptEncryption':False}
(p/'Info.plist').write_bytes(plistlib.dumps(info))
PY
SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
xcrun --sdk iphoneos swiftc -sdk "$SDK" -target arm64-apple-ios26.0 -swift-version 5 -parse-as-library \
  -O -emit-executable Sources/ProbeChecks.swift Sources/ProbeApp.swift \
  -framework SwiftUI -framework UIKit -framework Combine -framework FoundationModels \
  -Xlinker -rpath -Xlinker '@executable_path/Frameworks' \
  -Xlinker -no_adhoc_codesign -o "$APP/FoundationProbe" 2>&1 | tee build/compile.log
xcrun swift-stdlib-tool --copy --platform iphoneos --scan-executable "$APP/FoundationProbe" --destination "$APP/Frameworks" 2>&1 | tee build/swift-runtime.log
# Remove any vendor/ad-hoc signatures from copied Swift runtime libraries.
while IFS= read -r -d '' BINARY; do
  if file "$BINARY" | grep -q 'Mach-O'; then
    if codesign -d "$BINARY" >/dev/null 2>&1; then codesign --remove-signature "$BINARY"; fi
  fi
done < <(find "$APP" -type f -print0)
xcrun lipo "$APP/FoundationProbe" -verify_arch arm64
(cd build && zip -qry DCJ-Local-AI-Probe-v1-unsigned.ipa Payload)
python3 Tests/verify_ipa.py build/DCJ-Local-AI-Probe-v1-unsigned.ipa build/IPA_VALIDATION.json
shasum -a 256 build/DCJ-Local-AI-Probe-v1-unsigned.ipa > build/SHA256SUMS.txt
