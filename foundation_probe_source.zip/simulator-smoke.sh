#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
# Optional UI smoke test on an already-installed simulator. This is NOT a
# substitute for an Apple-Intelligence-enabled iPhone / LiveContainer test.
if [[ "$(xcrun --sdk iphonesimulator --show-sdk-version | cut -d. -f1)" -lt 26 ]]; then
  echo 'SKIP: default simulator SDK older than 26' | tee build/simulator-status.txt; exit 0
fi
UDID="$(xcrun simctl list devices available -j | python3 -c 'import json,sys; d=json.load(sys.stdin); a=[v["udid"] for runtime,vs in d["devices"].items() if "iOS-26" in runtime or "iOS-27" in runtime for v in vs if "iPhone" in v["name"] and v.get("isAvailable")]; print(a[0] if a else "")')"
if [[ -z "$UDID" ]]; then
  echo 'SKIP: no installed iOS 26+ iPhone simulator' | tee build/simulator-status.txt; exit 0
fi
SIM="$PWD/build/Simulator/FoundationProbe.app"
mkdir -p "$SIM"
cp build/Payload/FoundationProbe.app/Info.plist "$SIM/Info.plist"
python3 - "$SIM/Info.plist" <<'PY'
import plistlib,sys
p=sys.argv[1];d=plistlib.load(open(p,'rb'));d['CFBundleSupportedPlatforms']=['iPhoneSimulator'];plistlib.dump(d,open(p,'wb'))
PY
SDK="$(xcrun --sdk iphonesimulator --show-sdk-path)"
xcrun --sdk iphonesimulator swiftc -sdk "$SDK" -target "$(uname -m)-apple-ios26.0-simulator" -swift-version 5 -parse-as-library \
  Sources/ProbeChecks.swift Sources/ProbeApp.swift -framework SwiftUI -framework UIKit -framework Combine -framework FoundationModels \
  -o "$SIM/FoundationProbe" 2>&1 | tee build/simulator-compile.log
xcrun simctl boot "$UDID" || true
xcrun simctl bootstatus "$UDID" -b
xcrun simctl install "$UDID" "$SIM"
xcrun simctl launch "$UDID" com.deadcityjapan.foundationprobe
DATA="$(xcrun simctl get_app_container "$UDID" com.deadcityjapan.foundationprobe data)"
python3 - "$DATA" <<'PY'
import json,sys,time
from pathlib import Path
p=Path(sys.argv[1])/'Documents/FoundationProbe-result.json'
for i in range(30):
    if p.exists():break
    time.sleep(1)
assert p.exists(),'App did not save its startup availability report'
d=json.loads(p.read_text());assert d['events'] and d['model']=='Apple SystemLanguageModel.default (on-device)'
Path('build/simulator-runtime.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
print('PASS: Simulator app launched and saved actual model availability report')
PY
xcrun simctl io "$UDID" screenshot build/probe-simulator.png
printf '%s\n' 'PASS: UI launched and availability report saved. On-device inference / LiveContainer NOT tested.' | tee build/simulator-status.txt
xcrun simctl terminate "$UDID" com.deadcityjapan.foundationprobe || true
