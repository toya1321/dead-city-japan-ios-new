extends SceneTree

const Main = preload("res://main.tscn")
const District = preload("res://scripts/district.gd")
var failures := 0

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, description: String) -> void:
	print(("PASS " if condition else "FAIL ") + description)
	if not condition:
		failures += 1

func run() -> void:
	var game = Main.instantiate()
	root.add_child(game)
	await process_frame
	game._start_new_game(game.world.DEFAULT_PROFILE.duplicate(true))
	game._finish_intro()
	var world = game.world
	var state: Dictionary = world.s.district

	await game._on_command("街の地図を見る")
	check(world.s.minute == 0 and game.log_entries[-1].contains("デパート"), "map is visible without advancing the world")
	await game._on_command("街を歩く")
	check(game.location == "寝室" and world.s.minute == 0, "walking respects the existing locked entrance")
	await game._on_command("物資を持っていく")
	check(state.bag.food == 2.0 and state.bag.water == 4.0 and world.s.food == 3.0 and world.s.water == 2.0, "packing transfers finite household stock")
	await game._on_command("玄関へ行く、鍵を開ける、外を歩く")
	check(game.location == "商店通り", "free text walks outside into a new street")
	await game._on_command("街を歩く")
	check(game.location == "住宅街", "walking continues through the district")
	await game._on_command("デパートに入る")
	check(game.location == "住宅街" and game.log_entries[-1].contains("営業時間外"), "department store hours are enforced")
	await game._on_command("コンビニへ行く")
	check(game.location == "コンビニ" and game.district_card.visible, "convenience store is reachable and has its own scene label")
	var money := int(world.s.cash)
	await game._on_command("食料を買う")
	check(state.bag.food == 3.0 and state.sites["コンビニ"].food == 7.0 and int(world.s.cash) < money, "open shop charges for finite goods")
	await game._on_command("ここを拠点にする")
	check(state.sites["コンビニ"].level == 0, "operating store cannot be occupied as a shelter")
	await game._on_command("他の家に籠城する")
	check(game.location == "近所の空き家" and state.sites[game.location].level == 1, "vacant house can become a shelter via one text command")
	var house: Dictionary = state.sites["近所の空き家"]
	await game._on_command("物資を探索する")
	check(house.food == 0.5 and house.water == 0.0 and state.bag.food == 4.0, "searching consumes local stock and obeys carrying limits")
	await game._on_command("物資を置く")
	check(house.cache.food == 4.0 and state.bag.food == 0.0, "stashing moves supplies from the bag")
	world.s.hunger = 39.0
	world.s.thirst = 24.0
	var home_stock := Vector2(world.s.food, world.s.water)
	await game._on_command("ここで一晩過ごす")
	check(game.active_wait.elapsed == 480 and house.cache.food < 4 and house.cache.water < 7, "overnight stay uses this shelter's supplies")
	check(home_stock == Vector2(world.s.food, world.s.water), "away from home never draws on household food or water")
	world.s.inventory.wood = 2
	world.s.inventory.parts = 1
	await game._on_command("拠点を補強する")
	check(house.level == 2 and world.s.inventory.wood == 0 and world._player_has_district_cover(), "upgrading spends resources and changes exposure to street agents")
	var saved := var_to_bytes(state)
	check(game._save() == "保存した。", "save at an exterior shelter")
	await game._on_command("自宅に帰る")
	check(game.location == "玄関" and not world._player_has_district_cover() and house.level == 2, "leaving preserves the shelter without carrying its cover")
	check(game._load() == "保存データを読み込んだ。" and game.location == "近所の空き家" and var_to_bytes(world.s.district) == saved, "load restores position, cache, and upgrades")

	world.s.society = "emergency"
	world.s.minute += 59 - int(world.s.minute) % 60
	world.step(false)
	check(world.s.district.sites["コンビニ"].vacant and world.s.district.sites["デパート"].vacant, "world tick independently vacates disrupted stores")
	await game._on_command("デパートに行って籠城する")
	check(game.location == "デパート" and world.s.district.sites["デパート"].level == 1, "abandoned department store is a separate shelter")
	var legacy: Dictionary = world.s.duplicate(true)
	legacy.erase("district")
	var migrated: Dictionary = world.migrate_legacy(legacy)
	check(not migrated.is_empty() and District.valid(migrated.district), "old save gets a fresh district without losing world state")
	game.queue_free()
	await process_frame
	quit(0 if failures == 0 else 1)
