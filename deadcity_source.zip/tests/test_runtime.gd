extends SceneTree
# Execute with: godot --headless --path . --script res://tests/test_runtime.gd
const World = preload("res://scripts/world.gd")
var failures: Array[String] = []

func check(condition: bool, description: String) -> void:
    if not condition:
        failures.append(description)
        push_error("FAIL: " + description)
    else:
        print("PASS: " + description)

func _initialize() -> void:
    call_deferred("run_tests")

func run_tests() -> void:
    var world = World.new()
    check(world.validate_state(world.s), "initial world state valid")
    check(world.s.society == "normal", "normal starting society")
    check(is_equal_approx(float(world.s.water), 6.0), "finite initial drinking water")
    check(not world.can_eat(), "no eating without hunger")
    check(not world.can_drink(), "no drinking without thirst")
    world.advance(30)
    check(world.can_eat(), "hunger develops")
    check(world.can_drink(), "thirst develops")
    var before_food: float = world.s.food
    check(world.eat(), "eat succeeds")
    check(float(world.s.food) < before_food, "food decreases after eating")
    world.s.water_online = false
    var before_water: float = world.s.water
    check(world.drink(), "drink from stored water succeeds when tap off")
    check(float(world.s.water) < before_water, "stored water decreases")
    check(world.validate_state(world.s), "state valid after actions")
    world.advance_days_bounded(4)
    check(int(world.s.regional_cases) > 0, "outbreak progresses without observation")
    check(world.validate_state(world.s), "state valid after multiple days")
    var clone = world.s.duplicate(true)
    clone.water = -1.0
    check(not world.validate_state(clone), "reject negative water save")
    clone = world.s.duplicate(true)
    clone.door_locked = true
    clone.door_open = true
    check(not world.validate_state(clone), "reject impossible locked open door")
    clone = world.s.duplicate(true)
    clone.agents = ["corrupt"]
    check(not world.validate_state(clone), "reject malformed agents")
    check(world.s.longplay is Dictionary, "longplay state exists")
    check(world.validate_state(world.s), "longplay schema validated")
    var broken = world.s.duplicate(true)
    broken.longplay.morale = 101.0
    check(not world.validate_state(broken), "reject impossible morale")
    world.reset() # Subsequent survival/action checks require a living player.
    var day_before: int = int(world.s.longplay.days_survived)
    world.advance(1440)
    check(int(world.s.longplay.days_survived) > day_before, "survival days advance")
    check(world.validate_state(world.s), "state valid after longplay day")
    check(world.longplay_action("maintain").contains("必要"), "maintenance rejects missing parts")
    if failures.is_empty():
        print("ALL RUNTIME CHECKS PASSED")
        quit(0)
    else:
        print("FAILED: ", failures)
        quit(1)
