extends SceneTree
const World=preload("res://scripts/world.gd")
var failures:=0
var checks:=0
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok:
		failures+=1
		push_error("FAIL: "+label)
	else: print("PASS: "+label)
func canonical(value) -> String:
	return JSON.stringify(JSON.parse_string(JSON.stringify(value,"",true,true)),"",true,true)
func _initialize() -> void:
	var a=World.new()
	check(a.clock()=="2028-01-22 17:00","canonical saved time")
	check(a.s.food==837 and a.s.water==null and a.s.battery==null,"preserve known and unknown stocks")
	check(a.census().total==152,"explicit 135 plus legacy wanderer plus 16 residents")
	var b=World.new()
	a.advance(90)
	for _i in range(90): b.advance(1)
	check(canonical(a.s)==canonical(b.s),"time skip equals one-minute stepping")
	var before=canonical(a.s)
	for _i in range(50): a.census()
	check(canonical(a.s)==before,"observation does not mutate state")
	check(a.census().total==a.census().living+a.census().dead,"population conservation")
	var initial=World.new()
	var oldx: float=initial.s.agents[0].x
	var oldz: float=initial.s.agents[0].z
	initial.advance(1)
	check(Vector2(initial.s.agents[0].x-oldx,initial.s.agents[0].z-oldz).length()<=0.701,"movement respects per-minute speed")
	check(a.save_file("user://test_world.save")==OK,"atomic save writes")
	check(b.load_file("user://test_world.save")==OK,"valid save loads")
	check(canonical(a.s)==canonical(b.s),"save roundtrip state")
	a.advance(60)
	b.advance(60)
	check(canonical(a.s)==canonical(b.s),"save continuation deterministic")
	var c=World.new()
	c.s.hunger=25.0
	c.eat()
	check(is_equal_approx(c.s.food,836.75) and c.s.hunger==0,"food mass balance")
	c.s.water=2.0
	c.s.thirst=25.0
	c.drink()
	check(is_equal_approx(c.s.water,1.25),"measured water mass balance")
	c.s.water=null
	c.s.thirst=25.0
	c.drink()
	check(c.s.water==null and is_equal_approx(c.s.water_used,0.75),"unknown water remains unknown with withdrawal ledger")
	c.s.battery=4000.0
	var olddelta: float=c.s.energy_delta
	c.advance(60)
	check(is_equal_approx(c.s.battery-4000,c.s.energy_delta-olddelta),"power balance when measured and not clipped")
	var d=World.new()
	d.advance(1440,true)
	check(absf(d.s.food-836.0)<0.001,"daily routine consumes one food-day")
	check(absf(d.s.water_used-3.0)<0.001,"daily routine consumes three liters")
	check(d.s.health==100,"safe closed home permits uneventful day")
	var e=World.new()
	e.s.inventory.wood=3
	e.s.inventory.parts=2
	e.action("fortify")
	check(e.s.inventory.wood==0 and e.s.inventory.parts==0 and e.s.barricade==1,"craft material conservation")
	e.action("fortify")
	check(e.s.barricade==1,"cannot craft without material")
	var f=World.new()
	# A contact with one pre-existing actor must be necessary for exposure.
	f.s.agents=[f.s.agents[0]]
	f.s.player_pos=[0.0,0.1,14.0]
	f.s.agents[0].x=0.0
	f.s.agents[0].z=14.0
	f.advance(1)
	check(f.s.health<100 and f.s.injuries>0,"nearby physical contact causes injury")
	f.s.agents[0].dead=true
	var hp: float=f.s.health
	f.s.injuries=0
	f.advance(1)
	check(f.s.health==hp,"dead actor cannot attack")
	var g=World.new()
	g.s.agents[0].health=0.001
	g.advance(1)
	check(g.s.agents[0].dead and g.census().total==152,"death changes census without spawning or deleting IDs")
	var blocked=World.new()
	blocked.s.agents=[blocked.s.agents[0]]
	blocked.s.agents[0].x=0.0
	blocked.s.agents[0].z=9.1
	blocked.s.player_pos=[0.0,0.1,8.0]
	blocked.advance(1)
	check(blocked.s.health==100,"closed gate prevents contact across barrier")
	blocked.s.gate_open=true
	blocked.advance(1)
	check(blocked.s.health<100,"opening gate permits causal contact")
	var inside=World.new()
	inside.s.agents=[inside.s.agents[0]]
	inside.s.agents[0].x=0.0
	inside.s.agents[0].z=9.5
	inside.s.player_pos=[0.0,0.1,4.5]
	inside.s.door_open=true
	inside.s.gate_open=true
	inside.advance(10)
	check(inside.s.agents[0].z<6.0,"open gate and door permit ground-floor entry")
	var stocked=World.new()
	stocked.s.agents=[]
	stocked.s.water=0.2
	stocked.s.thirst=50.0
	check(not stocked.drink() and stocked.s.water==0.2,"insufficient measured water cannot be consumed")
	var crop=World.new()
	crop.s.inventory.planter=1
	crop.s.inventory.seeds=1
	crop.action("plant")
	check(crop.s.plots.size()==1 and crop.s.inventory.seeds==0 and crop.s.inventory.planter==0,"planting consumes physical materials")
	crop.s.agents=[]
	crop.s.plots[0].water=15.0
	crop.advance(14*1440,true)
	check(crop.s.plots[0].growth>0.999,"watered crops grow over simulated time")
	var long_run=World.new()
	long_run.s.agents=[]
	long_run.advance(7*1440,true)
	check(long_run.s.health==100 and absf(long_run.s.food-830.0)<0.01,"seven-day peaceful siege preserves survival and food ledger")
	print("WORLD_TESTS %d checks, %d failures"%[checks,failures])
	quit(1 if failures else 0)
