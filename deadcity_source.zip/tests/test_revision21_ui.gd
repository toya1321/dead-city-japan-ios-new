extends SceneTree
const Main = preload("res://main.tscn")
const Vitals = preload("res://scripts/vitals.gd")
var failures: Array[String]=[]
func check(ok: bool,label: String) -> void:
	print(("PASS " if ok else "FAIL ")+label)
	if not ok:failures.append(label)
func _initialize() -> void:call_deferred("run")
func button_named(node: Node,text: String) -> Button:
	for child in node.get_children():
		if child is Button and child.text==text:return child
		var found:=button_named(child,text)
		if found!=null:return found
	return null
func touch(index: int,pressed: bool,pos: Vector2) -> void:
	var event:=InputEventScreenTouch.new();event.index=index;event.pressed=pressed;event.position=pos
	root.push_input(event,true)
func drag(index: int,pos: Vector2,relative: Vector2) -> void:
	var event:=InputEventScreenDrag.new();event.index=index;event.position=pos;event.relative=relative
	root.push_input(event,true)
func mouse(pressed: bool,pos: Vector2) -> void:
	var event:=InputEventMouseButton.new();event.button_index=MOUSE_BUTTON_LEFT;event.position=pos;event.pressed=pressed
	root.push_input(event,true)
func run() -> void:
	root.size=Vector2i(1280,720)
	var game=Main.instantiate();root.add_child(game);await process_frame
	check(game.title_screen!=null and not game.intro_active,"title before gameplay")
	var title=game.title_screen
	title.save_exists=false
	title.continue_button.disabled=true
	check(title.continue_button.disabled,"continue disabled with no save")
	title.name_input.text="冬弥";title.age_input.value=37;title.address_input.text="福岡県嘉麻市";title.home_input.selected=1;title.job_input.selected=2;title.people_input.value=2;title.names_input.text="美咲、ユウタ"
	title._request_start()
	check(game.world.s.profile.name=="冬弥" and game.world.s.profile.age==37 and game.world.s.profile.housing=="集合住宅","settings stored in real world")
	check(game.world.s.sim.local_region==7 and game.world.s.household_members.size()==2,"address selects region and cohabitants exist")
	check(game.intro_body.text.contains("冬弥") and game.intro_body.text.contains("37歳") and game.intro_body.text.contains("福岡県嘉麻市"),"intro matches configured identity")
	var before:PackedByteArray=var_to_bytes(game.world.s)
	game._on_command("30分待つ")
	check(var_to_bytes(game.world.s)==before,"intro does not execute background actions")
	game._finish_intro();await process_frame;await process_frame
	check(game.vitals_bars["満腹度"].value==100 and game.vitals_bars["水分状態"].value==100,"initial good status bars")
	game._on_command("30分待つ")
	check(is_equal_approx(game.vitals_bars["満腹度"].value,100-float(game.world.s.hunger)),"wait updates normalized status")
	check(game.vitals_bars["水分状態"].value<100,"wait lowers hydration")
	game._on_command("水を飲む")
	check(game.vitals_bars["水分状態"].value>98,"drink restores hydration")
	game._on_command("台所へ行く");game._on_command("食事する")
	check(game.vitals_bars["満腹度"].value>95,"meal restores satiety")
	game.world.s.thirst=90;game._refresh()
	check(game.warning_label.visible and game.warning_label.text.contains("水分"),"danger warning is explicit text")
	game.world.s.thirst=0;game._refresh()
	# Actual touch events start over a live action button, not a scrollbar.
	await process_frame;await process_frame
	game.root_scroll.scroll_vertical=0;await process_frame
	var observation:=button_named(game.actions_box,"周囲を見る")
	check(observation!=null,"observation button available")
	var pos:Vector2=observation.get_global_rect().get_center()
	var time:int=game.world.s.minute
	var initial_scroll:int=game.root_scroll.scroll_vertical
	touch(0,true,pos);drag(0,pos-Vector2(0,130),Vector2(0,-130));touch(0,false,pos-Vector2(0,130));await process_frame
	check(game.root_scroll.scroll_vertical>initial_scroll,"swipe over button scrolls right panel")
	check(game.world.s.minute==time,"swipe does not activate action")
	check(not observation.button_pressed,"swipe releases visual pressed state")
	game.root_scroll.velocity=0;game.root_scroll.scroll_vertical=0;await process_frame
	observation=button_named(game.actions_box,"周囲を見る");pos=observation.get_global_rect().get_center()
	touch(0,true,pos);touch(0,false,pos);await process_frame
	check(game.world.s.minute==time+1,"finger tap activates exactly once")
	# Emulated mouse pair after touch must not activate twice.
	var emu:=InputEventMouseButton.new();emu.device=InputEvent.DEVICE_ID_EMULATION;emu.button_index=MOUSE_BUTTON_LEFT;emu.position=pos;emu.pressed=true;root.push_input(emu,true);emu=emu.duplicate();emu.pressed=false;root.push_input(emu,true);await process_frame
	check(game.world.s.minute==time+1,"touch-generated mouse does not duplicate action")
	game.root_scroll.velocity=0;game.root_scroll.scroll_vertical=0;await process_frame
	observation=button_named(game.actions_box,"周囲を見る");pos=observation.get_global_rect().get_center();time=game.world.s.minute
	mouse(true,pos);mouse(false,pos);await process_frame
	check(game.world.s.minute==time+1,"desktop mouse tap preserved")
	game.root_scroll.velocity=0;game.root_scroll.scroll_vertical=0;await process_frame
	observation=button_named(game.actions_box,"周囲を見る");pos=observation.get_global_rect().get_center();time=game.world.s.minute
	touch(3,true,pos);drag(3,pos+Vector2(45,1),Vector2(45,1));touch(3,false,pos+Vector2(45,1));await process_frame
	check(game.world.s.minute==time,"horizontal swipe cannot become a tap")
	touch(4,true,pos)
	var cancel:=InputEventScreenTouch.new();cancel.index=4;cancel.position=pos;cancel.pressed=false;cancel.canceled=true;root.push_input(cancel,true);await process_frame
	check(game.world.s.minute==time,"system-canceled touch cannot activate button")
	# Left card drag, independent of the right panel.
	var left_pos:Vector2=game.left_scroll.get_global_rect().position+Vector2(90,180)
	game.left_scroll.scroll_vertical=0;game.left_scroll.velocity=0
	var right_before:int=game.root_scroll.scroll_vertical
	touch(2,true,left_pos);drag(2,left_pos-Vector2(0,100),Vector2(0,-100));touch(2,false,left_pos-Vector2(0,100));await process_frame
	check(game.left_scroll.scroll_vertical>0 and game.root_scroll.scroll_vertical==right_before,"left card swipe scrolls independently")
	# Journey and both door directions, plus existing save-compatible state.
	game._interpret("玄関へ行く");game._interpret("鍵を開ける");game._interpret("共用廊下へ行く")
	check(game.location=="共用廊下","apartment has actual common corridor")
	game._interpret("外に出る");check(game.location=="屋外","can reach street")
	game._interpret("建物前へ行く");game._interpret("鍵を閉める")
	check(game.world.s.door_locked,"can lock door from outside")
	game._interpret("家に帰る");game._interpret("寝室に戻る")
	check(game.location=="寝室" and not game.world.s.door_open,"can return using own key and close door")
	var start_food:float=game.world.s.food
	game.world.advance_safe(1440)
	check(game.world.s.food<start_food and game.world.s.household_members[0].food_used>0,"cohabitants autonomously consume shared food")
	check(game._save()=="保存した。","save expanded world")
	var loaded=Main.instantiate();root.add_child(loaded);await process_frame
	loaded._continue_from_title()
	check(loaded.title_screen==null and not loaded.intro_active,"continue bypasses introduction")
	check(loaded.world.s.profile.name=="冬弥" and loaded.world.s.household_members.size()==2,"continue restores profile and household")
	check(loaded.location==game.location and loaded.world.s.door_locked==game.world.s.door_locked,"continue restores exact room and lock")
	check(loaded.vitals_bars["満腹度"].value==100-float(loaded.world.s.hunger),"loaded bars match internal state")
	game.queue_free();loaded.queue_free();await process_frame
	print("REVISION21 UI: ",failures.size()," failures")
	quit(0 if failures.is_empty() else 1)
