extends SceneTree
const Scene = preload("res://main.tscn")
const Intro = preload("res://scripts/intro.gd")
var failures: Array[String] = []
func check(ok: bool, label: String) -> void:
	print(("PASS " if ok else "FAIL ") + label)
	if not ok: failures.append(label)
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	var game = Scene.instantiate()
	root.add_child(game)
	await process_frame
	check(game.intro_active and game.intro_page == 0, "prologue opens before play")
	check(game.intro_heading.text == "いつもの朝", "first page heading")
	var before: PackedByteArray = var_to_bytes(game.world.s)
	game._on_command("30分待つ")
	game._utility("load")
	check(var_to_bytes(game.world.s) == before, "background actions and utilities blocked during prologue")
	game._intro_turn(1)
	check(game.intro_page == 1 and game.intro_heading.text == "暮らしのある場所", "next page")
	game._intro_turn(-1)
	check(game.intro_page == 0 and game.intro_previous.disabled, "previous page and lower bound")
	game._intro_turn(1)
	game._intro_turn(1)
	check(game.intro_page == 2 and game.intro_next.text == "この一日を始める", "last page transitions to play")
	for size in [Vector2i(1280,720), Vector2i(1560,720), Vector2i(1280,590)]:
		root.content_scale_size = Vector2i.ZERO
		root.size = size
		await process_frame
		await process_frame
		check(game.intro_body.get_global_rect().size.y >= 80, "readable scroll region " + str(size))
		check(game.intro_next.get_global_rect().end.y <= game.get_viewport_rect().size.y, "next button inside viewport " + str(size))
	check(var_to_bytes(game.world.s) == before and game.world.s.minute == 0, "reading pages never advances time or NPC state")
	game._intro_turn(1)
	check(not game.intro_active, "finish dismisses prologue")
	check(game.log_entries.size() == 4 and game.log_entries[0].contains("トウヤ"), "prologue retained in action history")
	game._finish_intro()
	check(game.log_entries.size() == 4, "duplicate finish is harmless")
	game._on_command("窓を見る")
	check(game.world.s.minute == 2 and game.visual_focus == "window", "normal actions work after reading")
	check(game._save() == "保存した。", "save with prologue history")
	var saved: PackedByteArray = var_to_bytes(game.world.s)
	var resumed = Scene.instantiate()
	root.add_child(resumed)
	await process_frame
	resumed._resume_from_intro()
	check(not resumed.intro_active and var_to_bytes(resumed.world.s) == saved, "continue restores save without consuming time")
	check(resumed.log_entries.size() == game.log_entries.size()+1, "continue does not duplicate prologue")
	check(Intro.PAGES.size() == 3, "three authored pages")
	game.queue_free()
	resumed.queue_free()
	await process_frame
	print("INTRO RUNTIME: ", failures.size(), " failures")
	quit(0 if failures.is_empty() else 1)
