extends SceneTree
const Main=preload("res://main.tscn")
var failures:Array[String]=[]
func check(ok:bool,label:String)->void:
	print(("PASS " if ok else "FAIL ")+label)
	if not ok:failures.append(label)
func _initialize()->void:call_deferred("run")
func button_named(n:Node,label:String)->Button:
	for c in n.get_children():
		if c is Button and c.text==label:return c
		var b:=button_named(c,label)
		if b!=null:return b
	return null
func touch(id:int,down:bool,p:Vector2)->void:
	var e:=InputEventScreenTouch.new();e.index=id;e.position=p;e.pressed=down
	root.push_input(e,true)
func mouse(down:bool,p:Vector2)->void:
	var e:=InputEventMouseButton.new();e.device=InputEvent.DEVICE_ID_EMULATION;e.position=p;e.button_index=MOUSE_BUTTON_LEFT;e.pressed=down
	root.push_input(e,true)
func run()->void:
	root.content_scale_size=Vector2i.ZERO;root.size=Vector2i(1280,720)
	var g=Main.instantiate();root.add_child(g);await process_frame
	g._start_new_game(g.world.DEFAULT_PROFILE.duplicate(true));g._finish_intro();await process_frame;await process_frame;await process_frame
	var b:=button_named(g.actions_box,"周囲を見る");var p:=b.get_global_rect().get_center();var minute:int=g.world.s.minute
	# Emulated down can precede or follow the native touch. Test both, never
	# rely on the single event order used by the previous fixture.
	mouse(true,p);touch(0,true,p);mouse(false,p);touch(0,false,p);await process_frame
	check(g.world.s.minute==minute+1,"mouse-before-touch tap executes exactly once")
	check(g.root_scroll.pointer==-999,"mouse-before-touch leaves no captured pointer")
	g.root_scroll.pointer=-999;g.root_scroll.velocity=0;g.root_scroll.scroll_vertical=0
	for panel in [g.root_scroll,g.left_scroll,g.log_scroll]:panel.last_touch_ms=-10000
	await process_frame
	b=button_named(g.actions_box,"周囲を見る");p=b.get_global_rect().get_center();minute=g.world.s.minute
	# Exercise the actual engine input path with touch-to-mouse emulation.
	Input.emulate_mouse_from_touch=true
	var t:=InputEventScreenTouch.new();t.index=1;t.position=p;t.pressed=true;Input.parse_input_event(t)
	t=t.duplicate();t.pressed=false;Input.parse_input_event(t)
	Input.flush_buffered_events();await process_frame
	check(g.world.s.minute==minute+1,"engine native touch-to-mouse path executes once")
	print("CAPTURE ",g.root_scroll.pointer," last_touch_ms=",g.root_scroll.last_touch_ms)
	g.queue_free();await process_frame
	print("TOUCH23: ",failures.size()," failures")
	quit(0 if failures.is_empty() else 1)
