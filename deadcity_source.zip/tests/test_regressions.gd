extends SceneTree
var failures:=0
var checks:=0
func check(value: bool, label: String) -> void:
	checks+=1
	if value: print("PASS: "+label)
	else:
		failures+=1
		push_error("FAIL: "+label)
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	var game=load("res://main.tscn").instantiate()
	game.persistence_enabled=false
	root.add_child(game)
	game.menu.visible=true
	for _i in range(5): await physics_frame
	var indoors:=0
	var mismatches:=0
	for i in range(game.actor_nodes.size()):
		var n: Node3D=game.actor_nodes[i]
		var a: Dictionary=game.world.s.agents[i]
		if absf(n.global_position.x)<7.0 and n.global_position.z<6.0 and n.global_position.z> -8.0: indoors+=1
		if Vector2(n.global_position.x-a.x,n.global_position.z-a.z).length()>1.1: mismatches+=1
	print("REGRESSION_ACTORS indoors=",indoors," model_mismatches=",mismatches)
	check(indoors==0,"no uninvited character in house after startup")
	check(mismatches==0,"actor render and collision transforms follow world positions")
	var physics_mismatches:=0
	for n in game.actor_nodes:
		var physics_transform: Transform3D=PhysicsServer3D.body_get_state(n.get_rid(),PhysicsServer3D.BODY_STATE_TRANSFORM)
		if physics_transform.origin.distance_to(n.global_position)>0.01: physics_mismatches+=1
	check(physics_mismatches==0,"NPC collision bodies match visible positions")
	game.world.s.door_open=true
	game.world.s.door_locked=false
	game.world.s.gate_open=true
	game.world.s.gate_locked=false
	game.apply_doors()
	game.player.position=Vector3(0,0.2,4.0)
	for _i in range(5): await physics_frame
	for _i in range(160):
		await physics_frame
		game.player.velocity=Vector3(0,-2,3)
		game.player.move_and_slide()
	check(game.player.position.z>9.5,"walk outside through open door and gate")
	for _i in range(220):
		await physics_frame
		game.player.velocity=Vector3(0,-2,-3)
		game.player.move_and_slide()
	print("REGRESSION_RETURN_POSITION ",game.player.position)
	check(game.player.position.z<5.0,"walk back inside through the same open door")
	for mode in ["walking","running","crouching"]:
		game.menu.visible=true
		game.player.position=Vector3(0.0 if mode=="walking" else (0.6 if mode=="running" else -0.6),0.2,4)
		game.player.velocity=Vector3.ZERO
		game.yaw=PI
		game.pitch=0
		game.running=mode=="running"
		game.crouching=mode=="crouching"
		game.menu.visible=false
		game.move_axis=Vector2(0,-1)
		for _i in range(300):
			await physics_frame
			if game.player.position.z>=10.5: break
		game.move_axis=Vector2.ZERO
		check(game.player.position.z>9.3,"runtime "+mode+" exits house")
		game.yaw=0
		game.move_axis=Vector2(0,-1)
		for _i in range(300): await physics_frame
		game.move_axis=Vector2.ZERO
		game.menu.visible=true
		print("RUNTIME_RETURN ",mode," ",game.player.position," fatigue=",game.world.s.fatigue)
		check(game.is_home() and game.player.position.y>0.04,"runtime "+mode+" returns through open entrance")
	game.player.position=Vector3(20,0.1,17.0)
	game.player.rotation.y=PI
	game.camera.rotation=Vector3.ZERO
	await physics_frame
	check(game.ray_target()=="shop:grocer","storefront is physically interactable")
	game.interact()
	check(game.menu.visible and game.shop_mode=="grocer","storefront opens actual shopping menu")
	var old_food: float=game.world.s.food
	game.shop_action("食料1日 600円")
	check(game.world.s.food==old_food+1,"shopping button transfers real food")
	print("REGRESSION_TESTS %d checks, %d failures"%[checks,failures])
	game.queue_free()
	await process_frame
	quit(1 if failures else 0)
