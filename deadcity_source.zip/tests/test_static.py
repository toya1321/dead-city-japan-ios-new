"""Source-level regression checks. These do not execute the Godot engine."""
from pathlib import Path
import re, json, zipfile
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/'scripts/main.gd').read_text()
world=(ROOT/'scripts/world.gd').read_text()
checks={
 'main scene exists':(ROOT/'main.tscn').exists(),
 'project config exists':(ROOT/'project.godot').exists(),
 'five illustrations exist':all((ROOT/f'assets/illustrations/{x}.svg').exists() for x in ('bedroom','living','kitchen','entrance','street')),
 'private rules valid JSON': isinstance(json.loads((ROOT/'assets/private_rules.json').read_text()),dict),
 'finite initial water':'"water":6.0' in world and '"water":null' not in world,
 'no null infinite water path':'s.water == null' not in world,
 'water consumption tracked':'s.water_used += liters' in world,
 'food consumed before time passes':main.index('if not world.eat()')<main.index('world.advance(15)'),
 'water consumed before time passes':main.index('if not world.drink()')<main.index('world.advance(2)'),
 'outside coordinates': '"屋外": world.s.player_pos = [0.0, 1.6, 12.0]' in main,
 'enter home despite closed unlocked door':'if world.s.door_locked or not world.s.door_open' not in main,
 'door closes on re-entry':'world.s.door_open = false\n\t\t_sync_player_position()' in main,
 'location updated on load':'location = str(data["location"])\n\tvisual_focus = ""\n\t_sync_player_position()' in main,
 'validate actor shapes':'for actor in data.agents:' in world,
 'validate vehicle shapes':'for vehicle in data.vehicles:' in world,
 'validate numeric bounds':'if float(data[key]) < 0.0' in world,
 'new save format':'const SAVE_VERSION = 5' in main and 'chronicle_v5.json' in main,
 'unsupported actions do not advance time':'return "その行動はまだ処理できない。世界の状態や時間は変更していない。"' in main,
 'outbreak advances without observation':'_update_outbreak()' in world and 'func _update_outbreak()' in world,
 'dead player actions blocked':'if float(world.s.health) <= 0.0' in main,
}
for key,val in checks.items():print(('PASS' if val else 'FAIL')+' '+key)
assert all(checks.values()),'Static regression failed'
print(f'PASSED {len(checks)} static checks')
