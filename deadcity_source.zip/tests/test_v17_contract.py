from pathlib import Path
import re, json
root=Path(__file__).resolve().parents[1]
w=(root/'scripts/world.gd').read_text()
m=(root/'scripts/main.gd').read_text()
assert 'const VERSION = 22' in w
assert 'func advance_safe(' in w
assert 'in [15, 16, 17, 18, 19, 20, 21]' in m
assert 'if old_version not in [15, 16, 17, 18, 19, 20, 21]' in w
assert 'var elapsed: int = world.advance_safe(wait_minutes)' in m
assert 'var normalized: String = cmd.strip_edges().trim_suffix("。")' in m
assert 'symptomatic_positions' in w
assert 'world.census()' not in m
coverage=json.loads((root/'ILLUSTRATION_COVERAGE.json').read_text())
assert not coverage['missing']
print('v17 contract: PASS')
