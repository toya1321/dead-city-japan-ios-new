from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
w=(root/'scripts/world.gd').read_text()
m=(root/'scripts/main.gd').read_text()
coverage=json.loads((root/'ILLUSTRATION_COVERAGE.json').read_text())
assert int(__import__('re').search(r'const VERSION = ([0-9]+)', w)[1]) >= 22
assert '"home_x"' in w and '"work_x"' in w
assert 'a.destination = "home" if activity == "home" else activity' in w
assert 'destination == "work"' in w
assert 'world.census()' not in m
assert 'func _parse_wait_minutes' in m
assert 'clampi(minutes, 0, 1440)' in w
assert not coverage['missing']
print('v14 static contract PASS')
