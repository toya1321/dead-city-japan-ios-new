extends SceneTree
const Main=preload("res://main.tscn")
var failures:Array[String]=[]
func check(ok:bool,label:String)->void:
	print(("PASS " if ok else "FAIL ")+label)
	if not ok:failures.append(label)
func _initialize()->void:call_deferred("run")
func run()->void:
	root.content_scale_size=Vector2i.ZERO;root.size=Vector2i(1560,720)
	var game=Main.instantiate();root.add_child(game);await process_frame
	var profile:Dictionary=game.world.DEFAULT_PROFILE.duplicate(true);profile.cohabitants=1;profile.companion_names=["同居人"]
	game._start_new_game(profile);game._finish_intro();await process_frame
	for command in ["玄関へ行く","鍵を開ける","外に出る","食品店へ行く","食料を12個買う","食料を12個買う","食料を12個買う","水を12個買う","水を12個買う","金物店へ行く","木材を12個買う","部品を12個買う","種を4個買う","浄水器を買う","ソーラーパネルを買う","蓄電池を買う","薬局へ行く","包帯を3個買う","家に帰る"]:
		var answer:String=game._interpret(command)
		print("PLAY ",command," => ",answer.split("\n")[0])
		check(not answer.contains("まだ正確に") and not answer.contains("足りない") and not answer.contains("処理できない"),"ordinary command "+command)
		check(game.world.validate_state(game.world.s),"valid after "+command)
	check(game.world.s.equipment.filter and game.world.s.equipment.solar and game.world.s.equipment.battery,"all purchased equipment persists")
	game._on_command("玄関を補強");await process_frame
	var before:int=game.world.s.minute;game._on_command("外に出る")
	check(game.location=="玄関" and game.world.s.minute==before,"boards block crossing without time loss")
	game._on_command("玄関の補強を外す");await process_frame
	game._on_command("鍵を開ける");game._on_command("外に出る")
	check(game.location=="屋外","removal restores exit")
	game._on_command("家に帰る");game._on_command("鍵を閉める");game._on_command("台所へ行く")
	game._on_command("プランターを作る");game._on_command("種を植える");game._on_command("水やり")
	check(game.world.s.plots.size()==1 and float(game.world.s.plots[0].water)>1.9,"planting and watering use available home water")
	# All actions through the same command entry point as the UI. No health,
	# food, cash, clock, supplies or infection state is reset during this run.
	for day in range(1,15):
		game._on_command("台所へ行く")
		for meal in range(3):game._on_command("食事する");game._on_command("水を飲む")
		game._on_command("ニュースを見る")
		game._on_command("8時間待つ")
		for meal in range(2):game._on_command("食事する");game._on_command("水を飲む")
		game._on_command("水やり")
		game._on_command("8時間待つ")
		for meal in range(2):game._on_command("食事する");game._on_command("水を飲む")
		game._on_command("寝室へ行く");game._on_command("寝る")
		check(game.world.s.health>0,"living player after daily routine "+str(day))
		check(game.world.validate_state(game.world.s),"consistent world after day "+str(day))
		if day in [1,7,14]:
			check(game._save()=="保存した。","normal play save day "+str(day))
			var exact:PackedByteArray=var_to_bytes(game.world.s)
			check(game._load()=="保存データを読み込んだ。" and var_to_bytes(game.world.s)==exact,"normal play reload day "+str(day))
			print("DAY ",day," clock=",game.world.clock()," health=",game.world.s.health," food=",game.world.s.food," water=",game.world.s.water," NPC=",game.world.census())
		await process_frame
	check(game.world.s.sim.event_counts.size()>10,"daily life naturally includes multiple stateful events")
	check(game.world.s.household_members[0].food_used>0,"cohabitant shares real finite reserves")
	print("NORMAL PLAY22: ",failures.size()," failures")
	game.queue_free();await process_frame
	quit(0 if failures.is_empty() else 1)
