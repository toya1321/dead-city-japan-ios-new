extends SceneTree
const Scene = preload("res://main.tscn")
const World = preload("res://scripts/world.gd")
var failures: Array[String] = []
func check(ok: bool, label: String) -> void:
	print(("PASS " if ok else "FAIL ") + label)
	if not ok: failures.append(label)
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	var game = Scene.instantiate()
	root.add_child(game)
	await process_frame
	game._start_new_game(game.world.DEFAULT_PROFILE.duplicate(true))
	game._finish_intro()
	check(game.location == "寝室" and game.world.s.minute == 0, "new game")
	game._on_command("窓を見る")
	check(game.visual_focus == "window" and game.world.s.minute == 2, "window command and actual image focus")
	check(game.scene_view.context == "window" and game.scene_view.weather == game.world.s.weather, "current window context and weather rendered")
	var focus: String = game.visual_focus
	game._on_command("窓を壊す")
	check(game.visual_focus == focus and game.world.s.minute == 2, "invalid command preserves focus and time")
	game._on_command("ニュースを見る")
	check(game.world.s.minute == 7 and game.observed_news == "新しい報道は確認できない。", "news read caches observed report")
	game._on_command("居間へ移動")
	game._on_command("台所へ移動")
	var food: float = game.world.s.food
	game._on_command("ご飯を食べる")
	check(game.world.s.food < food and game.world.s.minute == 24, "meal consumes food and 15 min")
	game._on_command("30分待つ")
	check(game.world.s.minute == 54, "thirty minute wait")
	for cmd in ["食べない", "ニュースを見る、寝る", "食事してから水を飲む", "水を飲んで30分待つ", "水を飲む？"]:
		var before: String = JSON.stringify(game.world.s)
		game._on_command(cmd)
		check(before == JSON.stringify(game.world.s), "no mutation: " + cmd)
	game._on_command("居間へ移動")
	var money: int = int(game.world.s.cash)
	game._on_command("通販で水を3個注文")
	check(game.world.s.longplay.orders.size() == 1 and game.world.s.cash == money - 540, "online order charged once")
	game._on_command("玄関へ移動")
	var time: int = int(game.world.s.minute)
	game._on_command("窓を見る")
	check(game.world.s.minute == time and game.visual_focus != "window", "impossible observation cannot change visual")
	game._on_command("鍵を開ける")
	game._on_command("外に出る")
	game._on_command("近くの住民を観察")
	check(game.location == "屋外", "NPC observation on street")
	game._on_command("家に戻る")
	game._on_command("鍵を閉める")
	game._on_command("居間へ移動")
	var original: Dictionary = JSON.parse_string(JSON.stringify(game.world.s, "", true, true))
	check(game._save() == "保存した。", "real file save")
	game._on_command("30分待つ")
	check(game._load().contains("読み込んだ"), "real file load")
	check(original == JSON.parse_string(JSON.stringify(game.world.s, "", true, true)), "all world fields restored")
	var second = Scene.instantiate()
	root.add_child(second)
	await process_frame
	check(second._load().contains("読み込んだ"), "new game instance loads persistent file")
	check(original == JSON.parse_string(JSON.stringify(second.world.s, "", true, true)), "new instance state matches")
	game._on_command("1日待つ")
	check(game.world.s.minute == int(original.minute) + 1440, "one day command")
	await game._on_command("7日待つ")
	check(game.world.s.health <= 0 and not game.advancing and game.command_input.editable, "seven day UI wait stops on death and restores input")
	# Corrupt runtime dependencies must be refused before state replacement.
	for field in ["home_x", "destination", "supplies"]:
		var bad: Dictionary = game.world.s.duplicate(true)
		bad.agents[0].erase(field)
		check(not game.world.validate_state(bad), "reject missing NPC field " + field)
	var bad: Dictionary = game.world.s.duplicate(true)
	bad.shops.grocer.stock = null
	check(not game.world.validate_state(bad), "reject corrupt shop")
	bad = game.world.s.duplicate(true)
	bad.vehicles[0].route = 99
	check(not game.world.validate_state(bad), "reject invalid vehicle route")
	var w = World.new()
	w.s.water_online = false
	w.s.water = 0.0
	w.s.rain_water = 10.0
	w.s.thirst = 50.0
	check(not w.can_drink() and not w.drink() and w.s.rain_water == 10.0, "untreated rainwater not used as drinking water")
	# Arrived NPC gets food by conserving finite shop stock.
	var found := false
	for actor in w.s.agents:
		if w.draw(0, int(actor.id), "find-supplies", 10000) < 7500:
			actor.activity = "shopping"
			actor.destination = "shopping"
			actor.x = 20.0
			actor.z = 19.3
			var supply: float = actor.supplies
			var stock: float = w.s.shops.grocer.stock.food
			w.step(false)
			check(is_equal_approx(actor.supplies-supply, 1.5) and is_equal_approx(stock-w.s.shops.grocer.stock.food, 1.5), "arrival exchange conserves food")
			w.step(false)
			check(is_equal_approx(actor.supplies-supply, 1.5), "no repeated arrival payout same day")
			found = true
			break
	check(found, "arrival fixture found")
	# UI geometry at landscape logical sizes, including phone aspect.
	for size in [Vector2i(1280,720),Vector2i(1560,720),Vector2i(1280,590)]:
		root.content_scale_size = Vector2i.ZERO
		root.size = size
		await process_frame
		await process_frame
		var rect: Rect2 = game.command_input.get_global_rect()
		check(rect.end.y <= game.get_viewport_rect().size.y and rect.position.y >= 0, "input within viewport " + str(size))
		check(game.picture.size.y > 50, "illustration visible " + str(size))
	game.queue_free()
	second.queue_free()
	await process_frame
	print("PLAYTHROUGH WORK: ", failures.size(), " failures")
	quit(0 if failures.is_empty() else 1)
