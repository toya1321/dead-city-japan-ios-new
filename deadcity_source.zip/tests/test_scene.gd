extends SceneTree
var fails:=0
var checks:=0
func check(ok: bool,label: String) -> void:
	checks+=1
	if ok: print("PASS: "+label)
	else:
		fails+=1
		push_error("FAIL: "+label)
func walk(game,velocity: Vector3,frames: int) -> void:
	for _i in range(frames):
		await physics_frame
		game.player.velocity=velocity
		game.player.move_and_slide()
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	var game=load("res://main.tscn").instantiate()
	game.persistence_enabled=false
	root.add_child(game)
	await physics_frame
	game.world.reset()
	game.world.s.player_yaw=PI
	game.apply_state()
	game.menu.visible=true
	check(game.actor_nodes.size()==game.world.s.agents.size(),"one render node for each persisted individual")
	game.player.position=Vector3(0,0.2,4)
	await walk(game,Vector3(0,-1,3),90)
	check(game.player.position.z<5.7,"closed front door blocks passage")
	game.world.s.door_open=true
	game.world.s.door_locked=false
	game.apply_doors()
	await physics_frame
	await walk(game,Vector3(0,-1,3),65)
	check(game.player.position.z>6.5 and game.player.position.z<8.8,"opened front door passes; closed gate blocks")
	game.world.s.gate_open=true
	game.world.s.gate_locked=false
	game.apply_doors()
	await physics_frame
	await walk(game,Vector3(0,-1,3),65)
	check(game.player.position.z>9.5,"opened gate permits exterior exploration")
	game.world.s.door_open=false
	game.apply_doors()
	await physics_frame
	check(not game.doors.door.get_child(1).disabled,"door can close again after opening")
	game.player.position=Vector3(5,0.4,5.0)
	await walk(game,Vector3(0,-1,-3),300)
	print("STAIR_POSITION ",game.player.position)
	check(game.player.position.y>3.1 and game.player.position.z< -5.5,"stairs reach second-floor landing")
	await walk(game,Vector3(-3,-1,0),70)
	check(game.player.position.x<3 and game.player.position.y>3.1,"stair landing connects to upstairs floor")
	game.player.position=Vector3(-5,3.4,-2.2)
	game.player.rotation.y=PI
	game.camera.rotation=Vector3(-0.25,0,0)
	await physics_frame
	var target: String=game.ray_target()
	print("TARGET ",target," camera ",game.camera.global_position," basis ",-game.camera.global_basis.z)
	check(target=="pantry","interaction ray reaches solid furniture")
	game.world.s.hunger=30.0
	game.interact()
	check(game.world.s.food<365,"furniture interaction consumes real inventory")
	print("SCENE_TESTS %d checks, %d failures"%[checks,fails])
	game.queue_free()
	await process_frame
	quit(1 if fails else 0)
