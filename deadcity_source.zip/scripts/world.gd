extends RefCounted
# This state never depends on camera visibility, UI queries, or render frames.
# One deterministic minute is the smallest simulation step, including during skips.
const VERSION = 11
const ROUTE = [Vector2(-55,14), Vector2(-20,14), Vector2(0,14), Vector2(25,14), Vector2(55,14), Vector2(55,38), Vector2(0,38), Vector2(-55,38)]
var s: Dictionary
var private_rules: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://assets/private_rules.json"))

func _init() -> void:
	reset()

func reset() -> void:
	s = {"version":VERSION,"minute":0,"seed":481516,"food":837.0,"water":null,"water_used":0.0,"rain_water":0.0,"battery":null,"energy_delta":0.0,"health":100.0,"hunger":0.0,"thirst":0.0,"fatigue":0.0,"injuries":0.0,"exposure":-1,"symptoms_due":-1,"symptomatic":false,"door_open":false,"door_locked":true,"gate_open":false,"gate_locked":true,"window_open":false,"radio":false,"weather":"cloudy","equipment":{"solar":true,"battery":true,"camera":true,"filter":true},"inventory":{"wood":0,"parts":0,"seeds":0,"bandage":0,"planter":0,"harvest":0.0},"plots":[],"barricade":0,"loot_taken":[],"agents":[],"events":[],"noise":[],"player_pos":[0.0,3.35,-2.0],"player_yaw":0.0,"player_pitch":0.0}
	# v10's 135 were a reconstruction, not a historical census. Preserve legacy
	# wanderer separately because the source could not establish overlap.
	for i in range(136):
		var at: int = draw(0,i,"initial",ROUTE.size())
		var v: Vector2 = ROUTE[at]
		var offset: float = float(draw(0,i,"offset",100))/100.0
		s.agents.append({"id":i,"x":v.x+offset,"z":v.y,"route":at,"kind":"symptomatic","health":float(60+draw(0,i,"health",40)),"food":0.0,"exposure":-1,"symptoms_due":-1,"dead":false,"attack_at":-10})
	for i in range(16):
		var v: Vector2 = ROUTE[draw(0,i,"resident-start",ROUTE.size())]
		s.agents.append({"id":136+i,"x":v.x,"z":v.y,"route":draw(0,i,"resident-target",ROUTE.size()),"kind":"survivor","health":100.0,"food":float(14+draw(0,i,"resident-food",14)),"exposure":-1,"symptoms_due":-1,"dead":false,"attack_at":-10})

func draw(t: int, id: int, tag: String, bound: int = 10000) -> int:
	var text := "%s|%s|%s|%s" % [int(s.seed),t,id,tag]
	return int(text.sha256_text().substr(0,7).hex_to_int()) % bound

func advance(minutes: int, sleeping: bool = false) -> void:
	for _i in range(minutes):
		if s.health <= 0:
			break
		step(sleeping)

func step(sleeping: bool) -> void:
	s.minute = int(s.minute) + 1
	var day: int = s.minute / 1440
	var hour: float = fmod(17.0 + float(s.minute)/60.0,24.0)
	if (s.minute+17*60) % 1440 == 0:
		var w := draw(day,0,"weather")
		s.weather = "clear" if w < 4300 else ("cloudy" if w < 7800 else ("rain" if w < 9700 else "snow"))
		for key in s.equipment:
			if draw(day,0,"fault-"+key) < 9:
				s.equipment[key] = false
	var sun: float = maxf(0.0,sin((hour-6.0)/12.0*PI))
	var factor: float = {"clear":0.76,"cloudy":0.3,"rain":0.11,"snow":0.06}[s.weather]
	var generation: float = 800.0 * factor * sun / 60.0 if s.equipment.solar else 0.0
	var load_wh: float = (21.67 + (8.0 if s.radio else 0.0))/60.0
	var delta: float = generation-load_wh
	s.energy_delta += delta
	if s.battery != null and s.equipment.battery:
		s.battery = clampf(float(s.battery)+delta,0.0,7000.0)
	if s.weather == "rain" and s.equipment.filter:
		s.rain_water = minf(200.0,s.rain_water+0.03)
	s.hunger += 100.0/1440.0
	s.thirst += 100.0/1440.0
	s.fatigue = clampf(s.fatigue + (-100.0/480.0 if sleeping else 100.0/1440.0),0.0,100.0)
	if sleeping and s.minute % 60 == 0:
		eat()
		drink()
	if s.hunger > 100 or s.thirst > 100:
		s.health = maxf(0.0,s.health-0.03)
	if s.injuries > 0:
		s.health = maxf(0.0,s.health-0.002*s.injuries)
	if s.exposure >= 0 and s.minute>=int(s.symptoms_due):
		s.symptomatic = true
	if s.symptomatic:
		s.health = maxf(0.0,s.health-0.01)
	for a in s.agents:
		if a.dead:
			continue
		if a.kind == "survivor":
			a.food = maxf(0.0,a.food-1.0/1440.0)
			if a.food == 0:
				a.health -= 0.03
			if a.exposure >= 0 and s.minute>=int(a.symptoms_due):
				a.kind = "symptomatic"
		else:
			a.health -= 0.0014
		if a.health <= 0:
			a.dead = true
			continue
		var pos := Vector2(a.x,a.z)
		var target: Vector2 = ROUTE[int(a.route)]
		var speed: float = 0.7 if a.kind == "symptomatic" else 1.0
		# Only exterior players and actual noises influence nearby agents.
		var pp := Vector2(s.player_pos[0],s.player_pos[2])
		var outside: bool = absf(pp.x)>7.0 or pp.y>6.0 or pp.y < -6.0
		var can_enter: bool = bool(s.door_open) and bool(s.gate_open) and int(s.barricade)==0
		var reachable: bool = outside or (can_enter and float(s.player_pos[1])<2.0)
		var stimulus := false
		if a.kind == "symptomatic" and reachable and pos.distance_to(pp)<10:
			target = pp
			stimulus = true
		for n in s.noise:
			if a.kind == "symptomatic" and pos.distance_to(Vector2(n.x,n.z))<float(n.radius):
				target = Vector2(n.x,n.z)
				stimulus = true
		if a.kind == "survivor":
			for other in s.agents:
				if not other.dead and other.kind == "symptomatic":
					var op := Vector2(other.x,other.z)
					if pos.distance_to(op)<6:
						target = pos + (pos-op).normalized()*8
						break
		# Street network bounds. House walls prevent visual/model divergence.
		var next := pos.move_toward(target,speed)
		var on_road: bool = next.y>=9.0 and next.y<=42.0 and absf(next.x)<=60.0
		var at_gate: bool = absf(next.x)<1.0 and next.y>=6.3 and next.y<9.0 and bool(s.gate_open)
		var in_house: bool = absf(next.x)<1.0 and next.y>=-6.5 and next.y<6.3 and can_enter
		if on_road or at_gate or in_house:
			a.x = next.x
			a.z = next.y
		if pos.distance_to(target)<1.0 and not stimulus:
			a.route = (int(a.route) + (1 if draw(s.minute,a.id,"direction",2)==0 else ROUTE.size()-1))%ROUTE.size()
		if a.kind == "symptomatic" and reachable and float(s.player_pos[1])<2.0 and contact_clear(pos,pp) and pos.distance_to(pp)<1.4 and s.minute-int(a.attack_at)>=3:
			a.attack_at = s.minute
			s.health = maxf(0.0,s.health-7.0)
			s.injuries += 1
			if s.exposure < 0 and draw(s.minute,a.id,"contact")<4200:
				s.exposure = s.minute
				s.symptoms_due = s.minute + incubation(a.id)
		if a.kind == "symptomatic":
			for b in s.agents:
				if b.kind == "survivor" and not b.dead and Vector2(b.x,b.z).distance_to(pos)<1.0:
					if b.exposure < 0 and draw(s.minute,b.id,"contact-%s"%a.id)<180:
						b.exposure = s.minute
						b.symptoms_due = s.minute + incubation(b.id)
	var pending: Array = []
	for n in s.noise:
		if n.until > s.minute:
			pending.append(n)
	s.noise = pending
	for plot in s.plots:
		if plot.water>0:
			plot.growth = minf(1.0,plot.growth+1.0/(14*1440))
			plot.water = maxf(0.0,plot.water-1.0/1440.0)

func eat() -> bool:
	if s.food < 0.25 or s.hunger <= 0:
		return false
	var portion: float = minf(0.25,float(s.hunger)/100.0)
	s.food -= portion
	s.hunger = maxf(0.0,s.hunger-portion*100.0)
	return true

func drink() -> bool:
	if s.thirst <= 0:
		return false
	var liters: float = minf(0.75,float(s.thirst)*3.0/100.0)
	if s.rain_water >= liters:
		s.rain_water -= liters
	elif s.water == null:
		# Preserve source uncertainty; record withdrawal, never fabricate starting stock.
		s.water_used += liters
	elif float(s.water) >= liters:
		s.water -= liters
	else:
		return false
	s.thirst = maxf(0.0,s.thirst-liters*100.0/3.0)
	return true

func action(kind: String) -> String:
	if s.health<=0:
		return "トウヤは死亡した。ロードで保存時点に戻れます。"
	match kind:
		"eat": return "備蓄を食べた。" if eat() else "今は食事不要、または食料不足。"
		"drink": return "水を飲んだ。未計測分の使用量も記録。" if drink() else "飲める水が足りない、または今は不要。"
		"bandage":
			if s.inventory.bandage>0 and s.injuries>0:
				s.inventory.bandage-=1
				s.injuries=maxf(0.0,s.injuries-2)
				return "傷を手当てした。"
			return "包帯がない、または傷がない。"
		"craft":
			if s.inventory.wood<2 or s.inventory.parts<1:
				return "プランター製作：木材2・部品1が必要。"
			s.inventory.wood-=2
			s.inventory.parts-=1
			s.inventory.planter+=1
			advance(30)
			return "プランターを製作した（30分）。"
		"plant":
			if s.inventory.planter<1 or s.inventory.seeds<1:
				return "プランターと種が必要。"
			s.inventory.planter-=1
			s.inventory.seeds-=1
			s.plots.append({"growth":0.0,"water":1.0})
			return "植え付けた。収穫には14日以上と水が必要。"
		"tend":
			if s.plots.is_empty(): return "栽培中の作物はない。"
			if s.rain_water<1.0: return "計量済み雨水が1L必要。"
			s.rain_water-=1.0
			s.plots[0].water+=1.0
			return "最初の鉢に水1Lを与えた。"
		"harvest":
			for plot in s.plots:
				if plot.growth>=1.0:
					plot.growth=0.0
					s.food+=0.5
					s.inventory.harvest+=1.0
					return "収穫した（簡易モデル：食料0.5日分）。"
			return "まだ収穫できない。"
		"fortify":
			if s.inventory.wood<3 or s.inventory.parts<2: return "補強：木材3・部品2が必要。"
			s.inventory.wood-=3
			s.inventory.parts-=2
			s.barricade+=1
			advance(60)
			return "玄関を補強した（60分）。"
	return "操作なし。"

func noise(radius: float) -> void:
	s.noise.append({"x":s.player_pos[0],"z":s.player_pos[2],"radius":radius,"until":s.minute+5})

func attack() -> String:
	noise(18.0)
	var p := Vector2(s.player_pos[0],s.player_pos[2])
	for a in s.agents:
		if not a.dead and p.distance_to(Vector2(a.x,a.z))<2.0 and float(s.player_pos[1])<2.0:
			a.health-=35
			if a.health<=0: a.dead=true
			return "近くの人物に打撃。音が周囲に響いた。"
	return "届く相手がいない。"

func contact_clear(a: Vector2, p: Vector2) -> bool:
	if maxf(a.y,p.y)>=9.0 and minf(a.y,p.y)<9.0 and not s.gate_open: return false
	if maxf(a.y,p.y)>=6.0 and minf(a.y,p.y)<6.0 and (not s.door_open or s.barricade>0): return false
	return true

func incubation(id: int) -> int:
	var limits: Array = private_rules.incubation_hours_range
	var lo: int = int(limits[0])
	var hi: int = int(limits[1])
	return (lo+draw(s.minute,id,"incubation",hi-lo+1))*60

func census() -> Dictionary:
	var r := {"total":s.agents.size(),"living":0,"dead":0,"symptomatic":0,"survivor":0}
	for a in s.agents:
		if a.dead: r.dead+=1
		else:
			r.living+=1
			r[a.kind]+=1
	return r

func save_file(path: String) -> Error:
	var temp := path+".tmp"
	var file := FileAccess.open(temp,FileAccess.WRITE)
	if file==null: return FileAccess.get_open_error()
	file.store_var(s)
	file.flush()
	file.close()
	# Atomic replace on supported platforms, same directory/filesystem.
	return DirAccess.rename_absolute(temp,path)

func load_file(path: String) -> Error:
	var file := FileAccess.open(path,FileAccess.READ)
	if file==null: return ERR_FILE_NOT_FOUND
	var value = file.get_var(false)
	if not value is Dictionary or value.get("version",0)!=VERSION: return ERR_INVALID_DATA
	for key in s:
		if not value.has(key): return ERR_INVALID_DATA
	if not value.agents is Array or not value.player_pos is Array or value.player_pos.size()!=3: return ERR_INVALID_DATA
	s=value
	return OK

func clock() -> String:
	var base := Time.get_unix_time_from_datetime_string("2028-01-22T17:00:00")
	return Time.get_datetime_string_from_unix_time(int(base)+int(s.minute)*60).replace("T"," ").substr(0,16)
