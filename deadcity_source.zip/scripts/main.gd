extends Control
# Text-first UI. The world model advances ONLY when an action consumes time.
const WorldScript = preload("res://scripts/world.gd")
const SAVE_PATH = "user://chronicle_v5.json"
const SAVE_VERSION = 5
const ROOM_LINKS = {"寝室":["居間"],"居間":["寝室","台所","玄関"],"台所":["居間"],"玄関":["居間","屋外"],"屋外":["玄関"]}
var advancing := false
var safe_margin: MarginContainer
var left_scroll: ScrollContainer
var world = WorldScript.new()
var location := "寝室"
var log_entries: Array[String] = []
var picture: TextureRect
var clock_label: Label
var status_label: Label
var story: RichTextLabel
var command_input: LineEdit
var actions_box: HFlowContainer
var backdrop: ColorRect
var scene_caption: Label
var sidebar_status: Label
var world_status: Label
var inventory_status: Label
var view_tabs: HFlowContainer
var main_layout: HBoxContainer
var left_panel: VBoxContainer
var root_scroll: ScrollContainer
var scene_picture_min_height := 260.0
var right_panel: VBoxContainer
var content_column: VBoxContainer
var visual_focus := ""
var event_visual := ""
var known_events: Array[String] = []
var observed_news := "まだ確認していない"
var image_paths := {
	"寝室": "res://assets/illustrations/bedroom.svg",
	"居間": "res://assets/illustrations/living.svg",
	"玄関": "res://assets/illustrations/entrance.svg",
	"屋外": "res://assets/illustrations/street.svg",
	"台所": "res://assets/illustrations/kitchen.svg"
}

func _ready() -> void:
	_build_ui()
	_show_intro()

func _panel(parent: Node, title: String) -> VBoxContainer:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _style(Color("#101b28"), Color("#405b76"), 9))
	parent.add_child(panel)
	var body := VBoxContainer.new()
	body.add_theme_constant_override("separation", 8)
	panel.add_child(body)
	var label := Label.new()
	label.text = title
	label.add_theme_font_size_override("font_size", 16)
	label.add_theme_color_override("font_color", Color("#d9e9fb"))
	body.add_child(label)
	return body

func _style(bg: Color, edge: Color, radius: int = 9) -> StyleBoxFlat:
	var st := StyleBoxFlat.new()
	st.bg_color = bg
	st.border_color = edge
	st.set_border_width_all(1)
	st.set_corner_radius_all(radius)
	st.content_margin_left = 12
	st.content_margin_right = 12
	st.content_margin_top = 10
	st.content_margin_bottom = 10
	return st

func _action_button(parent: Node, label: String, command: String) -> void:
	var btn := Button.new()
	btn.text = label
	btn.custom_minimum_size = Vector2(95, 42)
	btn.add_theme_stylebox_override("normal", _style(Color("#182b40"), Color("#557594")))
	btn.add_theme_stylebox_override("hover", _style(Color("#21466d"), Color("#81b8ed")))
	btn.pressed.connect(_on_command.bind(command))
	parent.add_child(btn)

func _build_ui() -> void:
	var theme_ui := Theme.new()
	theme_ui.default_font = load("res://assets/NotoSansJP-subset.otf") as Font
	theme_ui.default_font_size = 24
	theme = theme_ui
	var bg := ColorRect.new()
	bg.color = Color("#070d15")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	safe_margin = MarginContainer.new()
	safe_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(safe_margin)
	var base := VBoxContainer.new()
	base.add_theme_constant_override("separation", 8)
	safe_margin.add_child(base)
	var header := HBoxContainer.new()
	base.add_child(header)
	var title := Label.new()
	title.text = "DEAD CITY JAPAN  /  CHRONICLE  ·  TEST 19"
	title.add_theme_font_size_override("font_size", 20)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	clock_label = Label.new()
	clock_label.add_theme_font_size_override("font_size", 18)
	header.add_child(clock_label)
	main_layout = HBoxContainer.new()
	main_layout.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_layout.add_theme_constant_override("separation", 10)
	base.add_child(main_layout)
	left_scroll = ScrollContainer.new()
	left_scroll.custom_minimum_size.x = 215
	left_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	main_layout.add_child(left_scroll)
	left_panel = VBoxContainer.new()
	left_panel.custom_minimum_size.x = 195
	left_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left_scroll.add_child(left_panel)
	var vitals := _panel(left_panel, "体調・状態")
	status_label = Label.new()
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vitals.add_child(status_label)
	var supplies := _panel(left_panel, "備蓄・拠点")
	inventory_status = Label.new()
	inventory_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	supplies.add_child(inventory_status)
	var reports := _panel(left_panel, "確認した情報")
	world_status = Label.new()
	world_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	world_status.add_theme_font_size_override("font_size", 16)
	reports.add_child(world_status)
	var tools := HBoxContainer.new()
	left_panel.add_child(tools)
	for item in [{"label":"保存", "key":"save"}, {"label":"読込", "key":"load"}]:
		var button := Button.new()
		button.text = item.label
		button.custom_minimum_size = Vector2(92, 80)
		button.pressed.connect(_utility.bind(str(item.key)))
		tools.add_child(button)
	content_column = VBoxContainer.new()
	content_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content_column.add_theme_constant_override("separation", 8)
	main_layout.add_child(content_column)
	var frame := _panel(content_column, "現在地")
	frame.get_parent().size_flags_vertical = Control.SIZE_EXPAND_FILL
	picture = TextureRect.new()
	picture.custom_minimum_size.y = 145
	picture.size_flags_vertical = Control.SIZE_EXPAND_FILL
	picture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	picture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	frame.add_child(picture)
	scene_caption = Label.new()
	scene_caption.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	scene_caption.add_theme_font_size_override("font_size", 14)
	frame.add_child(scene_caption)
	var story_body := _panel(content_column, "行動記録  /  スクロールで履歴")
	story = RichTextLabel.new()
	story.custom_minimum_size.y = 130
	story.bbcode_enabled = false
	story.scroll_following = true
	story.add_theme_font_size_override("normal_font_size", 22)
	story_body.add_child(story)
	right_panel = VBoxContainer.new()
	right_panel.custom_minimum_size.x = 220
	main_layout.add_child(right_panel)
	var actions := _panel(right_panel, "行動  /  上下にスクロール")
	actions.get_parent().size_flags_vertical = Control.SIZE_EXPAND_FILL
	root_scroll = ScrollContainer.new()
	root_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	actions.add_child(root_scroll)
	actions_box = HFlowContainer.new()
	actions_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions_box.add_theme_constant_override("h_separation", 6)
	actions_box.add_theme_constant_override("v_separation", 8)
	root_scroll.add_child(actions_box)
	var entry_row := HBoxContainer.new()
	base.add_child(entry_row)
	command_input = LineEdit.new()
	command_input.placeholder_text = "行動を入力（例：窓を見る／30分待つ）"
	command_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	command_input.custom_minimum_size.y = 80
	command_input.max_length = 200
	command_input.text_submitted.connect(_on_command)
	entry_row.add_child(command_input)
	var send := Button.new()
	send.text = "実行"
	send.custom_minimum_size = Vector2(110, 80)
	send.pressed.connect(func(): _on_command(command_input.text))
	entry_row.add_child(send)
	get_viewport().size_changed.connect(_update_layout)
	_update_layout()

func _process(_delta: float) -> void:
	# Keyboard and safe area can change without a viewport resize on iOS.
	if OS.has_feature("mobile"):
		_update_layout()

func _update_layout() -> void:
	if main_layout == null: return
	var vp := get_viewport_rect().size
	var scale_factor: float = vp.x / maxf(1.0, float(DisplayServer.window_get_size().x))
	var inset_left := 16
	var inset_right := 16
	var inset_top := 12
	var inset_bottom := 12
	if OS.has_feature("mobile"):
		var safe := DisplayServer.get_display_safe_area()
		var screen := DisplayServer.screen_get_size()
		inset_left = maxi(16, int(safe.position.x * scale_factor))
		inset_right = maxi(16, int((screen.x - safe.end.x) * scale_factor))
		inset_top = maxi(12, int(safe.position.y * scale_factor))
		inset_bottom = maxi(12, int((screen.y - safe.end.y) * scale_factor))
	var keyboard: int = int(DisplayServer.virtual_keyboard_get_height() * scale_factor) if DisplayServer.has_feature(DisplayServer.FEATURE_VIRTUAL_KEYBOARD) else 0
	safe_margin.add_theme_constant_override("margin_left", inset_left)
	safe_margin.add_theme_constant_override("margin_right", inset_right)
	safe_margin.add_theme_constant_override("margin_top", inset_top)
	safe_margin.add_theme_constant_override("margin_bottom", maxi(inset_bottom, keyboard))
	var typing: bool = keyboard > 0
	left_scroll.visible = not typing and vp.x >= 1000
	right_panel.visible = not typing and vp.x >= 1100
	picture.custom_minimum_size.y = 30 if typing else 145
	story.custom_minimum_size.y = 70 if typing else 130

func _apply_font(node: Node, font: Font) -> void:
	if node is Control:
		(node as Control).add_theme_font_override("font", font)
	for child in node.get_children():
		_apply_font(child, font)

func _show_intro() -> void:
	_sync_player_position()
	_append("朝。寝室のカーテン越しに、いつもの街の光が差している。")
	_append("遠くから車の音が聞こえる。現時点で、異変を示す確かな情報はない。")
	_append("何をする？ 行動を文章で入力できる。")
	_refresh()

func _append(line: String) -> void:
	log_entries.append(line)
	if log_entries.size() > 100:
		log_entries.pop_front()
	if story != null:
		story.text = "\n\n".join(log_entries)

func _refresh() -> void:
	clock_label.text = "%s  |  %s" % [world.clock(), location]
	status_label.text = "♥ 体力  %.0f\n♨ 空腹  %.0f\n◆ 渇き  %.0f\n◷ 疲労  %.0f" % [float(world.s.health),float(world.s.hunger),float(world.s.thirst),float(world.s.fatigue)]
	inventory_status.text = "食料   %.1f日分\n飲料水   %.1f L\n雨水   %.1f L\n住居耐久  %.0f" % [float(world.s.food),float(world.s.water),float(world.s.rain_water),float(world.s.longplay.shelter_integrity)]
	world_status.text = "確認した報道\n%s\n\n生存 %d日" % [observed_news,int(world.s.longplay.days_survived)]
	var image_path: String = _scene_path()
	picture.texture = load(image_path) as Texture2D
	scene_caption.text = _scene_caption()
	for child in actions_box.get_children():
		child.queue_free()
	var options: Array[String] = ["周囲を見る", "窓から外を見る", "ニュースを見る", "状態", "持ち物", "近くの住民を観察", "時間を10分進める", "30分待つ", "1日待つ", "7日待つ", "生存記録", "世界の出来事", "配送状況", "1時間休息"]
	match location:
		"寝室": options.append_array(["居間へ移動", "寝る"])
		"居間": options.append_array(["台所へ移動", "玄関へ移動", "寝室へ移動"])
		"台所": options.append_array(["食事する", "水を飲む", "住居を修繕", "浄水する", "プランターを作る", "種を植える", "水やり", "収穫", "居間へ移動"])
		"玄関": options.append_array(["外に出る", "居間へ移動", "鍵を開ける", "鍵を閉める", "玄関を補強"])
		"屋外": options.append_array(["家に戻る", "街を観察する", "物資を探索する"])
	for option in options:
		var b := Button.new()
		b.text = option
		b.disabled = advancing
		b.custom_minimum_size = Vector2(0, 80)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(_on_command.bind(option))
		actions_box.add_child(b)

func _on_command(raw: String) -> void:
	if advancing: return
	var cmd := raw.strip_edges()
	if cmd.is_empty(): return
	command_input.clear()
	_append("▶ " + cmd)
	var multi_day := RegEx.new()
	multi_day.compile("^([2-7])日(?:待つ|待機する|過ごす|進める)$")
	var matched := multi_day.search(cmd.trim_suffix("。"))
	if matched != null:
		advancing = true
		command_input.editable = false
		var total: int = int(matched.get_string(1)) * 1440
		var before: int = int(world.s.minute)
		while int(world.s.minute) - before < total and float(world.s.health) > 0.0:
			world.advance_safe(mini(30, total - (int(world.s.minute) - before)))
			_refresh()
			await get_tree().process_frame
		advancing = false
		command_input.editable = true
		_append("%d分が経過した。%s" % [int(world.s.minute)-before, "死亡のため待機を中止した。" if float(world.s.health) <= 0.0 else ""])
		_refresh()
		return
	_append(_interpret(cmd))
	_refresh()

# A world event is not player knowledge until it is witnessed or reported.
func _event_id(e: Dictionary) -> String:
	return "%d:%s" % [int(e.minute), str(e.kind)]

func _remember_event(e: Dictionary) -> void:
	var id := _event_id(e)
	if not known_events.has(id):
		known_events.append(id)
	if known_events.size() > 240:
		known_events.pop_front()

func _parse_wait_minutes(cmd: String) -> int:
	# Return -1 for unsupported input, -2 for a supported but oversized wait.
	# Anchoring prevents e.g. "水を飲んで30分待つ" from silently waiting.
	var pattern := RegEx.new()
	pattern.compile("^(?:時間を)?([0-9]{1,4})\\s*(分|時間|日)(?:だけ)?(?:待つ|待機する|経過させる|過ごす|進める)$")
	var found := pattern.search(cmd)
	if found == null:
		return -1
	var amount: int = int(found.get_string(1))
	var unit: String = found.get_string(2)
	var minutes: int = amount * (1 if unit == "分" else (60 if unit == "時間" else 1440))
	if minutes <= 0 or minutes > 1440:
		return -2
	return minutes

# Full-command recognition precedes every mutation. Unknown subjects,
# questions, alternatives and compound instructions cannot fall through to
# substring-based execution. This is a bounded Japanese grammar, not an LLM.
func _canonical_command(raw: String) -> String:
	var cmd := raw.strip_edges().trim_suffix("。").replace("　", " ")
	for ending in ["してください", "して下さい", "してほしい"]:
		if cmd.ends_with(ending): cmd = cmd.trim_suffix(ending) + "する"
	var aliases := {
		"窓を見る":"窓から外を見る", "窓の外を見る":"窓から外を見る",
		"外の様子を見る":"窓から外を見る", "ニュースを確認する":"ニュースを見る",
		"テレビを見る":"ニュースを見る", "ご飯を食べる":"食事する",
		"食事をする":"食事する", "食べる":"食事する", "水を飲みたい":"水を飲む",
		"眠る":"寝る", "睡眠を取る":"寝る", "休憩する":"1時間休息",
		"休憩":"1時間休息", "持ち物を確認する":"持ち物", "状態を確認する":"状態",
		"セーブ":"保存", "セーブする":"保存", "保存する":"保存",
		"ロード":"読込", "ロードする":"読込", "読み込む":"読込",
		"NPCを観察する":"近くの住民を観察", "住民を観察する":"近くの住民を観察",
		"家に入る":"家に戻る", "周りを見る":"周囲を見る"
	}
	if aliases.has(cmd): return aliases[cmd]
	var exact := ["周囲を見る", "窓から外を見る", "ニュースを見る", "生存記録", "日誌", "世界の出来事", "出来事の記録", "配送状況", "注文履歴", "1時間休息", "寝る", "食事する", "水を飲む", "持ち物", "状態", "保存", "読込", "近くの住民を観察", "住民を観察", "NPCを観察", "玄関を補強", "住居を修繕", "家を修理", "浄水する", "プランターを作る", "種を植える", "水やり", "水をやる", "収穫", "収穫する", "物資を探索する", "街を観察する", "外に出る", "家に戻る", "鍵を開ける", "鍵を閉める", "施錠する", "傷を手当てする", "買い物する"]
	if cmd in exact: return cmd
	if _parse_wait_minutes(cmd) != -1: return cmd
	var movement := RegEx.new()
	movement.compile("^(寝室|居間|リビング|台所|キッチン|玄関)(へ|に)(移動|移動する|行く|戻る)$")
	var moved := movement.search(cmd)
	if moved != null: return moved.get_string(1) + "へ移動"
	var order := RegEx.new()
	order.compile("^(?:通販で)?(水|飲料水|食料)を([0-9]+)(?:個|箱|セット)注文(?:する)?$")
	var found := order.search(cmd)
	if found != null:
		var quantity: String = found.get_string(2)
		if quantity.length() > 2 or int(quantity) < 1 or int(quantity) > 12: return "invalid_order"
		return "通販で%sを%d個注文" % [found.get_string(1), int(quantity)]
	return ""

func _interpret(raw: String) -> String:
	var cmd := _canonical_command(raw)
	if cmd == "invalid_order": return "注文数は1～12個で指定する。何も注文していない。"
	if cmd.is_empty():
		return "その文章はまだ正確に処理できない。行動・時間・物資は変更していない。一つの行動を具体的に入力して（例：窓を見る／30分待つ）。"
	var before_minute: int = int(world.s.minute)
	var before_location := location
	var response := _execute_command(cmd)
	# Illustration focus changes only after a recognized, successful action.
	if int(world.s.minute) != before_minute or location != before_location:
		if cmd.contains("窓") or cmd == "街を観察する":
			visual_focus = "window"
			event_visual = ""
		elif cmd == "ニュースを見る":
			if visual_focus != "event": visual_focus = "news"
		else:
			if not (cmd == "玄関を補強" and response.begins_with("玄関を補強")):
				visual_focus = ""
				event_visual = ""
	return response

func _execute_command(cmd: String) -> String:
	# The deterministic parser handles ONE action at a time. Never execute
	# the first action of a compound instruction and silently ignore the rest.
	var normalized: String = cmd.strip_edges().trim_suffix("。")
	for separator in ["。", "、", "それから", "そのあと", "続けて", "してから"]:
		if normalized.contains(separator):
			return "複数の行動は一つずつ入力して。今回は何も実行していない。"
	# Safety-first: do not execute an action mentioned in a negative instruction.
	# This is not a complete Japanese-language parser; ambiguous instructions are rejected.
	var negated := ["しない", "しません", "しないで", "するな", "やめて", "待たない", "寝ない", "食べない", "飲まない", "開けない", "閉めない", "注文しない", "買わない", "移動しない", "行かない", "経過させない", "過ごさない"]
	for negative in negated:
		if cmd.contains(negative):
			return "否定の指示を確認した。行動も時間経過も実行していない。"
	if float(world.s.health) <= 0.0 and not (cmd.contains("ロード") or cmd.contains("読込") or cmd.contains("保存") or cmd.contains("セーブ") or cmd.contains("状態")):
		return "死亡している。保存済みの記録を読み込める。"
	if cmd.contains("近くの住民") or cmd.contains("住民を観察") or cmd.contains("NPCを観察"):
		if location != "屋外": return "住民の様子を直接観察するには屋外に出る必要がある。"
		var visible: Array = world.visible_residents()
		if visible.is_empty(): return "見える範囲に人影はない。"
		var lines: Array[String] = []
		for person in visible.slice(0,8):
			lines.append("住民#%d %s：%s（%s）" % [int(person.id),str(person.role),str(person.activity),str(person.condition)])
		return "\n".join(lines)
	if cmd.contains("状態") or cmd.contains("持ち物"):
		return _status_text()
	if cmd.contains("セーブ") or cmd.contains("保存"):
		return _save()
	if cmd.contains("ロード") or cmd.contains("読込"):
		return _load()
	if cmd.contains("生存記録") or cmd.contains("日誌"):
		var journal: Array = world.s.longplay.journal
		var result: Array[String] = []
		for entry in journal.slice(maxi(0,journal.size()-12)):
			result.append("%d日目：%s" % [int(entry.minute/1440),str(entry.text)])
		return "\n".join(result) if not result.is_empty() else "記録はまだない。"
	if cmd.contains("世界の出来事") or cmd.contains("出来事の記録"):
		var items: Array = []
		for e in world.recent_events(240):
			if known_events.has(_event_id(e)):
				items.append(e)
			if items.size() >= 12: break
		if items.is_empty(): return "まだ自分で確認した出来事はない。ニュースや窓から情報を得られる。"
		var lines: Array[String] = []
		for e in items:
			lines.append("%d日目：%s" % [int(e.minute)/1440,str(e.text)])
		event_visual = str(items[0].visual)
		visual_focus = "event"
		return "\n".join(lines)
	if cmd.contains("玄関を補強") or cmd.contains("バリケード"):
		if location != "玄関": return "玄関で作業する必要がある。"
		var response := world.action("fortify")
		if response.begins_with("玄関を補強"):
			event_visual = "shelter"
			visual_focus = "event"
		return response
	if cmd.contains("包帯") or cmd.contains("手当て"):
		var response := world.action("bandage")
		if response.begins_with("傷を手当て"):
			world.advance(10)
		return response
	if cmd.contains("配送状況") or cmd.contains("注文履歴"):
		return world.order_status()
	if cmd.contains("通販") or cmd.contains("注文"):
		if location not in ["寝室", "居間"]: return "注文端末は寝室か居間で操作する。"
		var item := "water" if (cmd.contains("水") or cmd.contains("飲料")) else ("food" if cmd.contains("食料") else "")
		if item.is_empty(): return "注文する物資を指定して。例：通販で水を3個注文"
		var amount := 1
		var pattern := RegEx.new()
		pattern.compile("([0-9]{1,2})\\s*(個|箱|セット)")
		var matched := pattern.search(cmd)
		if matched != null: amount = int(matched.get_string(1))
		return world.place_order(item, amount)
	if cmd.contains("買い物") or cmd.contains("購入"):
		return "店頭購入には店の位置まで移動する必要がある。現在の文章版では商店への移動は未実装。"
	if cmd.contains("1時間休息") or cmd.contains("休憩"):
		return world.longplay_action("rest")
	if cmd.contains("住居を修繕") or cmd.contains("家を修理"):
		if location != "玄関" and location != "台所": return "住居の修繕は玄関か台所から行う。"
		return world.longplay_action("maintain")
	if cmd.contains("浄水"):
		if location != "台所": return "台所で浄水設備を操作する。"
		return world.longplay_action("purify")
	if cmd.contains("物資を探索") or cmd.contains("探索する"):
		if location != "屋外": return "探索には屋外に出る必要がある。"
		return world.longplay_action("scavenge")
	if cmd.contains("プランター") and (cmd.contains("作") or cmd.contains("製作")):
		if location != "台所": return "台所で製作する。"
		return world.action("craft")
	if cmd.contains("種を植") or cmd.contains("植え付"):
		if location != "台所": return "台所で植え付ける。"
		return world.action("plant")
	if cmd.contains("水やり") or cmd.contains("水をやる"):
		if location != "台所": return "台所で水やりをする。"
		var result: String = world.action("tend")
		if result.begins_with("最初の鉢"): world.advance(10)
		return result
	if cmd.contains("収穫"):
		if location != "台所": return "台所で収穫する。"
		var result: String = world.action("harvest")
		if result.begins_with("収穫した"): world.advance(30)
		return result
	# Only a complete, unambiguous wait command advances time. A number in
	# a question or in another action must never trigger a partial action.
	var wait_minutes: int = _parse_wait_minutes(normalized)
	if wait_minutes > 0:
		var elapsed: int = world.advance_safe(wait_minutes)
		return "%d分が経過した。" % elapsed
	if wait_minutes == -2:
		return "一度に進められるのは24時間まで。期間を短く指定して。"
	if cmd.contains("寝る") or cmd.contains("睡眠"):
		if location != "寝室":
			return "寝室に移動する必要がある。"
		var elapsed: int = world.advance_safe(480, true)
		return "%d分眠った。目が覚めると、外の様子も変わっているかもしれない。" % elapsed
	if cmd.contains("食事") or cmd.contains("食べ"):
		if location != "台所":
			return "食事をするには台所へ行こう。"
		if not world.can_eat():
			return "今は食事が不要、または食料が足りない。"
		if not world.eat(): return "食事ができなかった。"
		world.advance(15)
		return "食事を取った。"
	if cmd.contains("水を飲") or cmd.contains("飲み水"):
		if not world.can_drink():
			return "今は水分補給が不要、または飲める水がない。"
		if not world.drink(): return "水を飲めなかった。"
		world.advance(2)
		return "水を飲んだ。"
	if cmd.contains("ニュース") or cmd.contains("テレビ"):
		if not bool(world.s.grid_online): return "停電でテレビを使えない。携帯通信・ラジオ受信の文章操作は未実装。"
		world.advance(5)
		observed_news = str(world.s.last_news)
		var events := world.recent_events(8)
		var headlines: Array[String] = [str(world.s.last_news)]
		var report_visual := ""
		for e in events:
			if str(e.scope) == "regional":
				_remember_event(e)
				headlines.append(str(e.text))
				if report_visual.is_empty(): report_visual = str(e.visual)
			if headlines.size() >= 4: break
		if not report_visual.is_empty():
			event_visual = report_visual
			visual_focus = "event"
		return "\n".join(headlines)
	if cmd.contains("窓") or cmd.contains("街を観察"):
		if location not in ["寝室", "居間", "台所"] and not (location == "屋外" and cmd.contains("街を観察")):
			return "ここからは窓の外を観察できない。"
		world.advance(2)
		# Local records currently have no event coordinates or visibility model.
		# Do not claim a district event was witnessed from this particular window.
		return "窓から通りを観察した。天候: %s。個別の事件の現認判定は未実装。" % str(world.s.weather)

	if cmd.contains("鍵を閉") or cmd.contains("施錠"):
		if location != "玄関": return "玄関にいない。"
		world.s.door_locked = true
		world.s.door_open = false
		world.advance(1)
		return "玄関を閉めて施錠した。"
	if cmd.contains("鍵を開"):
		if location != "玄関":
			return "玄関にいない。"
		world.s.door_locked = false
		world.advance(1)
		return "玄関の鍵を開けた。"
	if cmd.contains("外に出"):
		if location != "玄関":
			return "外に出るには玄関へ移動しよう。"
		if world.s.door_locked:
			return "玄関には鍵がかかっている。"
		location = "屋外"
		visual_focus = ""
		_sync_player_position()
		world.s.door_open = true
		world.advance(1)
		return "家の前に出た。道路には日常の生活音がある。"
	if cmd.contains("家に戻") or cmd.contains("家に入"):
		if location != "屋外":
			return "今は家の外にいない。"
		if world.s.door_locked:
			return "扉が施錠されていて、入れない。"
		location = "玄関"
		visual_focus = ""
		world.s.door_open = false
		_sync_player_position()
		world.advance(1)
		return "玄関に戻った。"
	var destinations := {"寝室":"寝室", "居間":"居間", "リビング":"居間", "台所":"台所", "キッチン":"台所", "玄関":"玄関"}
	for key in destinations:
		if cmd.contains(key) and (cmd.contains("移動") or cmd.contains("行く") or cmd.contains("戻る")):
			if location == "屋外":
				return "まず家に戻る必要がある。"
			var dest: String = destinations[key]
			if dest == location: return "すでに%sにいる。" % location
			if not ROOM_LINKS[location].has(dest):
				return "ここから%sへ直接は行けない。隣の部屋を経由する必要がある。" % dest
			location = dest
			visual_focus = ""
			_sync_player_position()
			world.advance(1)
			return "%sへ移動した。" % location
	if cmd.contains("周囲") or cmd.contains("見回"):
		world.advance(1)
		return _look()
	return "その行動はまだ処理できない。世界の状態や時間は変更していない。"


# Illustration choice is a pure function of current location, observation and
# independently simulated world state. Viewing never changes the outbreak.
func _visual_phase() -> String:
	var society := str(world.s.society)
	var day := int(world.s.minute) / 1440
	if society == "normal" and int(world.s.regional_cases) < 10:
		return "normal"
	if day >= 365 and society != "normal":
		return "overgrown"
	if society == "normal" or society == "alert" or int(world.s.regional_cases) < 200:
		return "alert"
	return "collapse"

func _scene_path() -> String:
	# Existing room JPGs contain smoke, broken cars and parts of other panels.
	# Neutral room placeholders avoid declaring damage to a protected home.
	if visual_focus in ["window", "news"] and location in ["寝室", "居間", "台所"]:
		var path := "res://assets/scenes/window_%s.jpg" % _visual_phase()
		if ResourceLoader.exists(path): return path
	return str(image_paths.get(location, "res://assets/illustrations/bedroom.svg"))

func _scene_caption() -> String:
	var phase := _visual_phase()
	var label: String = {"normal":"平常期", "alert":"異変の兆し", "collapse":"社会機能の崩壊", "overgrown":"長期生存期"}.get(phase, "現在")
	var view: String = "出来事の背景（専用挿絵がない場合は場所の風景）" if visual_focus == "event" else ("窓からの景色" if visual_focus == "window" else ("報道のイメージ" if visual_focus == "news" else location))
	return "背景イメージ（専用挿絵ではない・光や天候は再現しない）\n%s / %s / 天候: %s / 経過 %d日" % [view,label,str(world.s.weather),int(world.s.minute)/1440]

func _sync_player_position() -> void:
	# Existing world simulator uses coordinates to decide whether NPCs can reach the player.
	match location:
		"屋外": world.s.player_pos = [0.0, 1.6, 12.0]
		"玄関": world.s.player_pos = [0.0, 1.6, 2.0]
		_: world.s.player_pos = [0.0, 3.35, -2.0]

func _look() -> String:
	match location:
		"寝室": return "ベッド、カーテン、窓がある。外から車の音が聞こえる。"
		"居間": return "テレビとテーブルがある。台所、寝室、玄関に通じている。"
		"台所": return "食料と飲料水を確認できる。"
		"玄関": return "玄関扉は%s。" % ("施錠中" if world.s.door_locked else "解錠済み")
		"屋外": return "住宅街の通り。空模様は%s。" % world.s.weather
	return ""

func _status_text() -> String:
	return "体力: %.1f / 空腹: %.1f / 渇き: %.1f / 疲労: %.1f\n食料: %.1f日分 / 飲料水: %.1fL / 雨水: %.1fL / 電池: %.1fWh\n現金: %d円\n生存 %d日 / 士気 %.0f / 住居耐久 %.0f / 浄水設備 %.0f" % [float(world.s.health),float(world.s.hunger),float(world.s.thirst),float(world.s.fatigue),float(world.s.food),float(world.s.water),float(world.s.rain_water),float(world.s.battery),int(world.s.cash),int(world.s.longplay.days_survived),float(world.s.longplay.morale),float(world.s.longplay.shelter_integrity),float(world.s.longplay.filter_condition)]

func _save() -> String:
	var payload := {"save_version":SAVE_VERSION,"location":location,"world":world.s,"log":log_entries,"known_events":known_events,"observed_news":observed_news,"world_exact":Marshalls.raw_to_base64(var_to_bytes(world.s))}
	var temp := SAVE_PATH + ".tmp"
	var file := FileAccess.open(temp, FileAccess.WRITE)
	if file == null: return "保存できなかった。"
	file.store_string(JSON.stringify(payload, "", true, true))
	file.flush()
	file.close()
	var err := DirAccess.rename_absolute(ProjectSettings.globalize_path(temp), ProjectSettings.globalize_path(SAVE_PATH))
	return "保存した。" if err == OK else "保存ファイルを確定できなかった。"

func _load() -> String:
	if not FileAccess.file_exists(SAVE_PATH): return "保存データが見つからない。"
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if not (parsed is Dictionary): return "保存データが壊れている。"
	var data: Dictionary = parsed
	if not (data.get("save_version") is int or data.get("save_version") is float): return "セーブ形式が不正。"
	if int(data.get("save_version",-1)) != SAVE_VERSION: return "対応していないセーブ形式。"
	if not data.get("world") is Dictionary or not data.get("log") is Array: return "保存データが不正。"
	if not ROOM_LINKS.has(str(data.get("location",""))): return "保存位置が不正。"
	# New saves preserve the exact Variant numeric types and IEEE float values.
	# Decode with objects disabled; old JSON-only v5 saves remain importable.
	if data.has("world_exact"):
		if not data.world_exact is String or data.world_exact.length() > 4000000: return "精密保存データが不正。"
		var exact = bytes_to_var(Marshalls.base64_to_raw(data.world_exact))
		if not exact is Dictionary: return "精密保存データが壊れている。"
		data.world = exact
	if int(data["world"].get("version",-1)) in [15, 16, 17, 18, 19, 20, 21]:
		var migrated: Dictionary = world.migrate_legacy(data["world"])
		if migrated.is_empty(): return "旧セーブの移行に失敗した。"
		data["world"] = migrated
	if not world.validate_state(data["world"]): return "世界データが不正。"
	if data["log"].size() > 100: return "記録データが大きすぎる。"
	var loaded_log: Array[String] = []
	for line in data["log"]:
		if not line is String or line.length() > 2000: return "記録データが不正。"
		loaded_log.append(line)
	var loaded_known: Array[String] = []
	if data.has("known_events"):
		if not data["known_events"] is Array or data["known_events"].size() > 240: return "既知イベントの記録が不正。"
		for id in data["known_events"]:
			if not id is String or id.length() > 100: return "既知イベントの記録が不正。"
			loaded_known.append(id)
	if not data.get("observed_news", "まだ確認していない") is String: return "報道記録が不正。"
	world.s = data["world"]
	if not world.s.longplay.has("orders"):
		world.s.longplay.orders = []
	observed_news = str(data.get("observed_news", "まだ確認していない"))
	known_events = loaded_known
	location = str(data["location"])
	visual_focus = ""
	_sync_player_position()
	event_visual = ""
	log_entries = loaded_log.slice(maxi(0, loaded_log.size()-100))
	story.text = "\n\n".join(log_entries)
	return "保存データを読み込んだ。"

func _utility(key: String) -> void:
	if advancing: return
	match key:
		"save": _append(_save())
		"load": _append(_load())
		"status": _append(_status_text())
	_refresh()
