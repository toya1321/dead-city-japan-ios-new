extends Node3D
const World = preload("res://scripts/world.gd")
var world = World.new()
var player: CharacterBody3D
var camera: Camera3D
var sun: DirectionalLight3D
var env: WorldEnvironment
var hud: Label
var prompt: Label
var message: Label
var menu: PanelContainer
var status_text: Label
var actor_nodes: Array[Node3D] = []
var doors: Dictionary = {}
var accumulator := 0.0
var yaw := 0.0
var pitch := 0.0
var move_axis := Vector2.ZERO
var left_touch := -1
var right_touch := -1
var touch_origin := Vector2.ZERO
var running := false
var crouching := false
var look_mode := false
var info_mode := false
var inspect_camera := false
var return_pose: Transform3D
var pad: Control
var cross: Label
var rng := RandomNumberGenerator.new()
var frame_count := 0
var labels: Array = []
var loot_boxes: Dictionary = {}
var smoke_test := false

func _ready() -> void:
	rng.seed=372981
	build_environment()
	build_house()
	build_streets()
	build_actors()
	build_player()
	build_ui()
	load_game(false)
	say("2028年1月22日。自宅2階。玄関と門は施錠済み。")
	if "--smoke-test" in OS.get_cmdline_user_args():
		smoke_test=true
		print("SMOKE_READY actors=%s position=%s"%[world.s.agents.size(),player.position])

func material(color: Color, rough: float = 0.9) -> StandardMaterial3D:
	var m:=StandardMaterial3D.new()
	m.albedo_color=color
	m.roughness=rough
	return m

func box(parent: Node3D, pos: Vector3, size: Vector3, color: Color, solid: bool=true, tag: String="") -> Node3D:
	var root: Node3D=StaticBody3D.new() if solid else Node3D.new()
	parent.add_child(root)
	root.position=pos
	if tag!="": root.set_meta("interact",tag)
	var mesh:=MeshInstance3D.new()
	var shape:=BoxMesh.new()
	shape.size=size
	mesh.mesh=shape
	mesh.material_override=material(color)
	root.add_child(mesh)
	if solid:
		var col:=CollisionShape3D.new()
		var bs:=BoxShape3D.new()
		bs.size=size
		col.shape=bs
		root.add_child(col)
	return root

func sign_at(text: String,pos: Vector3,size: int=40, color: Color=Color(0.8,0.9,0.83)) -> void:
	var label:=Label3D.new()
	label.text=text
	label.font=load("res://assets/NotoSansJP-subset.otf")
	label.position=pos
	label.font_size=size
	label.pixel_size=0.007
	label.modulate=color
	label.no_depth_test=false
	add_child(label)

func build_environment() -> void:
	env=WorldEnvironment.new()
	var e:=Environment.new()
	e.background_mode=Environment.BG_COLOR
	e.background_color=Color("435765")
	e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color=Color("b3c1bd")
	e.ambient_light_energy=0.7
	e.tonemap_mode=Environment.TONE_MAPPER_FILMIC
	env.environment=e
	add_child(env)
	sun=DirectionalLight3D.new()
	sun.rotation_degrees=Vector3(-18,-35,0)
	sun.light_color=Color("f8c68f")
	sun.light_energy=1.5
	sun.shadow_enabled=true
	sun.directional_shadow_max_distance=65
	add_child(sun)
	box(self,Vector3(0,-0.3,15),Vector3(150,0.5,115),Color("696e64"))
	for x in [-73.0,73.0]:
		box(self,Vector3(x,4,15),Vector3(1,8,115),Color("34404a"))
	for z in [-42.0,72.0]:
		box(self,Vector3(0,4,z),Vector3(146,8,1),Color("34404a"))

func build_house() -> void:
	var plaster:=Color("c8c5b4")
	var wood:=Color("86765e")
	box(self,Vector3(0,0,-1),Vector3(14,0.2,14),wood)
	box(self,Vector3(-2,3.2,-1),Vector3(10,0.2,14),wood)
	box(self,Vector3(5,3.2,-7),Vector3(4,0.2,2),wood)
	box(self,Vector3(0,6.3,-1),Vector3(14.4,0.3,14.4),Color("c3c0ae"))
	box(self,Vector3(-7,3.1,-1),Vector3(0.25,6.4,14),plaster)
	box(self,Vector3(7,3.1,-1),Vector3(0.25,6.4,14),plaster)
	box(self,Vector3(0,3.1,-8),Vector3(14,6.4,0.25),plaster)
	# Staircase, with a continuous invisible ramp for reliable character motion.
	for i in range(16):
		box(self,Vector3(5,0.1+float(i)*0.1,5.5-float(i)*0.7),Vector3(3.3,0.2+float(i)*0.2,0.7),Color("756956"),false)
	var ramp:=StaticBody3D.new()
	var collision:=CollisionShape3D.new()
	var shape:=BoxShape3D.new()
	shape.size=Vector3(3.3,0.15,11.7)
	collision.shape=shape
	ramp.add_child(collision)
	add_child(ramp)
	ramp.position=Vector3(5,1.63,0.05)
	ramp.rotation.x=atan(3.2/11.2)
	# Front: ground-floor locked door; large upper-floor window.
	for x in [-4.15,4.15]:
		box(self,Vector3(x,1.5,6),Vector3(5.7,3,0.25),plaster)
	box(self,Vector3(0,2.85,6),Vector3(2.6,0.3,0.3),plaster)
	doors.door=box(self,Vector3(0,1.35,6),Vector3(2.5,2.7,0.22),Color("514e46"),true,"door")
	box(self,Vector3(0.8,1.3,5.83),Vector3(0.08,0.1,0.1),Color("c3b589"),false)
	box(self,Vector3(0,3.7,6),Vector3(14,0.8,0.25),plaster)
	box(self,Vector3(0,6.0,6),Vector3(14,0.6,0.25),plaster)
	for x in [-6.6,6.6]:
		box(self,Vector3(x,4.9,6),Vector3(0.8,1.7,0.3),plaster)
	for x in [-3.0,0.0,3.0]:
		box(self,Vector3(x,4.9,6),Vector3(0.06,1.7,0.08),Color("333d3d"))
	doors.window=box(self,Vector3(0,4.95,6),Vector3(12,1.65,0.03),Color(0.35,0.53,0.6,0.13),true,"window")
	var glass: StandardMaterial3D=(doors.window.get_child(0) as MeshInstance3D).material_override
	glass.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
	# Furniture and supplies, all solid/interactable.
	box(self,Vector3(-5,3.6,-5),Vector3(2.8,0.7,1.7),Color("4c6665"),true,"bed")
	box(self,Vector3(-5,3.99,-5),Vector3(2.7,0.12,1.5),Color("80918b"),false)
	box(self,Vector3(-5,4.0,-0.8),Vector3(2.5,1.5,0.8),Color("5d6652"),true,"pantry")
	for i in range(7):
		box(self,Vector3(-6.0+float(i%3)*0.7,4.9+float(i/3)*0.3,-0.8),Vector3(0.5,0.25,0.5),Color("9f8e69"),false)
	box(self,Vector3(-2.0,3.8,2.8),Vector3(2.5,0.15,1.5),Color("9f8765"),true,"table")
	for x in [-2.9,-1.1]:
		box(self,Vector3(x,3.5,2.8),Vector3(0.1,0.6,1.2),wood)
	box(self,Vector3(-2.6,4.05,2.8),Vector3(0.6,0.4,0.35),Color("383f3d"),true,"radio")
	box(self,Vector3(-1.5,4.05,2.8),Vector3(0.65,0.4,0.04),Color("203d3e"),true,"camera")
	box(self,Vector3(-5.5,3.8,3.8),Vector3(1.3,1.0,1),Color("597180"),true,"water")
	box(self,Vector3(0,0.7,-5.6),Vector3(2.2,1.4,0.9),Color("474e47"),true,"power")
	box(self,Vector3(-5,0.8,-5.6),Vector3(2.0,1.6,0.9),Color("7b6a56"),true,"workbench")
	box(self,Vector3(-5,0.45,2),Vector3(3,0.7,2),Color("736969"),true,"bed")
	for x in [-4.3,4.3]:
		box(self,Vector3(x,0.7,9),Vector3(5.8,1.4,0.25),Color("7b8176"))
	doors.gate=box(self,Vector3(0,0.7,9),Vector3(2.8,1.4,0.15),Color("394a49"),true,"gate")
	box(self,Vector3(-4.8,0.3,7.3),Vector3(2.2,0.5,1.2),Color("605742"),true,"garden")
	for i in range(4):
		box(self,Vector3(-4.5+float(i)*2.7,6.6,-2),Vector3(2.4,0.1,3.3),Color("253d53"),false)
	for key in doors:
		var trigger:=Area3D.new()
		trigger.position=doors[key].position
		trigger.set_meta("interact",key)
		var collider:=CollisionShape3D.new()
		var trigger_shape:=BoxShape3D.new()
		trigger_shape.size=Vector3(2.3,2.4,0.35) if key=="door" else (Vector3(2.6,1.4,0.3) if key=="gate" else Vector3(11.8,1.5,0.1))
		collider.shape=trigger_shape
		trigger.add_child(collider)
		add_child(trigger)
	sign_at("自 宅",Vector3(-3,2.3,6.2),30)

func build_streets() -> void:
	for z in [14.0,38.0]:
		box(self,Vector3(0,-0.02,z),Vector3(140,0.06,7.0),Color("343e43"),false)
		for x in range(-60,65,8):
			box(self,Vector3(x,0.03,z),Vector3(3,0.02,0.12),Color("d3c8a0"),false)
	for x in [-55.0,55.0]:
		box(self,Vector3(x,-0.02,26),Vector3(7,0.06,31),Color("343e43"),false)
	for z in [-2.0,26.0,53.0]:
		for x in [-58.0,-40.0,-22.0,20.0,38.0,57.0]:
			var height:=rng.randf_range(5.5,10.0)
			var color:=Color.from_hsv(rng.randf_range(0.08,0.15),rng.randf_range(0.08,0.22),rng.randf_range(0.45,0.72))
			box(self,Vector3(x,height/2,z),Vector3(10,height,12),color)
			box(self,Vector3(x,height+0.3,z),Vector3(10.6,0.6,12.6),Color("4a5050"))
			for level in range(int(height/2.5)):
				for dx in [-2.6,2.6]:
					box(self,Vector3(x+dx,1.5+float(level)*2.5,z-6.05),Vector3(1.8,1.15,0.04),Color("374e58"),false)
			box(self,Vector3(x-2,0.6,z-6.1),Vector3(0.8,1.2,0.4),Color("9ca69e"))
	for x in [-65.0,-30.0,12.0,45.0,65.0]:
		box(self,Vector3(x,4,19),Vector3(0.2,8,0.2),Color("535a55"))
		box(self,Vector3(x,7.5,19),Vector3(2.3,0.12,0.15),Color("535a55"),false)
		box(self,Vector3(x+0.8,7.4,19),Vector3(0.55,0.13,0.4),Color("dbc88b"),false)
	# Fixed caches exist from world initialization; observing never creates them.
	for i in range(8):
		var pos:=Vector3(-46+i*13,0.4,20)
		var crate:=box(self,pos,Vector3(0.9,0.8,0.9),Color("8c805a"),true,"loot:%s"%i)
		loot_boxes[i]=crate
	box(self,Vector3(29,0.5,9.8),Vector3(0.9,1,0.6),Color("b3b8ac"),true,"loot:8")
	sign_at("笹塚 商店街",Vector3(20,3.8,19.8),48)
	sign_at("探索範囲：架空の自宅・周辺街区",Vector3(0,3.4,62),40)
	# Planters/trees are deliberately sparse for mobile performance.
	for x in [-68.0,-8.0,8.0,68.0]:
		box(self,Vector3(x,1.3,23),Vector3(0.35,2.6,0.35),Color("645641"))
		box(self,Vector3(x,3.2,23),Vector3(2.5,2.5,2.5),Color("536654"),false)

func build_actors() -> void:
	for a in world.s.agents:
		var n:=AnimatableBody3D.new()
		n.sync_to_physics=true
		add_child(n)
		var actor_collision:=CollisionShape3D.new()
		var actor_capsule:=CapsuleShape3D.new()
		actor_capsule.radius=0.27
		actor_capsule.height=1.7
		actor_collision.shape=actor_capsule
		actor_collision.position.y=0.85
		n.add_child(actor_collision)
		var col:=Color("746d5c") if a.kind=="symptomatic" else Color("4f7482")
		box(n,Vector3(0,1.0,0),Vector3(0.45,0.7,0.28),col,false)
		box(n,Vector3(0,1.55,0),Vector3(0.3,0.35,0.3),Color("b3a18b"),false)
		for x in [-0.15,0.15]:
			box(n,Vector3(x,0.35,0),Vector3(0.15,0.7,0.18),Color("424b4c"),false)
			box(n,Vector3(x*2,1.0,0.1),Vector3(0.12,0.6,0.15),col,false)
		actor_nodes.append(n)

func build_player() -> void:
	player=CharacterBody3D.new()
	player.floor_snap_length=0.4
	player.floor_max_angle=deg_to_rad(45)
	add_child(player)
	var shape:=CapsuleShape3D.new()
	shape.radius=0.3
	shape.height=1.65
	var collision:=CollisionShape3D.new()
	collision.shape=shape
	collision.position.y=0.85
	player.add_child(collision)
	camera=Camera3D.new()
	camera.position.y=1.5
	camera.fov=78
	camera.far=160
	player.add_child(camera)
	camera.current=true
	player.position=Vector3(0,3.35,-2)
	yaw=PI

func style_button(b: Button) -> void:
	var st:=StyleBoxFlat.new()
	st.bg_color=Color(0.04,0.09,0.11,0.88)
	st.border_color=Color("6b8b84")
	st.set_border_width_all(1)
	st.set_corner_radius_all(7)
	st.content_margin_left=12
	st.content_margin_right=12
	st.content_margin_top=9
	st.content_margin_bottom=9
	b.add_theme_stylebox_override("normal",st)
	b.add_theme_font_size_override("font_size",18)

func make_button(text: String,callback: Callable,parent: Node) -> Button:
	var b:=Button.new()
	b.text=text
	style_button(b)
	b.pressed.connect(callback)
	parent.add_child(b)
	return b

func build_ui() -> void:
	var layer:=CanvasLayer.new()
	add_child(layer)
	var root:=Control.new()
	var theme:=Theme.new()
	theme.default_font=load("res://assets/NotoSansJP-subset.otf")
	root.theme=theme
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter=Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)
	var top:=PanelContainer.new()
	top.position=Vector2(24,18)
	top.size=Vector2(650,82)
	top.mouse_filter=Control.MOUSE_FILTER_IGNORE
	root.add_child(top)
	hud=Label.new()
	hud.add_theme_font_size_override("font_size",19)
	hud.modulate=Color("e4eadc")
	top.add_child(hud)
	var brand:=Label.new()
	brand.text="DEAD CITY\nJAPAN / 2028"
	brand.position=Vector2(1000,20)
	brand.add_theme_font_size_override("font_size",27)
	brand.modulate=Color("d5e0d0")
	root.add_child(brand)
	cross=Label.new()
	cross.text="·"
	cross.position=Vector2(631,340)
	cross.add_theme_font_size_override("font_size",30)
	root.add_child(cross)
	prompt=Label.new()
	prompt.position=Vector2(430,393)
	prompt.size=Vector2(420,35)
	prompt.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(prompt)
	message=Label.new()
	message.position=Vector2(300,550)
	message.size=Vector2(650,70)
	message.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	message.add_theme_font_size_override("font_size",18)
	message.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(message)
	var actions:=HBoxContainer.new()
	actions.position=Vector2(340,654)
	root.add_child(actions)
	make_button("操作 [E]",interact,actions)
	make_button("打撃",func(): say(world.attack()),actions)
	make_button("走る",func(): running=not running,actions)
	make_button("しゃがむ",func(): crouching=not crouching,actions)
	make_button("記録 / 生活",toggle_menu,actions)
	var hint:=Label.new()
	hint.text="左側ドラッグ：移動　右側ドラッグ：視点\nPC：WASD / 右ドラッグ / E操作 / Tab生活"
	hint.position=Vector2(25,650)
	hint.add_theme_font_size_override("font_size",14)
	root.add_child(hint)
	pad=Control.new()
	pad.position=Vector2(50,470)
	pad.size=Vector2(150,150)
	pad.mouse_filter=Control.MOUSE_FILTER_IGNORE
	pad.draw.connect(func():
		pad.draw_circle(Vector2(75,75),65,Color(0.06,0.15,0.17,0.5))
		pad.draw_arc(Vector2(75,75),65,0,TAU,40,Color(0.55,0.7,0.65,0.7),2)
		pad.draw_circle(Vector2(75,75)+move_axis*40,23,Color(0.65,0.78,0.7,0.7)))
	root.add_child(pad)
	menu=PanelContainer.new()
	menu.position=Vector2(260,110)
	menu.size=Vector2(760,490)
	root.add_child(menu)
	var v:=VBoxContainer.new()
	menu.add_child(v)
	var title:=Label.new()
	title.text="生活と記録 / 時間を進めても世界は独立して動く"
	title.add_theme_font_size_override("font_size",22)
	v.add_child(title)
	status_text=Label.new()
	status_text.add_theme_font_size_override("font_size",17)
	v.add_child(status_text)
	for row in [["食事","飲水","手当て","休息8時間"],["待機1時間","籠城1日","セーブ","ロード"],["製作","植付け","水やり","収穫"],["玄関補強","修理","閉じる"]]:
		var h:=HBoxContainer.new()
		v.add_child(h)
		for text in row:
			var t: String=text
			make_button(t,func(): menu_action(t),h)
	menu.visible=false

func menu_action(t: String) -> void:
	match t:
		"閉じる": menu.visible=false
		"セーブ": save_game()
		"ロード": load_game()
		"食事": say(world.action("eat"))
		"飲水": say(world.action("drink"))
		"手当て": say(world.action("bandage"))
		"製作": say(world.action("craft"))
		"植付け": say(world.action("plant"))
		"水やり": say(world.action("tend"))
		"収穫": say(world.action("harvest"))
		"玄関補強": say(world.action("fortify"))
		"修理":
			if world.s.inventory.parts<2: say("修理部品2が必要。")
			else:
				for key in world.s.equipment:
					if not world.s.equipment[key]:
						world.s.inventory.parts-=2
						world.advance(120)
						world.s.equipment[key]=true
						say("設備を修理（2時間）。")
						return
				say("現在、故障設備はない。")
		"休息8時間": skip(480,true)
		"待機1時間": skip(60,false)
		"籠城1日": skip(1440,true)
	update_hud()

func skip(minutes: int,sleeping: bool) -> void:
	if not is_home() or world.s.door_open or world.s.gate_open:
		say("時間スキップは自宅で玄関と門を閉じて行う。")
		return
	sync_player()
	world.advance(minutes,sleeping)
	apply_state()
	say("%s分経過。%s"%[minutes,"生活中に必要な食事と飲水も実行。" if sleeping else ""])
	save_game(false)

func is_home() -> bool:
	return absf(player.position.x)<7 and player.position.z<6 and player.position.z> -8

func toggle_menu() -> void:
	if inspect_camera:
		inspect_camera=false
		camera.transform=return_pose
	menu.visible=not menu.visible
	move_axis=Vector2.ZERO
	update_hud()

func say(text: String) -> void:
	message.text=text

func interact() -> void:
	if inspect_camera:
		inspect_camera=false
		camera.transform=return_pose
		return
	var hit:=ray_target()
	if hit=="":
		say("中央の点を物に合わせて近づく。")
		return
	match hit:
		"door", "gate":
			var opened: String=hit+"_open"
			var locked: String=hit+"_locked"
			if hit=="door" and world.s.barricade>0:
				world.s.barricade-=1
				say("玄関の補強を1つ外した。")
				return
			if world.s[locked]:
				world.s[locked]=false
				say("解錠した。もう一度操作すると開く。")
			else:
				world.s[opened]=not world.s[opened]
				if not world.s[opened]: world.s[locked]=true
				say("開けた。" if world.s[opened] else "閉めて施錠した。")
			apply_doors()
		"window":
			world.s.window_open=not world.s.window_open
			apply_doors()
			say("窓を開けた。" if world.s.window_open else "窓を閉めた。")
		"radio":
			world.s.radio=not world.s.radio
			var active: bool=world.s.radio and world.s.equipment.battery and (world.s.battery==null or world.s.battery>0)
			say("ラジオON：断続的な雑音。受信できる放送はない。" if active else "ラジオOFF、または電力不足。")
		"camera":
			if not world.s.equipment.camera: say("カメラが故障している。")
			else:
				inspect_camera=true
				return_pose=camera.transform
				camera.global_position=Vector3(-5,5.5,5.6)
				camera.global_rotation=Vector3(-0.28,PI,0)
				say("防犯カメラのライブ映像。操作ボタンで戻る。")
		"water": say(world.action("drink"))
		"pantry": say(world.action("eat"))
		"bed": toggle_menu()
		"power": say("太陽光800W / 蓄電池公称7kWh。初期残量は未計測。")
		"workbench", "garden", "table": toggle_menu()
		_:
			if hit.begins_with("loot:"):
				var id:=int(hit.split(":")[1])
				if id in world.s.loot_taken: say("箱は空だ。")
				else:
					world.s.loot_taken.append(id)
					world.s.inventory.wood+=1+id%3
					world.s.inventory.parts+=1
					world.s.inventory.seeds+=1 if id%2==0 else 0
					world.s.inventory.bandage+=1 if id%3==0 else 0
					say("箱を探索：木材・部品などを回収（有限の物資）。")
					world.noise(8)

func ray_target() -> String:
	if inspect_camera: return ""
	var origin:=camera.global_position
	var query:=PhysicsRayQueryParameters3D.create(origin,origin-camera.global_basis.z*3.5)
	query.collide_with_areas=true
	query.exclude=[player.get_rid()]
	var hit:=get_world_3d().direct_space_state.intersect_ray(query)
	if hit.has("collider"):
		return hit.collider.get_meta("interact","")
	return ""

func apply_doors() -> void:
	for tag in ["door","gate","window"]:
		var opened: bool=world.s.window_open if tag=="window" else world.s[tag+"_open"]
		var body: Node3D=doors[tag]
		body.visible=not opened
		body.get_child(1).set_deferred("disabled",opened)

func sync_player() -> void:
	world.s.player_pos=[player.position.x,player.position.y,player.position.z]
	world.s.player_yaw=yaw
	world.s.player_pitch=pitch

func apply_state() -> void:
	player.position=Vector3(world.s.player_pos[0],world.s.player_pos[1],world.s.player_pos[2])
	yaw=world.s.player_yaw
	pitch=world.s.player_pitch
	apply_doors()

func save_game(notify: bool=true) -> void:
	sync_player()
	var result: Error=world.save_file("user://deadcity_v11.save")
	if notify: say("セーブ完了。" if result==OK else "保存できなかった：%s"%result)

func load_game(notify: bool=true) -> void:
	var result: Error=world.load_file("user://deadcity_v11.save")
	if result==OK: apply_state()
	else:
		world.s.player_yaw=PI
		apply_state()
	if notify: say("ロード完了。" if result==OK else "有効なセーブがない。現在の状態を維持。")

func _notification(what: int) -> void:
	if what==NOTIFICATION_APPLICATION_PAUSED and is_instance_valid(player): save_game(false)

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_E: interact()
			KEY_TAB,KEY_ESCAPE: toggle_menu()
			KEY_F5: save_game()
			KEY_F9: load_game()
			KEY_C: crouching=not crouching
			KEY_SPACE: say(world.attack())
	if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_RIGHT:
		look_mode=event.pressed
	if event is InputEventMouseMotion and look_mode and not menu.visible and not inspect_camera:
		yaw-=event.relative.x*0.004
		pitch=clampf(pitch-event.relative.y*0.004,-1.25,1.25)
	if event is InputEventScreenTouch:
		if not event.pressed:
			if event.index==left_touch:
				left_touch=-1
				move_axis=Vector2.ZERO
			if event.index==right_touch: right_touch=-1
		elif not menu.visible and event.position.y<640:
			if event.position.x<400 and left_touch<0:
				left_touch=event.index
				touch_origin=event.position
			elif event.position.x>=400 and right_touch<0: right_touch=event.index
	if event is InputEventScreenDrag and not menu.visible:
		if event.index==left_touch: move_axis=((event.position-touch_origin)/65.0).limit_length()
		if event.index==right_touch and not inspect_camera:
			yaw-=event.relative.x*0.004
			pitch=clampf(pitch-event.relative.y*0.004,-1.25,1.25)

func _physics_process(dt: float) -> void:
	if smoke_test and frame_count>90:
		get_viewport().get_texture().get_image().save_png("user://smoke.png")
		print("SMOKE_DONE image=",ProjectSettings.globalize_path("user://smoke.png"))
		get_tree().quit()
	frame_count+=1
	if not menu.visible and not inspect_camera and world.s.health>0:
		var axis:=move_axis
		if Input.is_physical_key_pressed(KEY_W): axis.y-=1
		if Input.is_physical_key_pressed(KEY_S): axis.y+=1
		if Input.is_physical_key_pressed(KEY_A): axis.x-=1
		if Input.is_physical_key_pressed(KEY_D): axis.x+=1
		var speed:=1.7 if crouching else (5.0 if running or Input.is_physical_key_pressed(KEY_SHIFT) else 3.0)
		if world.s.fatigue>85: speed*=0.6
		var direction:=Basis(Vector3.UP,yaw)*Vector3(axis.x,0,axis.y).limit_length()
		player.velocity.x=direction.x*speed
		player.velocity.z=direction.z*speed
		player.velocity.y-=18.0*dt
		player.move_and_slide()
		player.rotation.y=yaw
		camera.rotation.x=pitch
		camera.position.y=1.05 if crouching else 1.5
		if direction.length()>0.1 and speed>=5.0 and frame_count%45==0:
			sync_player()
			world.noise(14)
			world.s.fatigue=minf(100,world.s.fatigue+0.3)
	if not menu.visible:
		accumulator+=dt
		if accumulator>=1.0:
			accumulator-=1.0
			sync_player()
			world.advance(1)
			if world.s.minute%10==0: save_game(false)
	for i in range(actor_nodes.size()):
		var a: Dictionary=world.s.agents[i]
		var n: Node3D=actor_nodes[i]
		n.position=n.position.lerp(Vector3(a.x,0,a.z),minf(1.0,dt*4)) if frame_count>1 else Vector3(a.x,0,a.z)
		n.get_child(0).set_deferred("disabled",bool(a.dead))
		n.rotation.z=PI/2 if a.dead else 0.0
		n.position.y=0.1 if a.dead else 0.0
		if not a.dead: n.rotation.x=sin(float(frame_count)*0.05+float(i))*0.03
	update_hud()
	pad.queue_redraw()

func update_hud() -> void:
	var s: Dictionary=world.s
	var weather_text: String={"clear":"晴","cloudy":"曇","rain":"雨","snow":"雪"}[s.weather]
	hud.text="  %s  ·  %s  ·  %s\n  体力 %d   空腹 %d   渇き %d   疲労 %d    食料 約%.1f日"%[world.clock(),weather_text,"自宅" if is_home() else "屋外",s.health,s.hunger,s.thirst,s.fatigue,s.food]
	var target:=ray_target()
	var names: Dictionary={"door":"玄関","gate":"門扉","window":"窓","radio":"ラジオ","camera":"防犯カメラ","water":"給水設備","pantry":"備蓄棚","bed":"寝床","table":"生活","power":"電力設備","workbench":"作業台","garden":"栽培"}
	prompt.text="[ 操作 ]  "+names.get(target,"物資箱") if target!="" else ""
	if inspect_camera: prompt.text="防犯カメラ / 操作で戻る"
	var hour: float=fmod(17.0+float(s.minute)/60.0,24.0)
	var daylight: float=maxf(0.0,sin((hour-6.0)/12.0*PI))
	sun.light_energy=daylight*1.8
	sun.rotation_degrees.x=-maxf(6.0,daylight*70)
	env.environment.ambient_light_energy=0.15+daylight*0.65
	env.environment.background_color=Color("101b29").lerp(Color("687e87"),daylight)
	if menu.visible:
		status_text.text="水：未計測 / 使用累計 %.2fL　回収雨水 %.1fL\n蓄電残量：未計測 / 開始後収支 %+.0fWh\n玄関 %s　門 %s　傷 %.0f　症状 %s\n木材%d 部品%d 種%d 包帯%d プランター%d 栽培%d\n初期水量・電池残量は未計測のまま保持しています。\n屋内スキップ中も人物・天候・設備が変化します。"%[s.water_used,s.rain_water,s.energy_delta,"施錠" if s.door_locked else "解錠","施錠" if s.gate_locked else "解錠",s.injuries,"あり" if s.symptomatic else "未確認",s.inventory.wood,s.inventory.parts,s.inventory.seeds,s.inventory.bandage,s.inventory.planter,s.plots.size()]
	if s.health<=0: message.text="トウヤは死亡した。記録メニューからロードできます。"
