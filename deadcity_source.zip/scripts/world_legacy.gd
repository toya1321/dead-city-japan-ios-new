extends RefCounted
# This state never depends on camera visibility, UI queries, or render frames.
# One deterministic minute is the smallest simulation step, including during skips.
const VERSION = 22
const START_TIME = "2026-11-10T08:00:00"
const INITIAL_RESIDENTS = 48
const TRAFFIC_ROUTE = [Vector2(-55,14),Vector2(55,14),Vector2(55,38),Vector2(-55,38)]
const ROUTE = [Vector2(-50,18.5), Vector2(-20,18.5), Vector2(0,18.5), Vector2(25,18.5), Vector2(50,18.5), Vector2(50,33.5), Vector2(0,33.5), Vector2(-50,33.5)]
var s: Dictionary
var private_rules: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://assets/private_rules.json"))

func _init() -> void:
	reset()

func reset() -> void:
	s = {"version":VERSION,"minute":0,"seed":481516,"food":5.0,"water":6.0,"water_used":0.0,"rain_water":0.0,"battery":0.0,"energy_delta":0.0,"health":100.0,"hunger":0.0,"thirst":0.0,"fatigue":0.0,"injuries":0.0,"exposure":-1,"symptoms_due":-1,"symptomatic":false,"door_open":false,"door_locked":true,"gate_open":false,"gate_locked":true,"window_open":false,"radio":false,"weather":"cloudy","equipment":{"solar":false,"battery":false,"camera":false,"filter":false},"inventory":{"wood":0,"parts":0,"seeds":0,"bandage":0,"planter":0,"harvest":0.0},"plots":[],"barricade":0,"loot_taken":[],"agents":[],"events":[],"noise":[],"player_pos":[0.0,3.35,-2.0],"player_yaw":0.0,"player_pitch":0.0,"start_hour":8.0,"grid_online":true,"water_online":true,"solar_w":0.0,"battery_capacity_wh":2000.0,"tap_water_used":0.0,"cash":25000,"bank":250000,"society":"normal","district_food_days":50000.0,"outbreak_pressure":0.0,"regional_cases":0,"last_news":"平常のニュースが続いている。","shops":{
		"grocer":{"name":"食品店","x":20.0,"z":19.3,"stock":{"food":120.0,"water":240.0}},
		"hardware":{"name":"金物店","x":38.0,"z":19.3,"stock":{"wood":40.0,"parts":40.0,"seeds":40.0}},
		"pharmacy":{"name":"薬局","x":-22.0,"z":19.3,"stock":{"bandage":40.0}}},"vehicles":[],"longplay":{"days_survived":0,"morale":75.0,"shelter_integrity":100.0,"filter_condition":100.0,"garden_skill":0,"repair_skill":0,"scavenge_runs":0,"water_collected":0.0,"food_grown":0.0,"journal":[],"milestones":[],"last_daily_event":-1,"orders":[],"population_snapshots":[],"resident_history":[],"household_snapshots":[]}}
	# New game uses the earliest recorded ordinary-life start, not v11's late
	# outbreak reconstruction. These are a finite sample of local passers-by.
	for i in range(INITIAL_RESIDENTS):
		var at: int = i%ROUTE.size()
		var next: int = (at+1)%ROUTE.size()
		var fraction: float = (float(i/ROUTE.size())+0.5)/6.0
		var v: Vector2 = ROUTE[at].lerp(ROUTE[next],fraction)
		s.agents.append({"id":i,"x":v.x,"z":v.y,"route":next,"kind":"survivor","role":["通勤中の人","買い物中の人","近所の住民","配達員"][i%4],"health":100.0,"food":14.0,"exposure":-1,"symptoms_due":-1,"dead":false,"attack_at":-10,"household":i/3,"home_x":-48.0+float((i/3)%8)*13.0,"home_z":38.0,"work_x":-48.0+float(i%8)*13.0,"work_z":18.5,"occupation":["office","retail","delivery","home"][i%4],"activity":"home","destination":"home","supplies":3.0+float(i%6),"trust":50.0,"last_seen":-1,"relations":{},"life_stage":"active","last_history_day":-1,"history_count":0,"last_meal_minute":0,"unfed_days":0})
	# Every household starts with durable ties, independent of the player.
	for a in s.agents:
		for b in s.agents:
			if int(a.id) != int(b.id) and int(a.household) == int(b.household):
				a.relations[str(b.id)] = 65 + draw(0,int(a.id),"household-%s" % int(b.id),20)
	for i in range(3):
		s.vehicles.append({"id":i,"x":-45.0+float(i)*35.0,"z":14.0,"route":1,"heading":-PI/2.0,"speed":3.0+float(i)*0.4})

func draw(t: int, id: int, tag: String, bound: int = 10000) -> int:
	var text := "%s|%s|%s|%s" % [int(s.seed),t,id,tag]
	return int(text.sha256_text().substr(0,7).hex_to_int()) % bound

func advance(minutes: int, sleeping: bool = false) -> void:
	# Bounded work per command; not a fast-forward algorithm.
	for _i in range(clampi(minutes, 0, 1440)):
		if s.health <= 0:
			break
		step(sleeping)


func advance_safe(minutes: int, sleeping: bool = false) -> int:
	# Explicit bounded stepping; caller may use multiple frames for longer waits.
	# Never silently truncate a requested duration to 1440 minutes.
	if minutes < 0 or minutes > 1440:
		return 0
	var start: int = int(s.minute)
	advance(minutes, sleeping)
	return int(s.minute) - start

func advance_days_bounded(days: int, sleeping: bool = false) -> Dictionary:
	# Deterministic chunked simulation; capped to one week per request.
	# Still minute-by-minute, so it is NOT a decades-scale fast-forward.
	if days < 1 or days > 7:
		return {"ok":false,"elapsed":0,"reason":"days must be 1..7"}
	var elapsed: int = 0
	for _day in range(days):
		var advanced: int = advance_safe(1440, sleeping)
		elapsed += advanced
		if advanced < 1440:
			break
	return {"ok":true,"elapsed":elapsed,"stopped":elapsed < days * 1440}

func step(sleeping: bool) -> void:
	s.minute = int(s.minute) + 1
	_update_outbreak()
	if int(s.minute) % 60 == 0:
		_process_orders()
		_update_resident_routines()
	var day: int = s.minute / 1440
	var hour: float = hour_of_day()
	if s.minute % 1440 == 0:
		_daily_longplay()
	if (s.minute+int(s.start_hour)*60) % 1440 == 0:
		var w := draw(day,0,"weather")
		s.weather = _weather_for_day(day)
		for key in s.equipment:
			if draw(day,0,"fault-"+key) < 9:
				s.equipment[key] = false
	var sun: float = maxf(0.0,sin((hour-6.0)/12.0*PI))
	var factor: float = {"clear":0.76,"cloudy":0.3,"rain":0.11,"snow":0.06}[s.weather]
	var generation: float = float(s.solar_w) * factor * sun / 60.0 if s.equipment.solar else 0.0
	var load_wh: float = (21.67 + (8.0 if s.radio else 0.0))/60.0
	var delta: float = generation-(0.0 if s.grid_online else load_wh)
	s.energy_delta += delta
	if s.battery != null and s.equipment.battery:
		s.battery = clampf(float(s.battery)+delta,0.0,float(s.battery_capacity_wh))
	if s.weather == "rain" and s.equipment.filter and float(s.longplay.filter_condition) > 0.0:
		var captured: float = 0.03
		s.rain_water = minf(200.0,s.rain_water+captured)
		s.longplay.water_collected += captured
		s.longplay.filter_condition = maxf(0.0,float(s.longplay.filter_condition)-0.0005)
	s.hunger = minf(100.0, float(s.hunger) + 100.0/1440.0)
	s.thirst = minf(100.0, float(s.thirst) + 100.0/1440.0)
	s.fatigue = clampf(s.fatigue + (-100.0/480.0 if sleeping else 100.0/1440.0),0.0,100.0)
	
	if float(s.fatigue) >= 95.0:
		s.health = maxf(0.0,float(s.health)-0.004)
	if s.hunger >= 100 or s.thirst >= 100:
		s.health = maxf(0.0,s.health-0.03)
	if float(s.longplay.shelter_integrity) <= 0.0 and s.weather in ["rain", "snow"]:
		s.health = maxf(0.0,float(s.health)-0.003)
	if s.injuries > 0:
		s.health = maxf(0.0,s.health-0.002*s.injuries)
	if s.exposure >= 0 and s.minute>=int(s.symptoms_due):
		s.symptomatic = true
	if s.symptomatic:
		s.health = maxf(0.0,s.health-0.01)
	var symptomatic_positions: Array[Vector2] = []
	for actor in s.agents:
		if not actor.dead and actor.kind == "symptomatic":
			symptomatic_positions.append(Vector2(float(actor.x), float(actor.z)))
	var has_symptomatic_agents: bool = not symptomatic_positions.is_empty()
	# Households share finite food. Meals are allocated once per day in a
	# stable resident-ID order, regardless of camera or player observations.
	if int(s.minute) % 1440 == 0:
		_allocate_household_meals()
	for a in s.agents:
		if a.dead or bool(a.get("departed", false)):
			continue
		if a.kind == "survivor":
			if int(a.get("unfed_days", 0)) > 0:
				a.health = maxf(0.0, float(a.health) - 0.018)
			if a.exposure >= 0 and s.minute>=int(a.symptoms_due):
				a.kind = "symptomatic"
		else:
			a.health = maxf(0.0, float(a.health) - 0.0014)
		if a.health <= 0:
			a.dead = true
			a.life_stage = "dead"
			_resident_record(a, "death", "死亡が記録された。")
			continue
		var pos := Vector2(a.x,a.z)
		var target: Vector2 = ROUTE[int(a.route)]
		if a.kind == "survivor":
			var destination: String = str(a.get("destination", "home"))
			if destination == "home" or destination == "shelter":
				target = Vector2(float(a.get("home_x", 0.0)),float(a.get("home_z", 38.0)))
			elif destination == "work":
				target = Vector2(float(a.get("work_x", 0.0)),float(a.get("work_z", 18.5)))
			elif destination in ["shopping", "searching"]:
				target = Vector2(20.0,19.3)
		target = _resident_target(a, target)
		var at_destination: bool = pos.distance_to(target) <= 1.0
		var speed: float = 0.7 if a.kind == "symptomatic" else (0.0 if at_destination else 0.65)
		speed = _resident_speed(a, speed)
		# Only exterior players and actual noises influence nearby agents.
		var pp := Vector2(s.player_pos[0],s.player_pos[2])
		var outside: bool = absf(pp.x)>7.0 or pp.y>6.0 or pp.y < -6.0
		var can_enter: bool = bool(s.door_open) and bool(s.gate_open) and int(s.barricade)==0
		var reachable: bool = outside or (can_enter and float(s.player_pos[1])<2.0)
		var stimulus := false
		if a.kind == "symptomatic" and reachable and pos.distance_to(pp)<10:
			target = pp
			stimulus = true
		for n in s.noise:
			if a.kind == "symptomatic" and pos.distance_to(Vector2(n.x,n.z))<float(n.radius):
				target = Vector2(n.x,n.z)
				stimulus = true
		if a.kind == "survivor" and has_symptomatic_agents:
			for op in symptomatic_positions:
				if pos.distance_to(op) < 6.0:
					target = pos + (pos-op).normalized()*8.0
					break
		# Route by road corridors rather than walking through buildings.
		# Home row z=38, workplace row z=18.5, connector x=50.
		if a.kind == "survivor" and not stimulus and speed > 0.0:
			if absf(pos.y - target.y) > 0.05:
				if absf(pos.x - _road_connector()) > 0.05:
					target = Vector2(_road_connector(), pos.y)
				else:
					target = Vector2(_road_connector(), target.y)
		# Street network bounds. House walls prevent visual/model divergence.
		# A stalled resident must not be teleported to the destination.
		var next := pos.move_toward(target,speed)
		var on_road: bool = next.y>=9.0 and next.y<=42.0 and absf(next.x)<=60.0
		var at_gate: bool = absf(next.x)<1.0 and next.y>=6.3 and next.y<9.0 and bool(s.gate_open)
		var in_house: bool = absf(next.x)<1.0 and next.y>=-6.5 and next.y<6.3 and can_enter
		if on_road or at_gate or in_house:
			a.x = next.x
			a.z = next.y
		_resident_arrived(a, day)
		if pos.distance_to(target)<1.0 and not stimulus and a.kind == "symptomatic":
			a.route = (int(a.route) + (1 if draw(s.minute,a.id,"direction",2)==0 else ROUTE.size()-1))%ROUTE.size()
		if a.kind == "symptomatic" and reachable and float(s.player_pos[1])<2.0 and contact_clear(pos,pp) and pos.distance_to(pp)<1.4 and s.minute-int(a.attack_at)>=3:
			a.attack_at = s.minute
			s.health = maxf(0.0,s.health-7.0)
			s.injuries += 1
			if s.exposure < 0 and draw(s.minute,a.id,"contact")<4200:
				s.exposure = s.minute
				s.symptoms_due = s.minute + incubation(a.id)
		if a.kind == "symptomatic":
			for b in s.agents:
				if b.kind == "survivor" and not b.dead and Vector2(b.x,b.z).distance_to(pos)<1.0:
					if b.exposure < 0 and draw(s.minute,b.id,"contact-%s"%a.id)<180:
						b.exposure = s.minute
						b.symptoms_due = s.minute + incubation(b.id)
	for vehicle in s.vehicles:
		var vp:=Vector2(vehicle.x,vehicle.z)
		var target: Vector2=TRAFFIC_ROUTE[int(vehicle.route)]
		var pp:=Vector2(s.player_pos[0],s.player_pos[2])
		if vp.distance_to(pp)>3.0 or float(s.player_pos[1])>2.0:
			var moved:=vp.move_toward(target,float(vehicle.speed) * _traffic_speed_factor())
			vehicle.x=moved.x
			vehicle.z=moved.y
		if vp.distance_to(target)<1.0:
			vehicle.route=(int(vehicle.route)+1)%TRAFFIC_ROUTE.size()
		var direction: Vector2=target-vp
		if direction.length()>0.01: vehicle.heading=atan2(-direction.x,-direction.y)
	var pending: Array = []
	for n in s.noise:
		if n.until > s.minute:
			pending.append(n)
	s.noise = pending
	for plot in s.plots:
		if plot.water>0:
			plot.growth = minf(1.0,plot.growth+_crop_growth_factor()/(14*1440))
			plot.water = maxf(0.0,plot.water-1.0/1440.0)

# Hidden deterministic outbreak timeline. Independent of player observations.
func _update_outbreak() -> void:
	var minute: int = int(s.minute)
	var day: int = int(minute / 1440)
	if minute % 60 != 0: return
	# The first reports occur after a deterministic delay, not on observation.
	if minute >= 2 * 1440:
		var growth: int = 1 + int(float(s.regional_cases) * 0.12)
		s.regional_cases = mini(100000000, int(s.regional_cases) + growth + draw(day, minute, "regional", 4))
		s.outbreak_pressure = minf(100.0, float(s.regional_cases) / 35.0)
	if s.regional_cases >= 20 and s.society == "normal":
		_record_event("first_reports", "原因不明の体調不良が複数地域で報じられ始めた。", "window_alert")
		s.society = "alert"
		s.last_news = "原因不明の体調不良が複数地域で報じられている。"
	if s.regional_cases >= 150 and s.society == "alert":
		_record_event("transport_breakdown", "交通と配送に広域の遅れが発生した。", "street_alert")
		s.society = "disrupted"
		s.last_news = "交通と配送に遅延。各地で医療機関への問い合わせが増えている。"
	if s.regional_cases >= 800 and s.society == "disrupted":
		_record_event("emergency_declared", "一部地域で移動制限が発表された。", "window_collapse")
		s.society = "emergency"
		s.last_news = "一部地域で移動制限。生活物資の供給が不安定になっている。"
	if s.society == "emergency" and bool(s.grid_online) and draw(day, minute, "grid", 10000) < 90:
		s.grid_online = false
		_record_event("blackout", "地域の電力供給が停止した。", "living_collapse")
	if s.society == "emergency" and bool(s.water_online) and draw(day, minute, "water", 10000) < 65:
		s.water_online = false
		_record_event("water_outage", "地域の水道供給が停止した。", "kitchen_collapse")
	# Local infections follow background prevalence, not player choices.
	if s.society != "normal" and minute % 360 == 0:
		for a in s.agents:
			if not a.dead and a.kind == "survivor" and a.exposure < 0:
				if draw(minute, int(a.id), "background-infection", 10000) < int(s.outbreak_pressure * 1.5):
					a.exposure = minute
					a.symptoms_due = minute + incubation(int(a.id))

# Long-horizon state advances only with simulation time, not observation.
# Daily events are seeded and bounded. No guaranteed rescue or forced encounter.
# Event history is generated from simulation state, never by opening the UI.
# These records are facts of the simulated world, not quests or forced encounters.
func _allocate_household_meals() -> void:
	# A resident can eat from another living household member's inventory.
	# Every unit is deducted exactly once; no food is conjured by this transfer.
	var groups: Dictionary = {}
	for resident in s.agents:
		if bool(resident.dead) or bool(resident.get("departed",false)) or str(resident.kind) != "survivor":
			continue
		var key: int = int(resident.household)
		if not groups.has(key):
			groups[key] = []
		groups[key].append(resident)
	for key in groups:
		var members: Array = groups[key]
		members.sort_custom(func(a, b): return int(a.id) < int(b.id))
		# Rotating meal priority prevents one member always eating first.
		var shift: int = int(s.minute / 1440) % members.size()
		for offset in range(members.size()):
			var eater: Dictionary = members[(offset + shift) % members.size()]
			# A household member can share food only while physically at home.
			var eater_at_home: bool = Vector2(float(eater.x),float(eater.z)).distance_to(Vector2(float(eater.home_x),float(eater.home_z))) <= 2.0
			var donor: Dictionary = {}
			if float(eater.supplies) >= 1.0:
				donor = eater
			else:
				for candidate in members:
					var donor_at_home: bool = Vector2(float(candidate.x),float(candidate.z)).distance_to(Vector2(float(candidate.home_x),float(candidate.home_z))) <= 2.0
					if eater_at_home and donor_at_home and float(candidate.supplies) >= 1.0:
						donor = candidate
						break
			if not donor.is_empty():
				donor.supplies = maxf(0.0, float(donor.supplies) - 1.0)
				eater.unfed_days = 0
				eater.last_meal_minute = int(s.minute)
			else:
				eater.unfed_days = int(eater.get("unfed_days", 0)) + 1
				if int(eater.unfed_days) == 1:
					_resident_record(eater, "shortage", "世帯内の食料が足りず、食事できなかった。")

func household_status(household_id: int) -> Dictionary:
	# Internal world data. UI must not reveal this without player knowledge.
	var members: Array = []
	var total: float = 0.0
	for resident in s.agents:
		if int(resident.household) == household_id:
			members.append(int(resident.id))
			if not bool(resident.dead):
				total += float(resident.supplies)
	return {"household":household_id,"members":members,"food_units":total}

func _update_resident_routines() -> void:
	# Independent hourly routine; querying a resident never advances this state.
	var hour: int = int(hour_of_day())
	var day: int = int(s.minute / 1440)
	for a in s.agents:
		if bool(a.dead) or str(a.kind) != "survivor":
			continue
		var supplies: float = float(a.get("supplies", 0.0))
		var previous: String = str(a.get("activity", "home"))
		var activity := "home"
		if s.society == "normal":
			if hour >= 8 and hour < 18 and str(a.get("occupation", "home")) != "home":
				activity = "work"
			elif hour >= 18 and hour < 20 and int(a.id) % 3 == 0:
				activity = "shopping"
		elif s.society in ["alert", "disrupted"]:
			if supplies < 2.0 and hour >= 9 and hour < 17:
				activity = "searching"
			else:
				activity = "shelter"
		else:
			if supplies < 1.0 and hour >= 7 and hour < 18 and draw(day,int(a.id),"risk",100) < 70:
				activity = "searching"
			else:
				activity = "shelter"
		a.activity = activity
		a.destination = "home" if activity == "home" else activity
		if previous != activity:
			a.last_activity_change = int(s.minute)
			# Avoid recording repetitive daily commutes as life-changing events.
			if activity in ["searching", "shelter"] and previous not in ["searching", "shelter"]:
				_resident_record(a, "routine", "生活状況が変化した：%s" % activity)
	# Aggregate historical snapshots: bounded and stored in save data.
	if hour == 0:
		_update_relationships(day)
		var snapshot := {"day":day,"living":0,"symptomatic":0,"dead":0,"searching":0}
		for resident in s.agents:
			if bool(resident.dead): snapshot.dead += 1
			elif str(resident.kind) == "symptomatic": snapshot.symptomatic += 1
			else:
				snapshot.living += 1
				if str(resident.get("activity", "")) == "searching": snapshot.searching += 1
		s.longplay.population_snapshots.append(snapshot)
		if s.longplay.population_snapshots.size() > 365:
			s.longplay.population_snapshots.pop_front()
		var household_total: float = 0.0
		var household_shortages: int = 0
		var seen: Dictionary = {}
		for resident in s.agents:
			if bool(resident.dead): continue
			var h: int = int(resident.household)
			if seen.has(h): continue
			seen[h] = true
			var status: Dictionary = household_status(h)
			household_total += float(status.food_units)
			if float(status.food_units) < 1.0: household_shortages += 1
		s.longplay.household_snapshots.append({"day":day,"households":seen.size(),"food_units":household_total,"shortages":household_shortages})
		if s.longplay.household_snapshots.size() > 365:
			s.longplay.household_snapshots.pop_front()

# This is a bounded personal history, NOT knowledge automatically given to the player.
func _resident_record(a: Dictionary, kind: String, description: String) -> void:
	var entry := {"minute":int(s.minute),"resident_id":int(a.id),"kind":kind,"text":description}
	s.longplay.resident_history.append(entry)
	if s.longplay.resident_history.size() > 1600:
		s.longplay.resident_history.pop_front()
	a.history_count = int(a.get("history_count",0)) + 1

func _update_relationships(day: int) -> void:
	# Only the local population is simulated. Relationships evolve even unseen.
	for a in s.agents:
		if bool(a.dead) or bool(a.get("departed",false)): continue
		var household: int = int(a.household)
		var group_alive: int = 0
		for b in s.agents:
			if int(b.id) != int(a.id) and int(b.household) == household and not bool(b.dead) and not bool(b.get("departed",false)):
				group_alive += 1
				var key: String = str(b.id)
				var previous: int = int(a.relations.get(key,50))
				var change: int = draw(day,int(a.id),"bond-%s" % key,3)-1
				a.relations[key] = clampi(previous+change,0,100)
		if group_alive == 0 and str(a.life_stage) != "isolated":
			a.life_stage = "isolated"
			_resident_record(a,"isolation","同居する生存者がいなくなった。")
		elif group_alive > 0 and str(a.life_stage) == "isolated":
			a.life_stage = "active"
			_resident_record(a,"reunited","同居する生存者との生活が再開した。")
		# Once every 30 days, preserve a sparse personal snapshot for continuity.
		if day % 30 == 0 and int(a.last_history_day) != day:
			a.last_history_day = day
			_resident_record(a,"monthly","生活記録：%s、備蓄%.1f日。" % [str(a.activity),float(a.supplies)])

func resident_profile(resident_id: int) -> Dictionary:
	# Internal world API; caller must independently enforce whether NPC is known.
	if resident_id < 0 or resident_id >= s.agents.size(): return {}
	var a: Dictionary = s.agents[resident_id]
	var history: Array = []
	for e in s.longplay.resident_history:
		if int(e.resident_id) == resident_id:
			history.append(e.duplicate(true))
	return {"id":int(a.id),"role":str(a.role),"household":int(a.household),"activity":str(a.activity),"life_stage":str(a.life_stage),"history":history.slice(maxi(0,history.size()-20))}

func visible_residents() -> Array:
	# Only physically nearby street residents are observable from the street.
	var result: Array = []
	var pp := Vector2(float(s.player_pos[0]),float(s.player_pos[2]))
	for a in s.agents:
		if bool(a.dead) or bool(a.get("departed",false)): continue
		if Vector2(float(a.x),float(a.z)).distance_to(pp) <= 18.0:
			result.append({"id":int(a.id),"role":str(a.role),"activity":str(a.get("activity","不明")),"condition":"体調が悪そう" if a.kind == "symptomatic" else "外見上は不明","life_stage":str(a.life_stage)})
	return result

func _record_event(kind: String, text: String, visual: String, scope: String = "regional") -> void:
	var record := {"minute":int(s.minute), "kind":kind, "text":text, "visual":visual, "scope":scope}
	s.events.append(record)
	if s.events.size() > 240:
		s.events.pop_front()

func _simulate_daily_events(day: int) -> void:
	# Every roll is a deterministic function of the world seed and calendar day.
	# No event is triggered by observing, reading news, or opening a menu.
	if s.society == "normal":
		if draw(day,0,"normal-commute") < 1100:
			_record_event("commute", "朝の通勤時間帯。街の交通は通常通りに流れている。", "street_normal", "local")
		if draw(day,0,"normal-delivery") < 700:
			_record_event("delivery", "近隣で宅配車両の往来が見られる。", "street_normal", "local")
	elif s.society == "alert":
		if draw(day,0,"clinic") < 3800:
			_record_event("clinic", "地域の医療機関で受診者の増加が報じられた。", "window_alert")
		if draw(day,0,"stock") < 2900:
			_record_event("stock", "一部商品の品薄が報じられた。", "street_alert")
	elif s.society == "disrupted":
		if draw(day,0,"traffic") < 4200:
			_record_event("traffic", "公共交通の運休と遅延が報じられた。", "street_alert")
		if draw(day,0,"supply") < 3800:
			_record_event("supply", "生活物資の配送に広域の遅れが出ている。", "shop_collapse")
	else:
		if draw(day,0,"abandon") < 2200:
			_record_event("abandon", "地域の一部で無人の車両が放置されている。", "street_collapse", "local")
		if draw(day,0,"evacuation") < 2300:
			_record_event("evacuation", "自治体の避難情報が更新された。", "window_collapse")
		if draw(day,0,"fire") < 800:
			_record_event("fire", "遠方の市街地で火災が報告された。", "window_collapse")
	if not bool(s.grid_online) and draw(day,0,"power-report") < 4500:
		_record_event("power", "地域の停電が継続している。", "living_collapse")
	if not bool(s.water_online) and draw(day,0,"water-report") < 4200:
		_record_event("water", "断水の復旧見込みは確認できていない。", "kitchen_collapse")
	if s.weather == "snow" and draw(day,0,"snow") < 2400:
		_record_event("snow", "降雪により道路と屋外の状況が変化している。", "winter", "local")
	if day >= 365 and day % 120 == 0 and s.society == "emergency":
		_record_event("overgrowth", "長期間の管理停止により、空き地や道路脇の植生が広がっている。", "street_overgrown", "local")

func recent_events(limit: int = 8, local_only: bool = false) -> Array:
	var result: Array = []
	for i in range(s.events.size()-1, -1, -1):
		var e: Dictionary = s.events[i]
		if local_only and str(e.get("scope","")) != "local":
			continue
		result.append(e)
		if result.size() >= limit:
			break
	return result

# Orders are reserved and paid for when placed. They do not materialize
# until a simulated delivery time, and can fail when distribution collapses.
func place_order(item: String, quantity: int) -> String:
	if s.society not in ["normal", "alert"]:
		return "配送網が機能しておらず、通販注文を受け付けられない。"
	if quantity < 1 or quantity > 12:
		return "注文数は1～12個で指定する。"
	if item not in ["food", "water"]:
		return "通販で扱うのは食料と飲料水のみ。"
	if not bool(s.grid_online):
		return "停電のため注文端末が使えない。"
	var pending: int = 0
	for order in s.longplay.orders:
		if order.status == "pending": pending += 1
	if pending >= 8:
		return "未配達の注文が多すぎる。"
	var price: int = (850 if item == "food" else 180) * quantity
	if int(s.cash) + int(s.bank) < price:
		return "注文に必要なお金が足りない。"
	while s.longplay.orders.size() >= 256:
		var removed := false
		for i in range(s.longplay.orders.size()):
			if s.longplay.orders[i].status != "pending":
				s.longplay.orders.remove_at(i)
				removed = true
				break
		if not removed: return "注文履歴が満杯。"
	var from_cash: int = mini(int(s.cash), price)
	s.cash -= from_cash
	s.bank -= price - from_cash
	var lead_days: int = 1 + draw(int(s.minute),quantity,"shipping-lead",3)
	if s.society == "alert": lead_days += 2
	var order := {"id":int(s.minute)*100 + s.longplay.orders.size(),"item":item,"quantity":quantity,"price":price,"due":int(s.minute)+lead_days*1440,"status":"pending"}
	s.longplay.orders.append(order)
	advance(5)
	return "%sを%d個注文した（%d円）。配送予定は約%d日後。" % ["食料" if item=="food" else "飲料水",quantity,price,lead_days]

func _process_orders() -> void:
	for order in s.longplay.orders:
		if order.status != "pending" or int(s.minute) < int(order.due): continue
		var blocked: bool = s.society == "emergency" or (s.society == "disrupted" and draw(int(order.id),int(s.minute),"delivery",10000)<8000)
		if blocked:
			order.status = "failed"
			_record_event("delivery_failed", "配送網の混乱により注文品が届かなかった。返金は未処理。", "street_collapse", "local")
		else:
			order.status = "delivered"
			if order.item == "food": s.food += float(order.quantity)
			if order.item == "water": s.water += float(order.quantity)*2.0
			_record_event("delivery_arrived", "玄関先に注文した荷物が届いた。", "entrance_normal" if s.society == "normal" else "entrance_alert", "local")

func order_status() -> String:
	if not s.longplay.has("orders") or s.longplay.orders.is_empty(): return "通販の注文履歴はない。"
	var lines: Array[String] = []
	for order in s.longplay.orders.slice(maxi(0,s.longplay.orders.size()-8)):
		lines.append("%s ×%d / %s" % ["食料" if order.item=="food" else "飲料水",int(order.quantity),str(order.status)])
	return "\n".join(lines)

func _daily_longplay() -> void:
	var lp: Dictionary = s.longplay
	lp.days_survived = int(s.minute / 1440)
	var day: int = int(lp.days_survived)
	if int(lp.last_daily_event) == day: return
	lp.last_daily_event = day
	_simulate_daily_events(day)
	lp.morale = clampf(float(lp.morale) - (0.7 if s.society == "emergency" else 0.15), 0.0, 100.0)
	if s.weather in ["rain", "snow"]:
		lp.shelter_integrity = maxf(0.0,float(lp.shelter_integrity)-0.05)
	if day % 30 == 0:
		_journal("生存記録：%d日目。食料=%.1f人日、水=%.1fL。" % [day,float(s.food),float(s.water)])
	for year in [1, 2, 3, 5, 10, 20]:
		var key: String = "%d年生存" % year
		if day >= year*365 and not lp.milestones.has(key):
			lp.milestones.append(key)
			_journal("節目：%s。" % key)
	# Small, non-scripted maintenance events; no automatic loot or scripted attacks.
	if draw(day,0,"home-wear",10000) < 90:
		lp.shelter_integrity = maxf(0.0,float(lp.shelter_integrity)-0.5)
		_journal("家の設備に経年劣化が見られる。")

func _journal(message: String) -> void:
	var entries: Array = s.longplay.journal
	entries.append({"minute":int(s.minute),"text":message})
	if entries.size() > 600: entries.pop_front()

func longplay_action(kind: String) -> String:
	if float(s.health) <= 0.0: return "死亡しているため行動できない。"
	match kind:
		"rest":
			advance(60,true)
			s.longplay.morale = minf(100.0,float(s.longplay.morale)+0.4)
			return "1時間休息した。"
		"maintain":
			if int(s.inventory.parts) < 1 or int(s.inventory.wood) < 1: return "修繕には部品1と木材1が必要。"
			s.inventory.parts -= 1
			s.inventory.wood -= 1
			advance(120)
			s.longplay.shelter_integrity = minf(100.0,float(s.longplay.shelter_integrity)+15.0)
			s.longplay.repair_skill += 1
			_journal("住居の修繕を行った。")
			return "2時間かけて住居を修繕した。"
		"purify":
			if not bool(s.equipment.filter) or float(s.longplay.filter_condition) < 1.0: return "使用可能な浄水設備がない。"
			if float(s.rain_water) < 1.0: return "雨水が1L必要。"
			s.rain_water -= 1.0
			s.water += 0.8
			s.longplay.filter_condition = maxf(0.0,float(s.longplay.filter_condition)-1.0)
			advance(15)
			return "雨水1Lを処理し、飲料水0.8Lを得た（ゲーム内簡易モデル）。"
		"scavenge":
			if s.society == "normal": return "まだ通常の商店が営業している。探索ではなく購入が必要。"
			if float(s.fatigue) > 85.0: return "疲労が強く探索できない。"
			var attempt: int = int(s.longplay.scavenge_runs)
			var roll: int = draw(int(s.minute),attempt,"scavenge",10000)
			s.longplay.scavenge_runs += 1
			advance(180)
			if float(s.health) <= 0.0: return "探索中に死亡した。"
			if roll < 3600:
				s.inventory.parts += 1
				return "3時間の探索で部品を1つ見つけた。"
			if roll < 6500:
				s.inventory.wood += 2
				return "3時間の探索で木材を2つ見つけた。"
			if roll < 7800:
				s.inventory.seeds += 1
				return "3時間の探索で種を1つ見つけた。"
			return "3時間探索したが、使える物資は見つからなかった。"
	return "未対応の行動。"

func can_eat() -> bool:
	return float(s.food) >= 0.25 and float(s.hunger) > 0.0

func can_drink() -> bool:
	if float(s.thirst) <= 0.0: return false
	var liters: float = minf(0.75, float(s.thirst) * 3.0 / 100.0)
	return bool(s.water_online) or float(s.water) >= liters

# Upgrade v10 worlds without rewriting the player timeline or random seed.
func migrate_legacy(data: Dictionary) -> Dictionary:
	var old_version: int = int(data.get("version", -1))
	if old_version not in [15, 16, 17, 18, 19, 20, 21]: return {}
	if not data.get("longplay") is Dictionary or not data.get("agents") is Array: return {}
	var migrated: Dictionary = data.duplicate(true)
	migrated.version = VERSION
	if not migrated.longplay.has("household_snapshots"):
		migrated.longplay.household_snapshots = []
	if old_version == 15:
		migrated.longplay.resident_history = []
	for a in migrated.agents:
		if not a is Dictionary: return {}
		if old_version == 15:
			a.relations = {}
			a.life_stage = "dead" if bool(a.get("dead", false)) else "active"
			a.last_history_day = -1
			a.history_count = 0
		if not a.has("home_x"): a.home_x = -48.0+float((int(a.id)/3)%8)*13.0
		if not a.has("home_z"): a.home_z = 38.0
		if not a.has("work_x"): a.work_x = -48.0+float(int(a.id)%8)*13.0
		if not a.has("work_z"): a.work_z = 18.5
		if not a.has("destination"): a.destination = str(a.get("activity", "home"))
		if not a.has("last_meal_minute"): a.last_meal_minute = int(migrated.minute)
		if not a.has("unfed_days"): a.unfed_days = 0
	if old_version == 15:
		for a in migrated.agents:
			for b in migrated.agents:
				if int(a.get("id", -1)) != int(b.get("id", -1)) and int(a.get("household", -1)) == int(b.get("household", -2)):
					a.relations[str(b.id)] = 65
	return migrated if validate_state(migrated) else {}

func migrate_v10(data: Dictionary) -> Dictionary:
	return migrate_legacy(data)

func validate_state(data: Dictionary) -> bool:
	if not (data.get("version") is int or data.get("version") is float): return false
	if int(data.version) != VERSION: return false
	for key in ["version", "minute", "seed", "food", "water", "rain_water", "battery", "health", "hunger", "thirst", "fatigue", "injuries", "exposure", "symptoms_due", "symptomatic", "door_open", "door_locked", "gate_open", "gate_locked", "window_open", "radio", "weather", "equipment", "inventory", "plots", "barricade", "loot_taken", "agents", "events", "noise", "player_pos", "player_yaw", "player_pitch", "start_hour", "grid_online", "water_online", "solar_w", "battery_capacity_wh", "tap_water_used", "cash", "bank", "society", "district_food_days", "outbreak_pressure", "regional_cases", "last_news", "shops", "vehicles", "longplay", "water_used", "energy_delta"]:
		if not data.has(key): return false
	for key in ["minute", "seed", "cash", "bank", "regional_cases", "barricade"]:
		if not (data[key] is int or data[key] is float): return false
		if float(data[key]) < 0.0 or float(data[key]) > 1000000000.0: return false
	for key in ["food", "water", "rain_water", "battery", "health", "hunger", "thirst", "fatigue", "injuries", "outbreak_pressure", "district_food_days", "water_used", "tap_water_used"]:
		if not (data[key] is int or data[key] is float): return false
		if not is_finite(float(data[key])): return false
		if float(data[key]) < 0.0 or float(data[key]) > 1000000000.0: return false
	for key in ["health", "hunger", "thirst", "fatigue", "outbreak_pressure"]:
		if float(data[key]) > 100.0: return false
	for key in ["door_locked", "door_open", "grid_online", "water_online", "symptomatic", "gate_open", "gate_locked", "window_open", "radio"]:
		if not data[key] is bool: return false
	for key in ["agents", "vehicles", "plots", "noise", "events", "loot_taken", "player_pos"]:
		if not data[key] is Array: return false
	if data.player_pos.size() != 3: return false
	for pos in data.player_pos:
		if not (pos is int or pos is float): return false
		if not is_finite(float(pos)) or absf(float(pos)) > 10000.0: return false
	if not data.equipment is Dictionary or not data.inventory is Dictionary or not data.shops is Dictionary: return false
	if not data.longplay is Dictionary: return false
	for key in s.longplay:
		if key == "orders": continue
		if not data.longplay.has(key): return false
	for key in ["morale", "shelter_integrity", "filter_condition"]:
		if not (data.longplay[key] is int or data.longplay[key] is float): return false
		if not is_finite(float(data.longplay[key])) or float(data.longplay[key]) < 0.0 or float(data.longplay[key]) > 100.0: return false
	for key in ["days_survived", "garden_skill", "repair_skill", "scavenge_runs", "last_daily_event"]:
		if not (data.longplay[key] is int or data.longplay[key] is float): return false
		if float(data.longplay[key]) < -1.0 or float(data.longplay[key]) > 1000000000.0: return false
	for key in ["water_collected", "food_grown"]:
		if not (data.longplay[key] is int or data.longplay[key] is float): return false
		if not is_finite(float(data.longplay[key])) or float(data.longplay[key]) < 0.0: return false
	if not data.longplay.journal is Array or not data.longplay.milestones is Array: return false
	if not data.longplay.get("population_snapshots", []) is Array: return false
	if not data.longplay.get("household_snapshots", []) is Array: return false
	if data.longplay.household_snapshots.size() > 365: return false
	if not data.longplay.get("resident_history", []) is Array: return false
	if data.longplay.resident_history.size() > 1600: return false
	for entry in data.longplay.resident_history:
		if not entry is Dictionary: return false
		if not (entry.get("minute") is int or entry.get("minute") is float): return false
		if int(entry.minute) < 0 or int(entry.minute) > int(data.minute): return false
		if not (entry.get("resident_id") is int or entry.get("resident_id") is float): return false
		if int(entry.resident_id) < 0 or int(entry.resident_id) >= data.agents.size(): return false
		if not entry.get("kind") is String or not entry.get("text") is String: return false
		if str(entry.text).length() > 500: return false
	if data.longplay.population_snapshots.size() > 365: return false
	if data.longplay.has("orders"):
		if not data.longplay.orders is Array or data.longplay.orders.size() > 2000: return false
		for order in data.longplay.orders:
			if not order is Dictionary: return false
			if str(order.get("status", "")) not in ["pending", "delivered", "failed"]: return false
			if str(order.get("item", "")) not in ["food", "water"]: return false
			for key in ["id", "quantity", "price", "due"]:
				if not (order.get(key) is int or order.get(key) is float): return false
				if float(order[key]) < 0.0 or float(order[key]) > 1000000000.0: return false
	if data.longplay.journal.size() > 600 or data.longplay.milestones.size() > 100: return false
	for key in s.equipment:
		if not data.equipment.has(key) or not data.equipment[key] is bool: return false
	for key in s.inventory:
		if not data.inventory.has(key) or not (data.inventory[key] is int or data.inventory[key] is float): return false
		if float(data.inventory[key]) < 0.0: return false
	if data.agents.size() > 10000 or data.vehicles.size() > 1000: return false
	for actor in data.agents:
		if not actor is Dictionary: return false
		for key in ["id", "x", "z", "route", "health", "food", "exposure", "symptoms_due", "attack_at"]:
			if not actor.has(key) or not (actor[key] is int or actor[key] is float): return false
		for key in ["dead", "kind"]:
			if not actor.has(key): return false
		if not actor.dead is bool or not actor.kind in ["survivor", "symptomatic"]: return false
		if int(actor.route) < 0 or int(actor.route) >= ROUTE.size(): return false
		if not actor.get("activity", "") is String or str(actor.activity) not in ["home", "work", "shopping", "searching", "shelter", "rest", "clinic", "park", "boundary", "farm"]: return false
		if not actor.get("occupation", "") is String: return false
		if not actor.get("relations", null) is Dictionary: return false
		if not actor.get("life_stage", "") is String or str(actor.life_stage) not in ["active","isolated","dead"]: return false
		if not (actor.get("household") is int or actor.get("household") is float): return false
		if not (actor.get("last_history_day") is int or actor.get("last_history_day") is float): return false
		if not (actor.get("history_count") is int or actor.get("history_count") is float): return false
		for relation_id in actor.relations:
			if not (actor.relations[relation_id] is int or actor.relations[relation_id] is float): return false
			if float(actor.relations[relation_id]) < 0.0 or float(actor.relations[relation_id]) > 100.0: return false
		for extra in ["last_meal_minute", "unfed_days"]:
			if not (actor.get(extra) is int or actor.get(extra) is float): return false
			if float(actor[extra]) < 0.0 or float(actor[extra]) > 1000000000.0: return false
		if not (actor.get("supplies") is int or actor.get("supplies") is float): return false
		if not is_finite(float(actor.supplies)) or float(actor.supplies) < 0.0 or float(actor.supplies) > 1000.0: return false
	for vehicle in data.vehicles:
		if not vehicle is Dictionary: return false
		for key in ["x", "z", "route", "speed", "heading"]:
			if not vehicle.has(key) or not (vehicle[key] is int or vehicle[key] is float): return false
		if int(vehicle.route) < 0 or int(vehicle.route) >= TRAFFIC_ROUTE.size(): return false
	if not data.society in ["normal", "alert", "disrupted", "emergency"]: return false
	for key in ["start_hour", "solar_w", "battery_capacity_wh", "energy_delta", "player_yaw", "player_pitch", "exposure", "symptoms_due"]:
		if not _finite_number(data.get(key)): return false
	for actor in data.agents:
		for key in ["id", "x", "z", "health", "food", "exposure", "symptoms_due", "attack_at", "home_x", "home_z", "work_x", "work_z", "supplies", "trust", "household", "last_meal_minute", "unfed_days"]:
			if not _finite_number(actor.get(key)): return false
		if float(actor.supplies) < 0 or float(actor.health) < 0: return false
		if actor.has("last_supply_day") and not _finite_number(actor.last_supply_day): return false
		if str(actor.get("destination", "")) not in ["home", "work", "shopping", "searching", "shelter", "rest", "clinic", "park", "boundary", "farm"]: return false
	for vehicle in data.vehicles:
		if not vehicle is Dictionary: return false
		for key in ["id", "x", "z", "route", "heading", "speed"]:
			if not _finite_number(vehicle.get(key)): return false
		if int(vehicle.route) < 0 or int(vehicle.route) >= TRAFFIC_ROUTE.size(): return false
	for plot in data.plots:
		if not plot is Dictionary: return false
		if not _finite_number(plot.get("growth")) or not _finite_number(plot.get("water")): return false
		if float(plot.growth) < 0 or float(plot.growth) > 1 or float(plot.water) < 0: return false
	for entry in data.noise:
		if not entry is Dictionary: return false
		for key in ["x", "z", "radius", "until"]:
			if not _finite_number(entry.get(key)): return false
	for shop_id in ["grocer", "hardware", "pharmacy"]:
		var shop = data.shops.get(shop_id)
		if not shop is Dictionary or not shop.get("stock") is Dictionary: return false
		if not _finite_number(shop.get("x")) or not _finite_number(shop.get("z")): return false
		for key in s.shops[shop_id].stock:
			if not _finite_number(shop.stock.get(key)) or float(shop.stock[key]) < 0: return false
	if not data.weather in ["clear", "cloudy", "rain", "snow"]: return false
	if not data.last_news is String or data.last_news.length() > 2000: return false
	if bool(data.door_locked) and bool(data.door_open): return false
	if data.noise.size() > 10000 or data.plots.size() > 10000 or data.events.size() > 240: return false
	for e in data.events:
		if not e is Dictionary: return false
		if not (e.get("minute") is int or e.get("minute") is float): return false
		if float(e.minute) < 0.0 or float(e.minute) > float(data.minute): return false
		for field in ["kind", "text", "visual", "scope"]:
			if not e.get(field) is String or str(e[field]).length() > 500: return false
	return true

func _finite_number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))

func eat() -> bool:
	if not can_eat():
		return false
	var portion: float = minf(0.25,float(s.hunger)/100.0)
	s.food -= portion
	s.hunger = maxf(0.0,s.hunger-portion*100.0)
	return true

func drink() -> bool:
	if not can_drink():
		return false
	var liters: float = minf(0.75,float(s.thirst)*3.0/100.0)
	if s.water_online:
		s.tap_water_used+=liters
	elif float(s.water) >= liters:
		s.water -= liters
	else:
		return false
	s.water_used += liters
	s.thirst = maxf(0.0,s.thirst-liters*100.0/3.0)
	return true

func action(kind: String) -> String:
	if s.health<=0:
		return "トウヤは死亡した。ロードで保存時点に戻れます。"
	match kind:
		"eat": return "備蓄を食べた。" if eat() else "今は食事不要、または食料不足。"
		"drink": return "水を飲んだ。未計測分の使用量も記録。" if drink() else "飲める水が足りない、または今は不要。"
		"bandage":
			if s.inventory.bandage>0 and s.injuries>0:
				s.inventory.bandage-=1
				s.injuries=maxf(0.0,s.injuries-2)
				return "傷を手当てした。"
			return "包帯がない、または傷がない。"
		"craft":
			if s.inventory.wood<2 or s.inventory.parts<1:
				return "プランター製作：木材2・部品1が必要。"
			s.inventory.wood-=2
			s.inventory.parts-=1
			s.inventory.planter+=1
			advance(30)
			return "プランターを製作した（30分）。"
		"plant":
			if s.inventory.planter<1 or s.inventory.seeds<1:
				return "プランターと種が必要。"
			s.inventory.planter-=1
			s.inventory.seeds-=1
			s.plots.append({"growth":0.0,"water":1.0})
			return "植え付けた。収穫には14日以上と水が必要。"
		"tend":
			if s.plots.is_empty(): return "栽培中の作物はない。"
			if s.rain_water<1.0: return "計量済み雨水が1L必要。"
			s.rain_water-=1.0
			s.plots[0].water+=1.0
			return "最初の鉢に水1Lを与えた。"
		"harvest":
			for plot in s.plots:
				if plot.growth>=1.0:
					plot.growth=0.0
					s.food+=0.5
					s.inventory.harvest+=1.0
					return "収穫した（簡易モデル：食料0.5日分）。"
			return "まだ収穫できない。"
		"fortify":
			if s.inventory.wood<3 or s.inventory.parts<2: return "補強：木材3・部品2が必要。"
			s.inventory.wood-=3
			s.inventory.parts-=2
			s.barricade+=1
			s.longplay.repair_skill+=1
			advance(60)
			return "玄関を補強した（60分）。"
	return "操作なし。"

func noise(radius: float) -> void:
	s.noise.append({"x":s.player_pos[0],"z":s.player_pos[2],"radius":radius,"until":s.minute+5})

func attack() -> String:
	noise(18.0)
	var p := Vector2(s.player_pos[0],s.player_pos[2])
	for a in s.agents:
		if not a.dead and p.distance_to(Vector2(a.x,a.z))<2.0 and float(s.player_pos[1])<2.0:
			a.health-=35
			if a.health<=0:
				a.dead=true
				a.life_stage="dead"
				_resident_record(a,"death","外傷により死亡した。")
			return "近くの人物に打撃。音が周囲に響いた。"
	return "届く相手がいない。"

func contact_clear(a: Vector2, p: Vector2) -> bool:
	if maxf(a.y,p.y)>=9.0 and minf(a.y,p.y)<9.0 and not s.gate_open: return false
	if maxf(a.y,p.y)>=6.0 and minf(a.y,p.y)<6.0 and (not s.door_open or s.barricade>0): return false
	return true

func incubation(id: int) -> int:
	var limits: Array = private_rules.incubation_hours_range
	var lo: int = int(limits[0])
	var hi: int = int(limits[1])
	return (lo+draw(s.minute,id,"incubation",hi-lo+1))*60

func census() -> Dictionary:
	var r := {"total":s.agents.size(),"living":0,"dead":0,"symptomatic":0,"survivor":0}
	for a in s.agents:
		if a.dead: r.dead+=1
		else:
			r.living+=1
			r[a.kind]+=1
	return r

func save_file(path: String) -> Error:
	if not validate_state(s): return ERR_INVALID_DATA
	var temp := path+".tmp"
	var file := FileAccess.open(temp,FileAccess.WRITE)
	if file==null: return FileAccess.get_open_error()
	file.store_var(s)
	file.flush()
	file.close()
	# Atomic replace on supported platforms, same directory/filesystem.
	return DirAccess.rename_absolute(temp,path)

func load_file(path: String) -> Error:
	var file := FileAccess.open(path,FileAccess.READ)
	if file==null: return ERR_FILE_NOT_FOUND
	var value = file.get_var(false)
	if not value is Dictionary: return ERR_INVALID_DATA
	if int(value.get("version", -1)) in [15, 16, 17, 18, 19, 20, 21]:
		value = migrate_legacy(value)
	if not validate_state(value): return ERR_INVALID_DATA
	s=value
	return OK

func clock() -> String:
	var base := Time.get_unix_time_from_datetime_string(START_TIME)
	return Time.get_datetime_string_from_unix_time(int(base)+int(s.minute)*60).replace("T"," ").substr(0,16)

func hour_of_day() -> float:
	return fmod(float(s.start_hour)+float(s.minute)/60.0,24.0)

func shops_open() -> bool:
	return s.society=="normal" and hour_of_day()>=8.0 and hour_of_day()<21.0

func buy(shop_id: String,item: String) -> String:
	if not s.shops.has(shop_id): return "店が見つからない。"
	var shop: Dictionary=s.shops[shop_id]
	if not shops_open(): return "営業時間は8時から21時です。"
	if Vector2(s.player_pos[0]-shop.x,s.player_pos[2]-shop.z).length()>4.0 or float(s.player_pos[1])>2.0:
		return "店頭に近づいてください。"
	if not shop.stock.has(item): return "この店では扱っていません。"
	var prices: Dictionary={"food":600,"water":120,"wood":500,"parts":800,"seeds":200,"bandage":300}
	var amount: float=2.0 if item=="water" else 1.0
	var price: int=prices[item]
	if shop.stock[item]<amount: return "売り切れです。"
	if s.cash+s.bank<price: return "所持金が足りない。"
	var from_cash: int=mini(int(s.cash),price)
	s.cash-=from_cash
	s.bank-=price-from_cash
	shop.stock[item]-=amount
	match item:
		"food": s.food+=amount
		"water": s.water+=amount
		_: s.inventory[item]+=int(amount)
	advance(1)
	return "%sで購入した（%d円）。"%[shop.name,price]

# Extension points used by the revision21 simulation.
func _weather_for_day(day: int) -> String:
	var w := draw(day,0,"weather")
	return "clear" if w < 4300 else ("cloudy" if w < 7800 else ("rain" if w < 9700 else "snow"))
func _resident_target(_actor: Dictionary, target: Vector2) -> Vector2:
	return target
func _resident_speed(_actor: Dictionary, speed: float) -> float:
	return speed
func _road_connector() -> float:
	return 50.0
func _traffic_speed_factor() -> float:
	return 1.0
func _crop_growth_factor() -> float:
	return 1.0
func _resident_arrived(a: Dictionary, day: int) -> void:
	if a.kind == "survivor" and str(a.get("activity", "")) in ["shopping", "searching"]:
		if Vector2(float(a.x), float(a.z)).distance_to(Vector2(20.0,19.3)) <= 1.0 and int(a.get("last_supply_day", -1)) != day:
			a.last_supply_day = day
			if draw(day,int(a.id),"find-supplies",10000)<7500:
				var amount: float = minf(1.5,minf(float(s.shops.grocer.stock.food),30.0-float(a.supplies)))
				s.shops.grocer.stock.food -= amount
				a.supplies += amount
