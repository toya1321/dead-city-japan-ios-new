extends Control
# Data-driven schematic background. It never pretends to be a dedicated image
# of a distant event. Light and precipitation follow the current game state.
var place := "寝室"
var hour := 8.0
var weather := "cloudy"
var power := true
var shop_open := true
var people := 0
var context := ""
func update_view(next_place: String,next_hour: float,next_weather: String,next_power: bool,next_shop_open: bool,visible_people: int,next_context: String) -> void:
	place=next_place;hour=next_hour;weather=next_weather;power=next_power;shop_open=next_shop_open;people=visible_people;context=next_context
	queue_redraw()
func _draw() -> void:
	var w:=size.x
	var h:=size.y
	if w<=1 or h<=1:return
	var night:=hour<6 or hour>=18
	var sky:=Color("#142036") if night else (Color("#5f748d") if weather in ["rain","snow","cloudy"] else Color("#8db7d5"))
	var outdoor:=place in ["屋外","建物前","食品店","金物店","薬局"] or context=="window"
	draw_rect(Rect2(0,0,w,h),Color("#182536") if night and not power else Color("#354353"))
	if outdoor:
		draw_rect(Rect2(0,0,w,h*0.65),sky)
		for i in range(7):
			var x:=float(i)*w/7
			var bh:=h*(0.30+float(i%3)*0.06)
			draw_rect(Rect2(x,h*0.65-bh,w/7-9,bh),Color("#26354a") if night else Color("#7f8b94"))
			for floor_index in range(2):
				for window_index in range(3):draw_rect(Rect2(x+9+window_index*w/25,h*0.65-bh+12+floor_index*25,w/35,14),Color("#ccad6c") if night and power else Color("#30445a"))
		draw_rect(Rect2(0,h*0.65,w,h*0.35),Color("#2d3440"))
		for i in range(8):draw_rect(Rect2(float(i)*w/8,h*0.82,w/15,3),Color("#a9a99b"))
		for i in range(mini(people,8)):
			var x:=w*0.09+float(i)*w*0.11
			draw_circle(Vector2(x,h*0.65),5,Color("#c4b2a0"))
			draw_line(Vector2(x,h*0.65+5),Vector2(x,h*0.65+21),Color("#6e8e9c"),6)
		if place in ["食品店","金物店","薬局"]:
			draw_rect(Rect2(w*0.25,h*0.18,w*0.5,h*0.48),Color("#344352"))
			draw_rect(Rect2(w*0.3,h*0.35,w*0.4,h*0.31),Color("#9ca6a7") if not shop_open else Color("#506d7d"))
			for i in range(5):draw_line(Vector2(w*0.3,h*(0.38+i*0.05)),Vector2(w*0.7,h*(0.38+i*0.05)),Color("#5a6772"),2)
	else:
		draw_rect(Rect2(0,h*0.68,w,h*0.32),Color("#544c43") if not night else Color("#272932"))
		draw_rect(Rect2(w*0.64,h*0.08,w*0.28,h*0.5),sky)
		draw_rect(Rect2(w*0.64,h*0.08,w*0.28,h*0.5),Color("#bbb5a6"),false,7)
		draw_line(Vector2(w*0.78,h*0.08),Vector2(w*0.78,h*0.58),Color("#bbb5a6"),4)
		match place:
			"寝室":
				draw_rect(Rect2(w*0.08,h*0.45,w*0.45,h*0.32),Color("#474459"))
				draw_rect(Rect2(w*0.1,h*0.48,w*0.41,h*0.20),Color("#88928e"))
				draw_rect(Rect2(w*0.11,h*0.49,w*0.1,h*0.11),Color("#c3c5b9"))
			"居間":
				draw_rect(Rect2(w*0.1,h*0.44,w*0.40,h*0.26),Color("#657d75"))
				draw_rect(Rect2(w*0.27,h*0.72,w*0.33,h*0.08),Color("#8d7052"))
			"台所":
				draw_rect(Rect2(w*0.08,h*0.5,w*0.5,h*0.25),Color("#879ba0"))
				draw_circle(Vector2(w*0.2,h*0.5),h*0.08,Color("#263a48"))
				if power:draw_circle(Vector2(w*0.33,h*0.5),h*0.06,Color("#899481"))
			_:
				draw_rect(Rect2(w*0.3,h*0.16,w*0.25,h*0.66),Color("#695b4e"))
				draw_circle(Vector2(w*0.5,h*0.48),4,Color("#bfad75"))
	if outdoor and weather=="rain":
		for i in range(32):
			var x:=fmod(float(i)*53.0,w)
			var y:=fmod(float(i)*31.0,maxf(h,1))
			draw_line(Vector2(x,y),Vector2(x-6,y+16),Color(0.6,0.8,0.9,0.6),1)
	if outdoor and weather=="snow":
		for i in range(35):draw_circle(Vector2(fmod(i*57.0,w),fmod(i*37.0,maxf(h,1))),2,Color("#e2e8ed"))
	var font:=get_theme_default_font()
	var label:=place
	if place in ["食品店","金物店","薬局"]:label+="  営業中" if shop_open else "  休業中"
	draw_rect(Rect2(0,0,w,34),Color(0.02,0.05,0.1,0.7))
	draw_string(font,Vector2(12,25),label,HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color("#e1e9ed"))
