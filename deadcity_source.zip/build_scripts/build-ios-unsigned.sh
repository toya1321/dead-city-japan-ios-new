#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != Darwin ]]; then
  echo 'The iOS compile stage requires macOS and Xcode.' >&2
  exit 1
fi
VERSION=4.6.3-stable
mkdir -p build/tools build/ios build/stage/Payload
TOOLS="$PWD/build/tools"
BASE="https://github.com/godotengine/godot/releases/download/$VERSION"
MAC="Godot_v${VERSION}_macos.universal.zip"
TEMPLATES="Godot_v${VERSION}_export_templates.tpz"
for NAME in "$MAC" "$TEMPLATES" SHA512-SUMS.txt; do
  if [[ ! -f "$TOOLS/$NAME" ]]; then
    curl --fail --location --retry 3 "$BASE/$NAME" -o "$TOOLS/$NAME"
  fi
done
(cd "$TOOLS" && grep -E 'Godot_v4[.]6[.]3-stable_(macos[.]universal[.]zip|export_templates[.]tpz)$' SHA512-SUMS.txt > selected-checksums.txt && test "$(wc -l < selected-checksums.txt | tr -d ' ')" = 2 && shasum -a 512 -c selected-checksums.txt)
unzip -oq "$TOOLS/$MAC" -d "$TOOLS"
GODOT="$TOOLS/Godot.app/Contents/MacOS/Godot"
TEMPLATE_DIR="$HOME/Library/Application Support/Godot/export_templates/4.6.3.stable"
mkdir -p "$TEMPLATE_DIR"
unzip -p "$TOOLS/$TEMPLATES" templates/ios.zip > "$TEMPLATE_DIR/ios.zip"
test -s "$TEMPLATE_DIR/ios.zip"
"$GODOT" --headless --editor --path "$PWD" --quit
"$GODOT" --headless --path "$PWD" --script res://tests/test_world.gd 2>&1 | tee build/world-tests.log
if grep -E 'SCRIPT ERROR:|ERROR:|failures[^0]|FAIL:' build/world-tests.log; then exit 1; fi
"$GODOT" --headless --path "$PWD" --export-release 'iOS unsigned project' "$PWD/build/ios/DeadCityJapan.zip" 2>&1 | tee build/export.log
# Team ID in export_presets.cfg is an exporter-only placeholder. The compiler
# is explicitly unsigned and receives an empty DEVELOPMENT_TEAM override.
xcodebuild -project build/ios/DeadCityJapan.xcodeproj -scheme DeadCityJapan \
  -configuration Release -destination 'generic/platform=iOS' -sdk iphoneos \
  -derivedDataPath "$PWD/build/DerivedData" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= \
  DEVELOPMENT_TEAM= ARCHS=arm64 ONLY_ACTIVE_ARCH=NO build 2>&1 | tee build/xcodebuild.log
APP="$PWD/build/DerivedData/Build/Products/Release-iphoneos/DeadCityJapan.app"
test -d "$APP"
# Embedded runtime binaries may retain vendor ad-hoc signatures. Remove every
# existing bundle signature so SideStore receives a consistently unsigned IPA.
while IFS= read -r -d '' BINARY; do
  if file "$BINARY" | grep -q 'Mach-O'; then
    if codesign -d "$BINARY" >/dev/null 2>&1; then codesign --remove-signature "$BINARY"; fi
  fi
done < <(find "$APP" -type f -print0)
find "$APP" -type d -name _CodeSignature -prune -exec rm -rf {} +
find "$APP" -name embedded.mobileprovision -delete
xcrun lipo "$APP/DeadCityJapan" -verify_arch arm64
python3 - "$APP" <<'PY'
import plistlib,sys
from pathlib import Path
p=Path(sys.argv[1]);info=plistlib.loads((p/'Info.plist').read_bytes())
assert info['CFBundleSupportedPlatforms']==['iPhoneOS']
assert info['CFBundleIdentifier']=='com.deadcityjapan.prototype'
assert any(p.rglob('*.pck')), 'Missing game data'
PY
ditto "$APP" build/stage/Payload/DeadCityJapan.app
OUTPUT="$PWD/build/DeadCityJapan-Godot-unsigned.ipa"
(cd build/stage && zip -qry "$OUTPUT" Payload)
unzip -t "$OUTPUT"
shasum -a 256 "$OUTPUT" > build/SHA256SUMS.txt
