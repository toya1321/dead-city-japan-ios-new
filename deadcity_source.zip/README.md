# DEAD CITY JAPAN v12 (0.2.0 build 12)

Revision following v11 real-device feedback.

- Fixed NPC physics transforms: initialize at persisted world positions and update each body with one complete transform. No NPC starts inside the home.
- Replaced the 15 cm entrance ledge with one continuous walkable collision surface. Walking, running and crouching re-entry are covered by runtime movement tests.
- New normal-city scenario starts at 2026-11-10 08:00, based on original save_001. 48 healthy residents, three moving vehicles, finite shops, tap water and grid electricity. This is a bounded prototype neighborhood, not a full city simulation.
- Food 365 days, 400 W solar, 2 kWh battery at 90%, cash 100,000 yen, bank 1,500,000 yen. Unmeasured stored water stays unknown; tap consumption is recorded separately.
- Storefront shopping spends money and transfers finite stock. Vehicles and pedestrians advance independently of observation.
- New save path deadcity_v12.save preserves deadcity_v11.save. The new-game menu confirms and backs up the current v12 save before resetting.
- Limitation: the later normal-to-outbreak timeline and external infection seeding are not implemented. Current normal start does not automatically become an outbreak.

## Validation

Godot 4.6.3. World (37 checks), scene (9 checks), regression (14 checks) suites. Native iPhone behavior still requires user verification.

## Build

Run bash build_scripts/build-ios-unsigned.sh on macOS with Xcode. The script verifies official Godot downloads, runs all three suites, exports the Xcode project and compiles unsigned arm64 for iPhoneOS. No Apple signing certificate is needed for this stage; SideStore signs when installing.
