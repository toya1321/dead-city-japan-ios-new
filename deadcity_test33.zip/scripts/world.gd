extends "res://scripts/world_legacy.gd"
const District = preload("res://scripts/district.gd")
const Events = preload("res://scripts/world_events.gd")
const HouseholdDialogue = preload("res://scripts/household_dialogue.gd")
const HOUSEHOLD_LEAVE := 9
const HOUSEHOLD_RETURN := 17
const HOUSEHOLD_SLEEP := 23
const HOUSEHOLD_WAKE := 7
const DEFAULT_PROFILE = {"name":"トウヤ","age":31,"address":"東京都渋谷区笹塚","job":"無職","housing":"一戸建て","cohabitants":0,"companion_names":[],"companion_genders":[],"seed":481516,"has_key":true}
const CATALOG = {"food":{"name":"食料","price":600,"amount":1.0,"shop":"grocer"},"water":{"name":"飲料水","price":120,"amount":2.0,"shop":"grocer"},"wood":{"name":"木材","price":500,"amount":1.0,"shop":"hardware"},"parts":{"name":"部品","price":800,"amount":1.0,"shop":"hardware"},"seeds":{"name":"種","price":200,"amount":1.0,"shop":"hardware"},"bandage":{"name":"包帯","price":300,"amount":1.0,"shop":"pharmacy"},"filter":{"name":"浄水器","price":12000,"amount":1.0,"shop":"hardware"},"solar":{"name":"ソーラーパネル","price":30000,"amount":1.0,"shop":"hardware"},"battery":{"name":"蓄電池","price":40000,"amount":1.0,"shop":"hardware"}}

func reset() -> void:
	super.reset()
	s.profile = DEFAULT_PROFILE.duplicate(true)
	s.household_members = []
	Events.initialize(self)
	s.district = District.fresh()

func configure(profile: Dictionary) -> bool:
	if not valid_profile(profile): return false
	reset()
	s.profile = profile.duplicate(true)
	s.seed = int(profile.seed)
	s.sim.local_region = Events.region_for_address(str(profile.address))
	for i in range(int(profile.cohabitants)):
		var names: Array = profile.get("companion_names",[])
		var name := str(names[i]).strip_edges() if i < names.size() else ""
		s.household_members.append({"id":i,"name":name if not name.is_empty() else "同居人%d"%(i+1),"health":100.0,"hunger":0.0,"thirst":0.0,"fatigue":0.0,"location":"居間","activity":"在宅","food_used":0.0,"water_used":0.0})
	return true

static func valid_profile(profile: Dictionary) -> bool:
	for key in ["name","address","job","housing"]:
		if not profile.get(key) is String or str(profile[key]).strip_edges().is_empty(): return false
	if str(profile.name).length()>24 or str(profile.address).length()>60: return false
	if str(profile.job) not in ["無職","会社員","自営業","学生"] or str(profile.housing) not in ["一戸建て","集合住宅"]: return false
	for key in ["age","seed","cohabitants"]:
		if not (profile.get(key) is int or profile.get(key) is float): return false
		if not is_finite(float(profile[key])) or float(profile[key]) != floor(float(profile[key])): return false
	if int(profile.age)<1 or int(profile.age)>100 or int(profile.cohabitants)<0 or int(profile.cohabitants)>3 or int(profile.seed)<1 or int(profile.seed)>999999999: return false
	if not profile.get("has_key") is bool or not profile.get("companion_names") is Array: return false
	if profile.companion_names.size()>3: return false
	for name_value in profile.companion_names:
		if not name_value is String or str(name_value).length()>24: return false
	var genders = profile.get("companion_genders", [])
	if not genders is Array or genders.size() > int(profile.cohabitants): return false
	for gender in genders:
		if not gender is String or gender not in HouseholdDialogue.GENDERS: return false
	return true

func step(sleeping: bool) -> void:
	super.step(sleeping)
	if int(s.minute)%60==0:
		_household_hour()
		if not s.has("district"):
			s.district = District.fresh()
		District.tick(self)
	if int(s.minute)%1440==0:_off_map_day()

func _update_outbreak() -> void:
	if int(s.minute)%60 == 0: Events.tick(self)

func _simulate_daily_events(_day: int) -> void:
	# Stateful hourly events supersede the old text-only daily rolls.
	pass

func _update_resident_routines() -> void:
	var hour := int(hour_of_day())
	var weekday := (2+int(s.minute)/1440)%7
	for a in s.agents:
		if a.dead or bool(a.get("departed",false)) or a.kind != "survivor": continue
		var activity := "home"
		var destination := "home"
		if int(a.get("sick_until",0))>int(s.minute): activity = "rest"
		elif int(s.sim.curfew_until)>int(s.minute) and str(a.destination)!="clinic": activity="shelter"
		elif int(a.get("override_until",0))>int(s.minute):
			activity = str(a.get("override_activity","shelter"))
			destination = str(a.get("override_destination","home"))
		elif float(a.supplies)<3.0 and hour>=8 and hour<20:
			activity = "shopping" if can_trade("grocer") else "searching"
			destination = activity
		elif s.society in ["normal","alert"] and hour>=8 and hour<18 and weekday<5 and str(a.occupation)!="home" and int(a.get("remote_until",0))<=int(s.minute):
			activity = "work"
			destination = "work"
		elif s.society in ["disrupted","emergency"]: activity = "shelter"
		var previous: String = a.activity
		a.activity = activity
		a.destination = destination
		if previous != activity: a.last_activity_change = int(s.minute)
	# Preserve the existing bounded population and household snapshots.
	if hour==0:
		_update_relationships(int(s.minute)/1440)
		var census_value := census()
		s.longplay.population_snapshots.append({"day":int(s.minute)/1440,"living":census_value.survivor,"symptomatic":census_value.symptomatic,"dead":census_value.dead,"searching":0})
		if s.longplay.population_snapshots.size()>365:s.longplay.population_snapshots.pop_front()
		var total := 0.0
		for a in s.agents:
			if not a.dead and not bool(a.get("departed",false)):total+=float(a.supplies)
		s.longplay.household_snapshots.append({"day":int(s.minute)/1440,"households":16,"food_units":total,"shortages":0})
		if s.longplay.household_snapshots.size()>365:s.longplay.household_snapshots.pop_front()

func _resident_target(a: Dictionary,target: Vector2) -> Vector2:
	match str(a.get("destination","home")):
		"clinic":return Vector2(-22,19.3)
		"work":
			if not str(a.get("work_shop","")).is_empty():
				var shop:Dictionary=s.shops[a.work_shop]
				return Vector2(float(shop.x),float(shop.z))
		"park":return Vector2(0,38)
		"boundary":return Vector2(55,38)
		"farm":return Vector2(-35,38)
	return target
func _resident_speed(a: Dictionary,speed: float) -> float:
	if speed<=0:return 0.0
	return (27.0 if a.kind=="symptomatic" else 39.0) * (0.7 if s.weather=="snow" else 1.0)
func _road_connector() -> float:
	return -50.0 if int(s.sim.road_blocked_until)>int(s.minute) else 50.0
func _traffic_speed_factor() -> float:
	return float(s.sim.traffic)*60.0
func _crop_growth_factor() -> float:
	var month: int = Time.get_datetime_dict_from_unix_time(int(Time.get_unix_time_from_datetime_string(START_TIME))+int(s.minute)*60).month
	return 0.45 if month in [12,1,2] else 1.0
func _weather_for_day(day: int) -> String:
	return Events.seasonal_weather(self,day)

func _resident_arrived(a: Dictionary,day: int) -> void:
	if a.kind != "survivor":return
	var pos := Vector2(float(a.x),float(a.z))
	if a.destination=="boundary" and pos.distance_to(Vector2(55,38))<1:
		a.departed=true
		a.activity="shelter"
		_resident_record(a,"departure","近隣地区から移動した。")
		return
	if a.destination=="clinic" and pos.distance_to(Vector2(-22,19.3))<1 and int(s.minute)%60==0 and float(s.sim.hospital_load)<80 and bool(s.sim.clinic_open):
		a.health=minf(100,float(a.health)+0.8)
	var paid_target:=Vector2(float(a.home_x),float(a.home_z)) if a.destination=="home" else _resident_target(a,Vector2(float(a.work_x),float(a.work_z)))
	if a.activity=="work" and a.occupation in ["office","retail","delivery"] and pos.distance_to(paid_target)<1 and int(s.minute)%60==0 and float(s.sim.payroll)>=600:
		a.cash+=600
		s.sim.payroll-=600
	if a.activity not in ["shopping","searching"] or pos.distance_to(Vector2(20,19.3))>1 or int(a.get("last_supply_day",-1))==day:return
	if not can_trade("grocer"):return
	if draw(day,int(a.id),"find-supplies",10000)>=7500:return
	var amount:float=minf(1.5,minf(float(s.shops.grocer.stock.food),30-float(a.supplies)))
	if bool(s.sim.panic):amount=minf(3.0,minf(float(s.shops.grocer.stock.food),30-float(a.supplies)))
	if bool(s.sim.rationing):amount=minf(amount,2.0)
	amount=minf(amount,float(a.cash)/600.0)
	if amount<=0:return
	a.last_supply_day=day
	a.cash=maxf(0,float(a.cash)-amount*600.0)
	s.shops.grocer.till+=amount*600.0
	s.shops.grocer.stock.food-=amount
	a.supplies+=amount

func household_activity_at(hour: int) -> String:
	if hour >= HOUSEHOLD_SLEEP or hour < HOUSEHOLD_WAKE:
		return "睡眠"
	return "外出" if hour >= HOUSEHOLD_LEAVE and hour < HOUSEHOLD_RETURN and s.society == "normal" else "在宅"

func _household_hour() -> void:
	var scheduled := household_activity_at(int(hour_of_day()))
	for person in s.household_members:
		if float(person.health)<=0:continue
		person.hunger=minf(100,float(person.hunger)+100.0/24.0)
		person.thirst=minf(100,float(person.thirst)+100.0/24.0)
		var previous_activity: String = person.activity
		person.activity = scheduled
		if person.activity != previous_activity:
			person.location="寝室" if person.activity=="睡眠" else ("屋外" if person.activity=="外出" else "居間")
		person.fatigue=clampf(float(person.fatigue)+(-12.5 if person.activity=="睡眠" else 100.0/24.0),0,100)
		if person.activity!="外出":
			if float(person.hunger)>=35 and float(s.food)>=0.25:
				s.food-=0.25
				person.food_used+=0.25
				person.hunger=maxf(0,float(person.hunger)-25)
			if float(person.thirst)>=25 and (bool(s.water_online) or float(s.water)>=0.75):
				if s.water_online:s.tap_water_used+=0.75
				else:s.water-=0.75
				person.water_used+=0.75
				person.thirst=maxf(0,float(person.thirst)-25)
		if float(person.hunger)>=100 or float(person.thirst)>=100:person.health=maxf(0,float(person.health)-1.5)

func can_trade(shop_id: String) -> bool:
	if not s.shops.has(shop_id):return false
	var shop:Dictionary=s.shops[shop_id]
	return bool(shop.get("open",false)) and not bool(shop.get("abandoned",false)) and hour_of_day()>=8 and hour_of_day()<21 and int(shop.get("closed_until",0))<=int(s.minute)
func shops_open() -> bool:
	return can_trade("grocer")
func buy(shop_id: String,item: String) -> String:
	return buy_quantity(shop_id,item,1)

func buy_quantity(shop_id: String,item: String,quantity: int) -> String:
	if float(s.health)<=0:return "死亡しているため購入できない。"
	if quantity<1 or quantity>12:return "購入数は1～12個で指定してください。"
	if not s.shops.has(shop_id):return "店が見つからない。"
	if not CATALOG.has(item) or str(CATALOG[item].shop)!=shop_id:return "この店では扱っていません。"
	var shop:Dictionary=s.shops[shop_id]
	if Vector2(float(s.player_pos[0]),float(s.player_pos[2])).distance_to(Vector2(float(shop.x),float(shop.z)))>4:return "店頭に近づいてください。"
	if not can_trade(shop_id):return "この店は休業中です。"
	var entry:Dictionary=CATALOG[item]
	var amount:float=float(entry.amount)*quantity
	var price:int=int(entry.price)*quantity
	if bool(s.sim.rationing) and quantity>2:return "この店では一度に2個までです。"
	if item in ["filter","solar","battery"] and quantity!=1:return "設備は1台ずつ購入してください。"
	if float(shop.stock.get(item,0))<amount:return "店の在庫が足りない。"
	if int(s.cash)+int(s.bank)<price:return "お金が足りない。"
	if item in ["filter","solar","battery"] and bool(s.equipment[item]):return "その設備はすでに所持している。"
	var cash_paid:=mini(int(s.cash),price)
	s.cash-=cash_paid
	s.bank-=price-cash_paid
	shop.till+=price
	shop.stock[item]-=amount
	if item in ["food","water"]:s[item]+=amount
	elif item in ["filter","solar","battery"]:
		s.equipment[item]=true
		if item=="filter":s.longplay.filter_condition=100.0
		if item=="solar":s.solar_w=400.0
		if item=="battery":s.battery=1000.0
	else:s.inventory[item]+=int(amount)
	advance_safe(5+int(shop.get("queue_minutes",0)))
	return "%sを購入した（%d円）。"%[entry.name,price]

func place_order(item: String,quantity: int) -> String:
	if float(s.health)<=0:return "死亡しているため注文できない。"
	if float(s.sim.communications)<30 or float(s.sim.phone_charge)<=0:return "通信が利用できず、通販注文を送れない。"
	if item not in ["food","water"] or quantity<1 or quantity>12:return "食料か飲料水を1～12個で指定してください。"
	var amount:float=quantity*(2.0 if item=="water" else 1.0)
	if float(s.sim.warehouse[item])<amount:return "配送倉庫の在庫が足りず、注文できない。"
	s.sim.warehouse[item]-=amount
	var result:=super.place_order(item,quantity)
	if result.contains("注文した"):
		s.longplay.orders[-1].reserved=true
	else:s.sim.warehouse[item]+=amount
	return result
func _process_orders() -> void:
	for order in s.longplay.orders:
		if order.status!="pending" or int(s.minute)<int(order.due):continue
		var amount:float=float(order.quantity)*(2.0 if order.item=="water" else 1.0)
		var blocked:bool=s.society=="emergency" or (s.society=="disrupted" and draw(int(order.id),int(s.minute),"delivery",10000)<8000)
		# Legacy pending orders had no reservation. Acquire finite stock at
		# fulfillment once; never mint goods on migration.
		if not bool(order.get("reserved",false)) and not blocked:
			if float(s.sim.warehouse[order.item])<amount:blocked=true
			else:s.sim.warehouse[order.item]-=amount;order.reserved=true
		if blocked:
			order.status="failed"
			if bool(order.get("reserved",false)):s.sim.warehouse[order.item]+=amount;order.reserved=false
			Events.emit_event(self,"delivery_failed","注文品の配送が中止された。返金は未処理。",{"order":order.id},"inspect",-1,[],true)
		else:
			order.status="delivered"
			s[order.item]+=amount
			Events.emit_event(self,"delivery_arrived","玄関先に注文した荷物が届いた。",{"order":order.id,"item":order.item,"amount":amount},"sight",-1,[0.0,2.0],true)
func order_status() -> String:
	if s.longplay.orders.is_empty():return "通販の注文履歴はない。"
	var lines:Array[String]=[]
	for order in s.longplay.orders.slice(maxi(0,s.longplay.orders.size()-8)):
		lines.append("%s ×%d / %s / 予定 %s"%["食料" if order.item=="food" else "飲料水",int(order.quantity),{"pending":"配送待ち","delivered":"配達済み","failed":"配送中止"}[order.status],Time.get_datetime_string_from_unix_time(int(Time.get_unix_time_from_datetime_string(START_TIME))+int(order.due)*60).replace("T"," ").substr(0,16)])
	return "\n".join(lines)
func has_home_power() -> bool:
	return bool(s.grid_online) or (bool(s.equipment.battery) and float(s.battery)>1.0)
func tap_available() -> bool:
	return bool(s.water_online) and float(s.player_pos[2])<3.0

func work_at_home() -> String:
	if s.profile.job=="無職":return "現在、受けている仕事はない。"
	if not has_home_power() or float(s.sim.communications)<30:return "電力と通信が必要です。"
	if s.profile.job=="学生":
		advance_safe(120)
		s.sim.study_sessions+=1
		return "2時間勉強した。"
	var pay:=4000 if s.profile.job=="会社員" else 3000
	if float(s.sim.payroll)<pay:return "支払元が業務を停止している。"
	var before:=int(s.minute)
	while int(s.minute)-before<240 and float(s.health)>0 and has_home_power() and float(s.sim.communications)>=30:
		advance_safe(1)
	if int(s.minute)-before<240:return "%d分で作業が中断された。報酬は発生していない。"%(int(s.minute)-before)
	s.bank+=pay
	s.sim.payroll-=pay
	return "4時間の仕事を終え、%d円の報酬を得た。"%pay

func migrate_legacy(data: Dictionary) -> Dictionary:
	for field in ["sim","profile"]:
		if data.has(field) and not data[field] is Dictionary:return {}
	if data.has("household_members") and not data.household_members is Array:return {}
	var migrated:Dictionary
	if int(data.get("version",-1))==VERSION:migrated=data.duplicate(true)
	else:
		# Parent migration calls this override's validator, so seed defaults first.
		var prepared:=data.duplicate(true)
		Events.upgrade_data(prepared)
		migrated=super.migrate_legacy(prepared)
	if migrated.is_empty():return {}
	Events.upgrade_data(migrated)
	if not migrated.has("district"):
		migrated.district = District.fresh()
	return migrated if validate_state(migrated) else {}
func validate_state(data: Dictionary) -> bool:
	return super.validate_state(data) and Events.valid_data(data) and valid_profile(data.get("profile",{})) and (not data.has("district") or District.valid(data.district))

func _player_has_district_cover() -> bool:
	return s.has("district") and District.fortified(self)
func load_file(path: String) -> Error:
	var file:=FileAccess.open(path,FileAccess.READ)
	if file==null:return ERR_FILE_NOT_FOUND
	var value=file.get_var(false)
	if not value is Dictionary:return ERR_INVALID_DATA
	var loaded:=migrate_legacy(value)
	if loaded.is_empty():return ERR_INVALID_DATA
	s=loaded
	return OK

func census() -> Dictionary:
	var result:Dictionary={"total":s.agents.size(),"living":0,"dead":0,"symptomatic":0,"survivor":0,"departed":0}
	for a in s.agents:
		if a.dead:result.dead+=1
		elif bool(a.get("departed",false)):result.departed+=1
		else:
			result.living+=1
			result[a.kind]+=1
	return result

func _off_map_day() -> void:
	# Departed residents keep their own finite supplies and health. They are
	# still simulated at daily resolution; departure never freezes life.
	for a in s.agents:
		if a.dead or not bool(a.departed):continue
		if a.kind=="survivor":
			if float(a.supplies)>=1:a.supplies-=1
			else:a.health=maxf(0,float(a.health)-12)
			if int(a.exposure)>=0 and int(s.minute)>=int(a.symptoms_due):a.kind="symptomatic"
		else:a.health=maxf(0,float(a.health)-2.016)
		if float(a.health)<=0:
			a.dead=true;a.life_stage="dead"
			_resident_record(a,"death","移動先で死亡が記録された。")

func action(kind: String) -> String:
	if float(s.health)<=0:return "死亡しているため行動できない。"
	if kind=="fortify" and bool(s.door_open):return "玄関の扉を閉めてから補強してください。"
	if kind=="unfortify":
		if int(s.barricade)<=0:return "取り外す補強はない。"
		s.barricade-=1
		s.inventory.wood+=2
		s.inventory.parts+=1
		var elapsed:=advance_safe(30)
		return "補強を1段外し、木材2と部品1を回収した（%d分）。"%elapsed
	if kind=="tend":
		if s.plots.is_empty():return "栽培中の作物はない。"
		if float(s.rain_water)>=1:s.rain_water-=1
		elif tap_available():s.tap_water_used+=1
		elif float(s.water)>=1:s.water-=1;s.water_used+=1
		else:return "水やりに使える水が1L必要です。"
		s.plots[0].water+=1
		return "最初の鉢に水1Lを与えた。"
	var result:=super.action(kind)
	if kind=="plant" and result.begins_with("植え付けた"):advance_safe(15)
	return result
