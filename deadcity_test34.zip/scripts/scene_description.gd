extends RefCounted

const District = preload("res://scripts/district.gd")
const Navigation = preload("res://scripts/navigation.gd")

const DETAILS = {
	"寝室": "ベッドの脇に、カーテンのかかった窓がある。ここなら腰を落ち着けて休める。",
	"居間": "ソファと低いテーブルがある。台所や玄関に向かうなら、この部屋から行ける。",
	"台所": "調理台の横に流し台がある。食事を取るなら、まず家の備蓄を確かめられる。",
	"廊下": "細い廊下の両側に部屋が並んでいる。先に進むと玄関のたたきに出る。",
	"玄関": "靴を置くたたきの先に、外へ通じる扉がある。",
	"共用廊下": "手すり沿いに住戸の扉が並んでいる。建物の入口と自宅の玄関を結ぶ通路だ。",
	"屋外": "家の並ぶ通りに出た。店が集まる方へも、住宅街を抜けて駅の方へも歩いていける。",
	"商店通り": "通りに面して小さな店が並ぶ。道沿いにコンビニの入口が見える。",
	"住宅街": "家々の塀と玄関が細い道に面している。並びには近所の空き家がある。",
	"駅前": "道路が広がり、建物の間から駅の入口が見える。駅前にはデパートが建っている。",
	"食品店": "小さな食品店の前だ。通りに面して店の入口がある。",
	"金物店": "工具や資材を扱う金物店の前だ。店先から元の通りに戻れる。",
	"薬局": "薬局の店先に着いた。入口は通りに面している。",
	"コンビニ": "通路の両側に商品棚が並び、奥にはガラス扉の冷蔵ケースがある。入口のそばがレジだ。",
	"近所の空き家": "木の廊下から障子のある和室が見える。低い卓の周りには、横になれるだけの広さがある。",
	"デパート": "広い売り場に陳列台が並び、奥にエスカレーターが見える。",
}
const SHOPS = {"食品店":"grocer", "金物店":"hardware", "薬局":"pharmacy"}
const STREET_VIEWS = ["建物前", "屋外", "共用廊下", "商店通り", "住宅街", "駅前", "食品店", "金物店", "薬局"]

static func describe(world, place: String) -> String:
	var housing := str(world.s.profile.housing)
	var detail := str(DETAILS.get(place, ""))
	if place == "建物前":
		detail = "集合住宅の入口に出た。住戸へは共用廊下を通る。" if housing == "集合住宅" else "家の玄関先に出た。敷地の先は通りにつながっている。"
	if place in STREET_VIEWS:
		detail += _outside_light(str(world.s.weather), world.hour_of_day())
		if not world.visible_residents().is_empty():
			detail += "近くに人影が見える。"
	if Navigation.indoor(place):
		for person in world.s.household_members:
			if person.location == place and float(person.health) > 0 and person.activity != "外出":
				detail += "%sが眠っている。" % person.name if person.activity == "睡眠" else "%sがいる。" % person.name
	var cue := _action_cue(world, place)
	var nearby: Array = Navigation.graph(housing).get(place, [])
	var lines: Array[String] = [detail]
	if not nearby.is_empty():
		lines.append("ここからは%sの方へ向かえる。" % "、".join(nearby))
	if not cue.is_empty():
		lines.append(cue)
	return "\n".join(lines)

static func _outside_light(weather: String, hour: float) -> String:
	match weather:
		"rain": return "雨で路面が濡れている。"
		"snow": return "雪が降っている。"
	if hour < 6.0 or hour >= 18.0:
		return "外は暗く、遠くの様子は見通しにくい。"
	if weather == "cloudy":
		return "曇り空の下、通りに淡い光が差している。"
	return "日中の光で通りの先まで見渡せる。"

static func _action_cue(world, place: String) -> String:
	if District.SITES.has(place):
		var site: Dictionary = world.s.district.sites[place]
		if not site.vacant:
			if District.can_enter(world, place):
				return "店は営業中。「店の在庫を見る」で品ぞろえを確かめたり、「水を買う」と注文したりできる。"
			return "営業時間外だ。いまは買い物できない。"
		if not District.prepared(world, place):
			var occupancy := "寝泊まりの支度はまだしていない。" if place == "近所の空き家" else "店は放棄されている。"
			return occupancy + "「物資を探索する」や「ここを拠点にする」と入力できる。"
		var shelter := "入口は補強してある。" if int(site.level) == 2 else "ここは寝泊まりできるように整えてある。"
		return shelter + "「ここで一晩過ごす」ことも、「拠点の状態を見る」こともできる。"
	if SHOPS.has(place):
		if world.can_trade(SHOPS[place]):
			return "店は営業中。「店の在庫を見る」で品ぞろえを確かめられる。"
		return "店は休業中。いまは買い物できない。"
	match place:
		"寝室": return "「窓を見る」と外の様子を確かめられる。休むなら「寝る」。"
		"居間": return "ここで「ニュースを見る」ことや、食料・水の通販注文ができる。"
		"台所":
			var tap := "水道は使える。" if world.tap_available() else "いまは水道を使えない。"
			return tap + "「食事する」や「水を飲む」と入力できる。"
		"玄関":
			if int(world.s.barricade) > 0:
				return "玄関の補強が通路を塞いでいる。「玄関の補強を外す」と通れる。"
			if bool(world.s.door_locked):
				return "扉には鍵がかかっている。外へ出る前に「鍵を開ける」。"
			return "玄関は解錠済み。「外に出る」と通りに出られる。"
		"屋外": return "「街を歩く」と先の通りへ進める。「街の地図を見る」で行き先を確認できる。"
		"商店通り": return "気になる店があれば「コンビニへ行く」と入口まで向かえる。"
		"住宅街": return "空き家の中が気になるなら「近所の空き家へ行く」と入力できる。"
		"駅前": return "「デパートへ行く」で建物に向かえる。営業時間外は中に入れないことがある。"
	return ""
