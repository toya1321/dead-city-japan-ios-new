extends RefCounted
# One-minute world steps remain the authority. Routine care uses the same finite
# household stocks and water access as explicit eating/drinking. No shopping,
# teleports, rescue, or unseen-news checks happen during a wait.
static func begin(game, minutes: int, care: bool = true) -> Dictionary:
	var reason := ""
	if minutes < 1 or minutes > 10080: reason = "待機は1分～7日で指定してください。"
	elif float(game.world.s.health) <= 0: reason = "死亡しているため待機できません。"
	elif care and not game._can_live_here(): reason = "長期間の日常生活には自宅か、寝泊まりできる拠点が必要です。屋外では短時間の待機を指定してください。"
	return {"ok":reason.is_empty(),"reason":reason,"target":minutes,"home":game.Navigation.indoor(game.location),"elapsed":0,"care":care,"meals":0,"drinks":0,"sleep":0,"food":0.0,"water":0.0,"sleeping":false,"health":float(game.world.s.health),"household_health":_household_health(game.world.s),"stopped":not reason.is_empty()}
static func _household_health(s: Dictionary) -> float:
	var value := 0.0
	for person in s.household_members:value += float(person.health)
	return value
static func tick(game, run: Dictionary, limit: int = 30) -> void:
	if run.stopped:return
	var w = game.world
	for i in range(mini(limit,int(run.target)-int(run.elapsed))):
		var why := ""
		if float(w.s.health)<=0:why="死亡しているため中断しました。"
		elif float(w.s.health)<float(run.health)-0.01 or bool(w.s.symptomatic):why="体調の悪化を感じたため中断しました。"
		elif _household_health(w.s)<float(run.household_health)-0.01:why="同居人の体調が悪化したため中断しました。"
		if why.is_empty() and run.care:
			if not game._can_live_here():why="寝泊まりできる場所を離れたため待機を中断しました。"
			elif float(w.s.hunger)>=40:
				var before:float=w.s.hunger
				if game._eat_here():run.meals+=1;run.food+=(before-float(w.s.hunger))/100.0
				else:why="食料が不足しています。食事を取れないため、待機を中断しました。"
			if why.is_empty() and float(w.s.thirst)>=25:
				var before:float=w.s.water_used
				if game._drink_here():run.drinks+=1;run.water+=float(w.s.water_used)-before
				else:why="飲める水が不足しています。水分補給できないため、待機を中断しました。"
			if float(w.s.fatigue)>=70:run.sleeping=true
			if float(w.s.fatigue)<=20:run.sleeping=false
		if why.is_empty() and (float(w.s.hunger)>=85 or float(w.s.thirst)>=85 or (not run.care and float(w.s.fatigue)>=85)):
			why="空腹・渇き・疲労が危険に近づいたため、待機を中断しました。"
		if not why.is_empty():run.reason=why;run.stopped=true;break
		w.advance_safe(1,bool(run.care and run.sleeping))
		run.elapsed+=1
		if run.care and run.sleeping:run.sleep+=1
		if int(run.elapsed)>=int(run.target):run.stopped=true;break
static func summary(run: Dictionary) -> String:
	return "%d分が経過した（予定%d分）。%s\n%s"%[int(run.elapsed),int(run.target),str(run.reason),"日常生活：食事%d回（食料%.2f人日）、水分補給%d回（%.2fL）、睡眠%d分。%s"%[int(run.meals),float(run.food),int(run.drinks),float(run.water),int(run.sleep),"自宅の物資を使用。" if run.home else "携行品とこの拠点の備蓄を使用。"] if run.care else "飲食・睡眠を伴わない待機。"]
