extends RefCounted

const SITES = {
	"コンビニ": {"food": 8.0, "water": 20.0, "vacant": false, "opens": 0, "closes": 24, "position": Vector2(28, 22)},
	"近所の空き家": {"food": 1.5, "water": 3.0, "vacant": true, "opens": 0, "closes": 24, "position": Vector2(-29, 36)},
	"デパート": {"food": 30.0, "water": 45.0, "vacant": false, "opens": 10, "closes": 20, "position": Vector2(53, 31)},
}
const FOOD_LIMIT = 4.0
const WATER_LIMIT = 8.0
const COMMANDS = ["街を歩く", "物資を持っていく", "物資を置く", "拠点の物資を持ち出す", "ここを拠点にする", "拠点を補強する"]

static func fresh() -> Dictionary:
	var sites := {}
	for place in SITES:
		var site: Dictionary = SITES[place]
		sites[place] = {"food": site.food, "water": site.water, "vacant": site.vacant, "level": 0, "cache": {"food": 0.0, "water": 0.0}}
	return {"sites": sites, "bag": {"food": 0.0, "water": 0.0}, "current": ""}

static func _amount(value: Variant, limit: float) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0.0 and float(value) <= limit

static func _supplies(value: Variant, food_limit: float, water_limit: float) -> bool:
	return value is Dictionary and _amount(value.get("food"), food_limit) and _amount(value.get("water"), water_limit)

static func valid(value: Variant) -> bool:
	if not value is Dictionary or not _supplies(value.get("bag"), FOOD_LIMIT, WATER_LIMIT):
		return false
	if not value.get("sites") is Dictionary or value.sites.size() != SITES.size():
		return false
	if not value.get("current") is String or (value.current != "" and not SITES.has(value.current)):
		return false
	for place in SITES:
		var site = value.sites.get(place)
		if not _supplies(site, SITES[place].food, SITES[place].water):
			return false
		if not site.get("vacant") is bool or not _amount(site.get("level"), 2) or float(site.level) != floorf(float(site.level)):
			return false
		if (not site.vacant and site.level != 0) or not _supplies(site.get("cache"), 100.0, 200.0):
			return false
	return true

static func tick(world) -> void:
	if world.s.society == "emergency" or (world.s.society == "disrupted" and float(world.s.sim.logistics) < 60.0):
		world.s.district.sites["コンビニ"].vacant = true
	if world.s.society == "emergency":
		world.s.district.sites["デパート"].vacant = true

static func can_enter(world, place: String) -> bool:
	var site: Dictionary = world.s.district.sites[place]
	var hours: Dictionary = SITES[place]
	var hour: float = world.hour_of_day()
	return site.vacant or (hour >= float(hours.opens) and hour < float(hours.closes))

static func prepared(world, place: String) -> bool:
	return SITES.has(place) and int(world.s.district.sites[place].level) >= 1

static func fortified(world) -> bool:
	var place: String = world.s.district.current
	return not place.is_empty() and int(world.s.district.sites[place].level) >= 2

static func describe(world, place: String) -> String:
	var site: Dictionary = world.s.district.sites[place]
	if not site.vacant:
		if not can_enter(world, place):
			return "営業時間外。中には入れません。"
		return "営業中。食料 %.1f人日、水 %.1f Lを販売。放棄されたあとに拠点として使えます。" % [site.food, site.water]
	var state: String = ["未整備", "寝泊まり可能", "補強済み"][int(site.level)]
	return "拠点：%s。残存物資 食料 %.1f人日／水 %.1f L。置いた備蓄 食料 %.1f人日／水 %.1f L。" % [state, site.food, site.water, site.cache.food, site.cache.water]

static func bag_text(world) -> String:
	var bag: Dictionary = world.s.district.bag
	return "携行：食料 %.1f／%.0f人日、水 %.1f／%.0f L" % [bag.food, FOOD_LIMIT, bag.water, WATER_LIMIT]

static func _transfer(source: Dictionary, destination: Dictionary, food_limit: float, water_limit: float, batch_food: float, batch_water: float) -> Vector2:
	var food := minf(float(source.food), minf(batch_food, maxf(0.0, food_limit - float(destination.food))))
	var water := minf(float(source.water), minf(batch_water, maxf(0.0, water_limit - float(destination.water))))
	source.food -= food
	source.water -= water
	destination.food += food
	destination.water += water
	return Vector2(food, water)

static func _transfer_text(world, amount: Vector2, action: String) -> String:
	if amount == Vector2.ZERO:
		return "移せる物資か空き容量がない。"
	world.advance_safe(5)
	return "%s：食料 %.1f人日、水 %.1f L。\n%s" % [action, amount.x, amount.y, bag_text(world)]

static func act(world, place: String, command: String, at_home: bool) -> String:
	if world.s.health <= 0:
		return "死亡している。"
	var bag: Dictionary = world.s.district.bag
	if command == "物資を持っていく":
		if not at_home:
			return "自宅で備蓄を詰められます。外の拠点では「拠点の物資を持ち出す」。"
		return _transfer_text(world, _transfer(world.s, bag, FOOD_LIMIT, WATER_LIMIT, 2.0, 4.0), "自宅から持ち出した")
	if command == "物資を置く" and at_home:
		return _transfer_text(world, _transfer(bag, world.s, INF, INF, FOOD_LIMIT, WATER_LIMIT), "自宅の備蓄に戻した")
	if not SITES.has(place):
		return "建物の中で実行してください。"
	var site: Dictionary = world.s.district.sites[place]
	if not site.vacant:
		return "営業中や管理中の建物では実行できない。"
	match command:
		"物資を探索する":
			return _transfer_text(world, _transfer(site, bag, FOOD_LIMIT, WATER_LIMIT, 2.0, 4.0), "残っていた物資を回収した")
		"ここを拠点にする":
			if site.level >= 1:
				return "ここはすでに寝泊まりできる。"
			if world.advance_safe(20) < 20:
				return "拠点の整備が中断された。"
			site.level = 1
			return "%sを寝泊まりできる拠点にした。物資を置いたり、ここで一晩過ごしたりできる。" % place
		"拠点を補強する":
			if site.level != 1:
				return "先に拠点を整えるか、補強状態を確認してください。"
			if world.s.inventory.wood < 2 or world.s.inventory.parts < 1:
				return "補強には木材2・部品1が必要。"
			if world.advance_safe(30) < 30:
				return "補強が中断された。"
			world.s.inventory.wood -= 2
			world.s.inventory.parts -= 1
			site.level = 2
			return "拠点を補強した。外を通る感染者から身を隠せる。"
		"物資を置く", "拠点の物資を持ち出す":
			if site.level < 1:
				return "先に「ここを拠点にする」で置き場所を確保してください。"
			if command == "物資を置く":
				return _transfer_text(world, _transfer(bag, site.cache, 100.0, 200.0, FOOD_LIMIT, WATER_LIMIT), "拠点に置いた")
			return _transfer_text(world, _transfer(site.cache, bag, FOOD_LIMIT, WATER_LIMIT, FOOD_LIMIT, WATER_LIMIT), "拠点の備蓄から持ち出した")
	return "ここでは実行できない。"

static func buy(world, place: String, item: String, quantity: int) -> String:
	var site: Dictionary = world.s.district.sites[place]
	if world.s.health <= 0 or site.vacant or not can_enter(world, place):
		return "この店では現在購入できない。"
	if item not in ["food", "water"] or quantity < 1 or quantity > 12:
		return "ここで買えるのは食料と飲料水。数量は1～12です。"
	var amount := float(quantity) * (1.0 if item == "food" else 2.0)
	var price := quantity * (600 if item == "food" else 120)
	var bag: Dictionary = world.s.district.bag
	if world.s.cash < price or float(site[item]) < amount or float(bag[item]) + amount > (FOOD_LIMIT if item == "food" else WATER_LIMIT):
		return "現金・店の在庫・携行容量を確認してください。"
	site[item] -= amount
	bag[item] += amount
	world.s.cash -= price
	world.advance_safe(5)
	return "購入した。\n" + bag_text(world)

static func consume(world, place: String, item: String) -> bool:
	var need: String = "hunger" if item == "food" else "thirst"
	if float(world.s.health) <= 0 or float(world.s[need]) <= 0:
		return false
	var factor := 1.0 if item == "food" else 3.0
	var amount := minf(0.25 * factor, float(world.s[need]) * factor / 100.0)
	var bag: Dictionary = world.s.district.bag
	var cache: Dictionary = world.s.district.sites[place].cache if prepared(world, place) else {"food": 0.0, "water": 0.0}
	if float(bag[item]) + float(cache[item]) < amount:
		return false
	var from_cache := minf(float(cache[item]), amount)
	cache[item] -= from_cache
	bag[item] = maxf(0.0, float(bag[item]) - (amount - from_cache))
	world.s[need] = maxf(0.0, float(world.s[need]) - amount * 100.0 / factor)
	if item == "water":
		world.s.water_used += amount
	return true
