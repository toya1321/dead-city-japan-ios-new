extends RefCounted

const MAX_BOTTLES := 12
const STOP_BEFORE_RETURN := 10
const PHASES := ["quantity", "queued", "carrying", "returning", "done", "failed"]
const FAILURES := ["closed", "stock", "cash", "rationed", "stayed_home"]

static func intent(speech: String, person: Dictionary) -> Dictionary:
	var text := speech.strip_edges().trim_prefix("「").trim_suffix("」")
	for i in range(10):
		text = text.replace("０１２３４５６７８９"[i], str(i))
	var order: Dictionary = person.get("water_errand", {})
	var phase := str(order.get("phase", ""))
	var related := "水" in text or "買い物" in text or "頼み" in text
	var active := phase in ["quantity", "queued", "carrying", "returning"]
	var cancel := RegEx.new()
	cancel.compile("^(?:(?:やっぱり|やはり|あ、)[、 ]*)?(?:(?:水|飲料水|お水|買い物|頼み事|お願い)(?:のこと)?(?:は|を)?[、 ]*)?(?:やめ(?:て|といて|ておいて)|なし(?:で)?|いらない|要らない|買わなくていい(?:よ)?|キャンセル(?:して)?)[。！!]*$")
	if active and cancel.search(text) != null:
		return {"kind":"cancel"}
	var status := RegEx.new()
	status.compile("(?:どうだった|買えた|買ってきた|買えなかった|その後|どうなった|頼んだ水|水の(?:こと|件)|持って帰れた)")
	if not order.is_empty() and status.search(text) != null and (related or text in ["買えた？", "買えた?", "どうだった？", "どうだった?", "どうなった？"]):
		return {"kind":"status"}
	var request := RegEx.new()
	request.compile("^(?:(?:もし)?(?:買い物に行くなら|買い物に行くとき|買い物のついでに|出かけるなら|帰りに|ついでに|今日)[、 ]*)?(?:ペットボトルの)?(?:飲料水|お水|水)(?:を|も|は|、| )?(?:[0-9一二三四五六七八九十]+本(?:を|だけ|ほど|くらい)?[、 ]*)?(?:お願い(?:できる|してもいい|できないかな|できるかな|します|ね)?|頼(?:む|める|んでもいい)|買って(?:(?:きて|来て)(?:くれる|もらえる|くれない|もらえない|ほしい|ほしいな)?|くれる|もらえる|ほしい))[。？！?!]*$")
	var asks_water := request.search(text) != null
	var amount := RegEx.new()
	amount.compile("^(?:(?:じゃあ|やっぱり|うん)[、 ]*)?(?:(?:飲料水|お水|水)(?:を|は|も)?[、 ]*)?([0-9一二三四五六七八九十]+)本(?:だけ|くらい|ほど)?(?:で(?:いい(?:よ|です)?|十分(?:だよ|です)?|お願い(?:します|ね)?)|にして|お願い(?:します|ね)?|で)?[。！!]*$")
	var count_match := amount.search(text)
	if count_match == null and asks_water:
		var in_request := RegEx.new()
		in_request.compile("([0-9一二三四五六七八九十]+)本")
		count_match = in_request.search(text)
	if count_match != null and (asks_water or phase in ["quantity", "queued"]):
		var raw := count_match.get_string(1)
		var quantity := int(raw) if raw.is_valid_int() else ["零","一","二","三","四","五","六","七","八","九","十","十一","十二"].find(raw)
		return {"kind":"set", "quantity":quantity}
	if asks_water:
		return {"kind":"request"}
	return {}

static func reply(world, person: Dictionary, action: Dictionary) -> String:
	var order: Dictionary = person.get("water_errand", {})
	var phase := str(order.get("phase", ""))
	var active := phase in ["quantity", "queued", "carrying", "returning"]
	match action.kind:
		"status":
			if active:
				if phase == "quantity":
					return "まだ本数を聞いてなかったね。何本いる？"
				return "水%d本、帰りに寄ってみる予定だよ。" % int(order.quantity)
			order.reported = true
			return report_text(order)
		"cancel":
			if phase in ["carrying", "returning"]:
				return "もう店に寄ったよ。帰ってから結果を話すね。"
			person.erase("water_errand")
			return "分かった。水の頼みは取り消しておくね。"
	if phase in ["carrying", "returning"]:
		return "さっきの分はもう店に寄ったよ。"
	if action.kind == "request" and phase == "queued":
		return "水は%d本の予定だよ。変えるなら本数を教えて。" % int(order.quantity)
	var current := int(world.s.minute)
	var hour: float = world.hour_of_day()
	var until_return: int = world.HOUSEHOLD_RETURN * 60 - int(round(hour * 60))
	if world.household_activity_at(world.HOUSEHOLD_LEAVE) != "外出" or until_return <= STOP_BEFORE_RETURN:
		return "このあと買い物に寄る予定がないんだ。今日は引き受けられないよ。"
	var return_minute: int = current + until_return
	if action.kind == "request":
		person.water_errand = {"phase":"quantity", "quantity":0, "due":return_minute, "failure":"", "reported":false}
		return "うん。水、何本くらい？"
	var quantity := int(action.quantity)
	if quantity < 1 or quantity > MAX_BOTTLES:
		return "水は1本から%d本までなら頼めるよ。何本にする？" % MAX_BOTTLES
	person.water_errand = {"phase":"queued", "quantity":quantity, "due":return_minute, "failure":"", "reported":false}
	return "分かった。水%d本ね。帰りに寄ってみるよ。" % quantity

static func step(world, person: Dictionary) -> void:
	var order: Dictionary = person.get("water_errand", {})
	if order.is_empty():
		return
	var now := int(world.s.minute)
	var due := int(order.due)
	if order.phase == "quantity" and now >= due - STOP_BEFORE_RETURN:
		person.erase("water_errand")
		return
	if float(person.health) <= 0:
		return
	if order.phase == "queued" and now >= due - STOP_BEFORE_RETURN:
		order.failure = "stayed_home"
		if person.activity == "外出":
			person.location = "食品店"
			order.failure = world.buy_household_water(int(order.quantity))
		order.phase = "carrying" if order.failure.is_empty() else "returning"
	if now >= due and person.activity == "在宅":
		if order.phase == "carrying":
			world.s.water += float(world.CATALOG.water.amount) * int(order.quantity)
			order.phase = "done"
		elif order.phase == "returning":
			order.phase = "failed"

static func report_text(order: Dictionary) -> String:
	if order.get("phase") == "done":
		return "水、%d本買えたよ。家の飲み水に足しておいた。" % int(order.quantity)
	match str(order.get("failure", "")):
		"closed": return "店まで行ったけど、閉まってて水は買えなかった。"
		"stock": return "店に必要な本数が残ってなかった。水は買えなかったよ。"
		"cash": return "水を買うには手持ちのお金が足りなかったよ。"
		"rationed": return "店で本数制限があって、頼まれた本数は買えなかったよ。"
		"stayed_home": return "今日は外出を見送ったから、水は買えてないよ。"
	return ""

static func valid(order: Variant) -> bool:
	if not order is Dictionary or order.get("phase") not in PHASES or not order.get("reported") is bool:
		return false
	for key in ["quantity", "due"]:
		var n = order.get(key)
		if (not n is int and not n is float) or not is_finite(float(n)) or floorf(float(n)) != float(n):
			return false
	if int(order.due) < 0 or (int(order.quantity) != 0 if order.phase == "quantity" else int(order.quantity) < 1 or int(order.quantity) > MAX_BOTTLES):
		return false
	return order.get("failure") in FAILURES if order.phase in ["returning", "failed"] else order.get("failure") == ""
