extends SceneTree
const Main=preload("res://main.tscn")
var bad:=0
func check(ok:bool,label:String)->void:
	print(("PASS " if ok else "FAIL ")+label)
	if not ok:bad+=1
func _initialize()->void:call_deferred("run")
func run()->void:
	var g=Main.instantiate();root.add_child(g);await process_frame
	g._start_new_game(g.world.DEFAULT_PROFILE.duplicate(true));g._finish_intro()
	var paths:Dictionary={}
	var district_photos := {
		"コンビニ": "konbini",
		"近所の空き家": "vacant_house",
		"デパート": "department_store",
	}
	for place in g.Navigation.NODES + district_photos.keys():
		g.location=place;g._sync_player_position();g._refresh();await process_frame
		var path:String=g._scene_path()
		check(ResourceLoader.exists(path) and g.picture.texture!=null,"photo loads for "+place)
		check(g.picture.texture!=null and g.picture.texture.get_width()>=1280 and g.picture.texture.resource_path==path,"actual displayed photo matches location "+place)
		check(not paths.has(path),"location has distinct background "+place)
		paths[path]=true
		if district_photos.has(place):
			check(path=="res://assets/photos/"+district_photos[place]+".jpg","dedicated interior for "+place)
			check(g.preview_button.visible and not g.district_card.visible,"interior replaces placeholder at "+place)
			g.preview_button.pressed.emit()
			check(g.image_preview.visible and g.preview_texture.texture==g.picture.texture,"preview opens current interior at "+place)
			g._close_image_preview()
	var exact:PackedByteArray=var_to_bytes(g.world.s);g._refresh();g._refresh()
	check(exact==var_to_bytes(g.world.s),"photo refresh cannot mutate autonomous world")
	g.world.s.profile.housing="集合住宅";g.location="建物前";g._refresh()
	check(g.picture.texture.resource_path.ends_with("apartment.jpg"),"apartment entrance differs from detached home")
	g.world.s.minute=900;g.world.s.weather="rain";g._refresh()
	check(g.scene_view.hour>=18 and g.scene_view.weather=="rain","night and weather overlays use actual world")
	g.queue_free();await process_frame
	quit(0 if bad==0 else 1)
