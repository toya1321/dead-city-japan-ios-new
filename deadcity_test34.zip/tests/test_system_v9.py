"""Non-runtime structural regression for v9. Not a Godot execution test."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
w=(root/'scripts/world.gd').read_text(encoding='utf-8')+'\n'+(root/'scripts/world_legacy.gd').read_text(encoding='utf-8')
m=(root/'scripts/main.gd').read_text(encoding='utf-8')
scenes=root/'assets/scenes'
images=set(re.findall(r'_record_event\("[^"]+",\s*"[^"]+",\s*"([^"]+)"',w))
images.update(['entrance_normal','entrance_alert','shelter'])
checks={
    'event artwork exists': all((scenes/f'{x}.jpg').is_file() for x in images),
    'world advances events': '_simulate_daily_events(day)' in w and '_update_outbreak()' in w,
    'world generates events without UI': '_record_event(' not in m,
    'event memory is knowledge-gated': 'known_events.has(_event_id(e))' in m,
    'news learns regional events': 'if str(e.scope) == "regional":\n\t\t\t\t_remember_event(e)' in m,
 "window avoids unverifiable district sightings": 'world.Events.observe(world,channel,location)' in m,
    'save stores known events': '"known_events":known_events' in m,
    'load restores known events': 'known_events = loaded_known' in m,
    'event array bounded': 'if s.events.size() > 240' in w,
    'save validates event fields': 'for e in data.events:' in w,
    'orders charge money': 's.cash -= from_cash' in w and 's.bank -= price - from_cash' in w,
    'orders arrive only on time': 'int(s.minute) < int(order.due)' in w,
    'orders can fail': 'order.status = "failed"' in w,
    'orders have bounded quantity': 'if quantity < 1 or quantity > 12' in w,
    'order history persisted': '"orders":[]' in w and 'world.s = data["world"]' in m,
    'old save missing orders migrates': 'if not world.s.longplay.has("orders"):' in m,
    'door repair requires location': 'if location != "玄関": return "玄関で作業する必要がある。"' in m,
    'iPhone portrait reference': 'window/handheld/orientation=1' in (root/'project.godot').read_text(),
    'illustrations available': len(list(scenes.glob('*.jpg'))) >= 28,
}
for name,passed in checks.items():
    print(('PASS' if passed else 'FAIL')+' '+name)
assert all(checks.values()),'Structural regression failed'
print(f'PASSED {len(checks)} structural checks')
