extends SceneTree

const Main = preload("res://main.tscn")
const Errands = preload("res://scripts/household_errands.gd")
var failures := 0

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, label: String) -> void:
	print(("PASS " if condition else "FAIL ") + label)
	if not condition:
		failures += 1

func run() -> void:
	var game = Main.instantiate()
	root.add_child(game)
	await process_frame
	var profile: Dictionary = game.world.DEFAULT_PROFILE.duplicate(true)
	profile.cohabitants = 2
	profile.companion_names = ["詩音", "美咲"]
	game._start_new_game(profile)
	game._finish_intro()
	var world = game.world
	var cash: float = world.s.cash
	await game._on_command("詩音、買い物に行くなら水もお願いできる？")
	check(game.log_entries[-1].contains("何本くらい") and world.s.household_members[0].get("water_errand", {}).get("phase") == "quantity", "exact natural request asks for a missing quantity")
	check(game._save() == "保存した。" and game._load() == "保存データを読み込んだ。", "pending question survives saving and loading")
	await game._on_command("詩音を呼ぶ")
	await game._on_command("2本でいいよ")
	check(game.log_entries[-1].contains("水2本ね") and world.s.household_members[0].get("water_errand", {}).get("phase") == "queued", "count-only answer schedules purchase for the same NPC")
	check(float(world.s.cash) == cash, "nothing is charged during the conversation")
	await game._on_command("やっぱり二本で")
	check(world.s.household_members[0].water_errand.quantity == 2, "Japanese numeral correction replaces rather than duplicates order")
	await game._on_command("美咲、3本でいいよ")
	check(not world.s.household_members[1].has("water_errand"), "another NPC does not inherit the request")
	await game._on_command("詩音、水は買わなくていいよ")
	check(not world.s.household_members[0].has("water_errand"), "cancellation removes queued purchase")
	await game._on_command("詩音、帰りに水を２本買ってきてくれる？")
	var person: Dictionary = world.s.household_members[0]
	var due := int(person.water_errand.due)
	world.advance_safe(due - int(world.s.minute) - 11)
	check(person.activity == "外出" and person.water_errand.phase == "queued", "NPC goes out independently and visits the shop on the way back")
	var stock: float = world.s.shops.grocer.stock.water
	var water: float = world.s.water
	cash = world.s.cash
	var till: float = world.s.shops.grocer.till
	world.step(false)
	check(person.water_errand.phase == "carrying" and person.location == "食品店", "NPC purchases at the actual shop")
	check(float(world.s.cash) == cash - 240 and float(world.s.shops.grocer.stock.water) == stock - 4 and float(world.s.shops.grocer.till) == till + 240, "purchase updates cash, stock, and till")
	check(float(world.s.water) == water, "the bottles stay with the NPC until return")
	check(game._save() == "保存した。" and game._load() == "保存データを読み込んだ。", "carried purchase survives a restart")
	await game._on_command("10分待つ")
	check(world.s.household_members[0].water_errand.phase == "done" and float(world.s.water) == water + 4, "return deposits exactly two 2L bottles")
	check(game.log_entries[-1].contains("2本買えたよ"), "return results are reported to the player")
	await game._on_command("詩音、頼んだ水どうだった？")
	check(game.log_entries[-1].contains("2本買えたよ") and float(world.s.water) == water + 4, "follow-up recalls the result without depositing again")
	world.advance_safe(900)
	await game._on_command("詩音、昨日の水どうだった？")
	check(game.log_entries[-1].contains("2本買えたよ"), "the completed request is still recalled the next morning")

	for failure in ["stock", "closed", "cash", "rationed", "stayed_home"]:
		game._start_new_game(profile)
		game._finish_intro()
		await game._on_command("詩音、帰りに水を三本買ってきて")
		person = world.s.household_members[0]
		world.s.minute = int(person.water_errand.due) - 11
		person.activity = "外出"
		person.location = "屋外"
		match failure:
			"stock": world.s.shops.grocer.stock.water = 0
			"closed": world.s.shops.grocer.open = false
			"cash": world.s.cash = 0
			"rationed": world.s.sim.rationing = true
			"stayed_home":
				person.activity = "在宅"
				person.location = "居間"
		water = world.s.water
		cash = world.s.cash
		world.step(false)
		check(person.water_errand.failure == failure and float(world.s.cash) == cash, "%s prevents the sale" % failure)
		world.advance_safe(10)
		check(person.water_errand.phase == "failed" and float(world.s.water) == water and not Errands.report_text(person.water_errand).is_empty(), "%s is reported without adding water" % failure)

	game.queue_free()
	await process_frame
	quit(0 if failures == 0 else 1)
