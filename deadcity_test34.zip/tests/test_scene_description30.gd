extends SceneTree

const Main = preload("res://main.tscn")
const Navigation = preload("res://scripts/navigation.gd")
const SceneDescription = preload("res://scripts/scene_description.gd")
var failures := 0

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, description: String) -> void:
	print(("PASS " if condition else "FAIL ") + description)
	if not condition:
		failures += 1

func run() -> void:
	var game = Main.instantiate()
	root.add_child(game)
	await process_frame
	game._start_new_game(game.world.DEFAULT_PROFILE.duplicate(true))
	game._finish_intro()
	var world = game.world

	await game._on_command("台所へ行く")
	var result: String = game.log_entries[-1]
	check(game.location == "台所" and result.contains("調理台") and result.contains("「食事する」"), "normal movement describes the destination and suggests a valid action")
	check(not result.contains("新しく確認できた出来事はない"), "arrival omits empty event filler")
	check(world.s.minute == 2, "arrival prose adds no time to the route")
	var before: PackedByteArray = var_to_bytes(world.s)
	for place in Navigation.all_nodes():
		check(not SceneDescription.describe(world, place).get_slice("\n", 0).is_empty(), "scene prose exists for " + place)
	check(before == var_to_bytes(world.s), "writing the scene does not advance or change the world")

	await game._on_command("玄関へ行く")
	check(game.log_entries[-1].contains("鍵がかかっている"), "arrival reflects a locked entrance")
	var minute := int(world.s.minute)
	await game._on_command("外に出る")
	check(world.s.minute == minute and not game.log_entries[-1].contains("家の並ぶ通り"), "a failed move never describes arrival")

	await game._on_command("鍵を開ける")
	await game._on_command("コンビニへ行く")
	check(game.location == "コンビニ" and game.log_entries[-1].contains("冷蔵ケース") and game.log_entries[-1].contains("営業中") and game.log_entries[-1].contains("水を買う"), "open store shows shopping guidance")
	await game._on_command("周囲を見る")
	check(game.log_entries[-1].contains("冷蔵ケース") and game.log_entries[-1].contains("食料 8.0人日"), "looking again describes the scene and retains local stock details")

	await game._on_command("近所の空き家へ行く")
	check(game.location == "近所の空き家" and game.log_entries[-1].contains("和室") and game.log_entries[-1].contains("「ここを拠点にする」"), "vacant house suggests exploration and preparing a shelter")
	await game._on_command("ここを拠点にする")
	await game._on_command("周囲を見る")
	check(game.log_entries[-1].contains("ここで一晩過ごす") and not game.log_entries[-1].contains("「ここを拠点にする」"), "prepared shelter describes overnight use")
	await game._on_command("デパートへ行く")
	check(game.location == "近所の空き家" and game.log_entries[-1].contains("営業時間外") and not game.log_entries[-1].contains("陳列台"), "closed destination never reveals its indoor scene")

	world.s.weather = "rain"
	var current_minute := int(world.s.minute)
	world.Events.emit_event(world, "near_test", "住宅街で見える出来事。", {}, "sight", -1, [-26.0,37.0], true)
	world.Events.emit_event(world, "far_test", "遠くの非公開の出来事。", {}, "sight", -1, [300.0,300.0], true)
	await game._on_command("住宅街へ行く")
	result = game.log_entries[-1]
	check(world.s.minute == current_minute + 2 and result.contains("雨") and result.contains("住宅街で見える出来事。") and not result.contains("遠くの非公開の出来事。"), "outdoor arrival reflects weather and only visible events")

	await game._on_command("自宅に帰る")
	check(game.location == "玄関" and game.log_entries[-1].contains("たたき"), "returning home narrates the entrance")
	game.queue_free()
	await process_frame
	quit(0 if failures == 0 else 1)
