# iPhone landscape design — v8

- Primary orientation: landscape (Godot `window/handheld/orientation=0`).
- Reference viewport: 1280×720. Godot stretch mode: canvas_items.
- Wide screens: left survival status, central illustration/narration/input, right world state and changing illustration timeline.
- Narrow landscape screens: prioritize illustration, narrative and action input; hide side columns while retaining status access through menu commands.
- Vertical scrolling handles short screens and keyboard appearance; no portrait-specific UI is targeted.
- No new illustration generation is included in this revision.

## Work acceptance checklist
1. Open in Godot 4.4+ and run scene; fix parser errors if any.
2. Check landscape at 852×393, 932×430, 1179×510, 1280×720.
3. Check safe-area/notch, text input with software keyboard, scrolling, tap targets, no clipped narration.
4. Test commands, save/load, background progression and illustration switching.
5. iOS export should support landscape orientation; verify Xcode export orientation settings and real iPhone rotation lock behavior.
