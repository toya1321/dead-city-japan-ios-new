extends SceneTree
# Native QA: prefill text only. A human/tool taps the real Send button. This
# script is excluded from exports and never changes stocks/health/world rules.
func _initialize()->void:call_deferred("run")
func run()->void:
	Input.emulate_touch_from_mouse=true
	Input.emulate_mouse_from_touch=true
	var game=load("res://main.tscn").instantiate();root.add_child(game)
	game._start_new_game(game.world.DEFAULT_PROFILE.duplicate(true));game._finish_intro()
	for command in ["台所へ行って食事し、水を飲んでからニュースを見る","玄関へ行って鍵を開けて食品店へ行く","家に帰って7日待つ"]:
		await create_timer(1.0).timeout
		game.command_input.text=command
		while not game.command_input.text.is_empty():await process_frame
		while game.advancing:await process_frame
