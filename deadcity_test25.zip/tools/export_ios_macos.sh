#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
engine="${GODOT:-godot}"
if [[ "$(uname -s)" != Darwin ]]; then
  echo 'iOS export requires macOS + Xcode. This script creates an Xcode project, not a signed IPA.' >&2
  exit 2
fi
command -v "$engine" >/dev/null
command -v xcodebuild >/dev/null
xcodebuild -version
if ! "$engine" --version | head -1 | awk '/^4\.6\.3\./ { found=1 } END { exit !found }'; then
  echo 'Use Godot 4.6.3 and matching export templates for this tested package.' >&2
  exit 2
fi
if /usr/bin/grep -q 'application/app_store_team_id=""' "$project_dir/export_presets.cfg"; then
  echo 'Set your Team ID locally in Project > Export > iOS Test. Do not send account credentials.' >&2
  exit 2
fi
mkdir -p "$project_dir/build/ios"
"$engine" --headless --path "$project_dir" --editor --import --quit
"$engine" --headless --path "$project_dir" --export-debug 'iOS Test' "$project_dir/build/ios/Chronicle.zip"
echo 'Open the generated .xcodeproj; set Signing & Capabilities and run on your connected iPhone.'
