extends SceneTree
# Desktop QA only: real mouse input is converted by Godot to touch input.
func _initialize() -> void:call_deferred("run")
func run() -> void:
	Input.emulate_touch_from_mouse=true
	Input.emulate_mouse_from_touch=true
	var game=load("res://main.tscn").instantiate()
	root.add_child(game)
	game._start_new_game(game.world.DEFAULT_PROFILE.duplicate(true))
	game._finish_intro()
