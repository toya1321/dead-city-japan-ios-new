extends SceneTree
const World=preload("res://scripts/world.gd")
func _initialize()->void:call_deferred("run")
func run()->void:
	var w=World.new();var loaded=World.new();var start:=Time.get_ticks_msec()
	# Pure world stress beyond player death, not unattended player survival.
	for day in range(1,3651):
		for minute in range(1440):w.step(false)
		if day in [365,1095,3650]:
			if not w.validate_state(w.s):push_error("FAIL invalid longplay state");quit(1);return
			if w.save_file("user://stress10.save")!=OK or loaded.load_file("user://stress10.save")!=OK:push_error("FAIL save/load");quit(1);return
			for minute in range(60):w.step(false);loaded.step(false)
			if var_to_bytes(w.s)!=var_to_bytes(loaded.s):push_error("FAIL continuation");quit(1);return
			w.load_file("user://stress10.save")
			print("PASS STRESS day=",day," elapsed_ms=",Time.get_ticks_msec()-start," bytes=",var_to_bytes(w.s).size()," records=",w.s.events.size()," archived=",w.s.sim.archived_total)
		if day%30==0:await process_frame
	# Boundary fixture for calendar/numeric handling after 30 years. This is
	# additional boundary coverage, not a claim of 30 years fully simulated.
	w.s.minute=30*365*1440-30
	for minute in range(60):w.step(false)
	if not w.validate_state(w.s):push_error("FAIL year30 boundary");quit(1);return
	print("PASS year30 calendar boundary ",w.clock())
	print("LONGPLAY 10 YEARS: PASS")
	quit()
