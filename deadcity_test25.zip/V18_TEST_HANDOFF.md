# v18 iPhone landscape test candidate

## Actual changes
- Anchored duration parser: rejects compound/negative/ambiguous waits rather than silently running the first recognized part.
- Observation guard: cannot view an indoor window from an unrelated room.
- Image audit: 28 images are backgrounds/thematic art, **not** complete event-specific illustrations. UI does not assert event-specific visual coverage.
- Bounded deterministic multi-day API: 1–7 days in 24-hour chunks; **not** optimized for decades.
- Godot headless regression test: `godot --headless --path . --script res://tests/test_v18_runtime.gd`.

## Unverified / blocking issues
- Godot 4 executable not available in this environment: no runtime test was run.
- iPhone IPA build and real device display have not been tested.
- NPC movement remains approximate; route mesh/obstacle navigation and actual home interiors are not implemented.
- Natural-language input remains a limited rule-based parser.
- Event-specific art is not complete.
- Multi-decade simulation is not performant/validated.

Do not describe this as complete or IPA-ready. Test in Godot before sending to Work for export.
