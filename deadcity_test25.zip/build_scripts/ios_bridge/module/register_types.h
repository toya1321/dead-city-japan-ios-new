#pragma once
// SCons uses this file to discover modules. The build targets only bridge.cpp;
// the exported app calls dcj_apple_plugin_init via the iOS plugin descriptor.
