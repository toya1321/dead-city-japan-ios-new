#include "core/config/engine.h"
#include "core/object/class_db.h"
#include "core/os/memory.h"

#include <cstdlib>
#include <cstdint>

extern "C" {
char *dcj_apple_ai_availability();
void dcj_apple_ai_begin(int64_t id, const char *instructions, const char *input);
char *dcj_apple_ai_take_result(int64_t id);
void dcj_apple_ai_cancel(int64_t id);
}

class DCJAppleAI : public Object {
	GDCLASS(DCJAppleAI, Object);

	static String consume_string(char *text) {
		if (!text) {
			return String();
		}
		String result = String::utf8(text);
		std::free(text);
		return result;
	}

protected:
	static void _bind_methods() {
		ClassDB::bind_method(D_METHOD("availability"), &DCJAppleAI::availability);
		ClassDB::bind_method(D_METHOD("begin", "id", "instructions", "input"), &DCJAppleAI::begin);
		ClassDB::bind_method(D_METHOD("take_result", "id"), &DCJAppleAI::take_result);
		ClassDB::bind_method(D_METHOD("cancel", "id"), &DCJAppleAI::cancel);
	}

public:
	String availability() {
		return consume_string(dcj_apple_ai_availability());
	}

	void begin(int64_t id, const String &instructions, const String &input) {
		dcj_apple_ai_begin(id, instructions.utf8().get_data(), input.utf8().get_data());
	}

	String take_result(int64_t id) {
		return consume_string(dcj_apple_ai_take_result(id));
	}

	void cancel(int64_t id) {
		dcj_apple_ai_cancel(id);
	}
};

static DCJAppleAI *singleton = nullptr;

extern "C" void dcj_apple_plugin_init() {
	ClassDB::register_class<DCJAppleAI>();
	singleton = memnew(DCJAppleAI);
	Engine::get_singleton()->add_singleton(Engine::Singleton("DCJAppleAI", singleton));
}

extern "C" void dcj_apple_plugin_deinit() {
	if (singleton) {
		Engine::get_singleton()->remove_singleton("DCJAppleAI");
		memdelete(singleton);
		singleton = nullptr;
	}
}
