#!/bin/bash
set -euo pipefail
BRIDGE_DIR="$(cd "$(dirname "$0")" && pwd)"
GAME_DIR="$(cd "$BRIDGE_DIR/../.." && pwd)"
TOOLS="$GAME_DIR/build/tools"
RELEASE=4.6.3-stable
ENGINE="$TOOLS/godot-$RELEASE"
SDK="$(xcrun --sdk iphoneos --show-sdk-path)"

mkdir -p "$TOOLS" "$GAME_DIR/ios/plugins"
if [[ ! -d "$ENGINE" ]]; then
  curl -fLsS --retry 3 "https://github.com/godotengine/godot/archive/refs/tags/$RELEASE.tar.gz" -o "$TOOLS/engine.tar.gz"
  tar -xzf "$TOOLS/engine.tar.gz" -C "$TOOLS"
fi
python3 -m venv "$TOOLS/plugin-venv"
"$TOOLS/plugin-venv/bin/pip" -q install scons==4.9.1
mkdir -p "$ENGINE/modules/dcj_apple_bridge"
cp "$BRIDGE_DIR/module/"* "$ENGINE/modules/dcj_apple_bridge/"
(
  cd "$ENGINE"
  "$TOOLS/plugin-venv/bin/scons" platform=ios target=template_release arch=arm64     ios_simulator=no ios_min_version=16.0 dcj_apple_bridge_object
)
OBJECT="$(find "$ENGINE" -type f -name 'bridge*.o' -print -quit)"
if [[ -z "$OBJECT" ]]; then
  echo "Godot compiled the bridge but its object file could not be located." >&2
  find "$ENGINE" -type f -iname "*bridge*"
  exit 1
fi
echo "Bridge object: $OBJECT"
xcrun --sdk iphoneos swiftc -sdk "$SDK" -target arm64-apple-ios16.0 -swift-version 5   -parse-as-library -O -emit-object "$BRIDGE_DIR/AppleModel.swift" -o "$TOOLS/AppleModel.o"
xcrun --sdk iphoneos libtool -static -o "$GAME_DIR/ios/plugins/DCJAppleAI.a" "$OBJECT" "$TOOLS/AppleModel.o"
cp "$BRIDGE_DIR/DCJAppleAI.gdip" "$GAME_DIR/ios/plugins/"
