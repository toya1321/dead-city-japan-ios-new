import Darwin
import Foundation
import FoundationModels

@available(iOS 26.0, *)
private enum AppleModel {
    static func availability() -> String {
        switch SystemLanguageModel.default.availability {
        case .available: return "available"
        case .unavailable(let reason):
            switch reason {
            case .deviceNotEligible: return "deviceNotEligible"
            case .appleIntelligenceNotEnabled: return "appleIntelligenceNotEnabled"
            case .modelNotReady: return "modelNotReady"
            @unknown default: return "unavailable"
            }
        @unknown default: return "unavailable"
        }
    }

    static func respond(instructions: String, input: String) async -> [String: String] {
        let status = availability()
        guard status == "available" else { return ["error": status] }
        do {
            let session = LanguageModelSession(model: SystemLanguageModel.default, instructions: instructions)
            let response = try await session.respond(
                to: input,
                options: GenerationOptions(temperature: 0, maximumResponseTokens: 768)
            )
            return ["content": response.content]
        } catch {
            let detail = error as NSError
            return ["error": "\(detail.domain) / \(detail.code)"]
        }
    }
}

// Godot polls from its own thread. A canceled task cannot publish into a
// newer request, even when Foundation Models finishes after cancellation.
private final class ModelMailbox: @unchecked Sendable {
    static let shared = ModelMailbox()
    private let lock = NSLock()
    private var token = UUID()
    private var requestID: Int64 = 0
    private var result: String?
    private var task: Task<Void, Never>?

    func begin(id: Int64, instructions: String, input: String) {
        lock.lock()
        defer { lock.unlock() }
        task?.cancel()
        let current = UUID()
        token = current
        requestID = id
        result = nil
        task = Task {
            let reply: [String: String]
            if #available(iOS 26.0, *) {
                reply = await AppleModel.respond(instructions: instructions, input: input)
            } else {
                reply = ["error": "unsupportedOS"]
            }
            guard !Task.isCancelled else { return }
            finish(token: current, reply: reply)
        }
    }

    private func finish(token completed: UUID, reply: [String: String]) {
        lock.lock()
        defer { lock.unlock() }
        guard token == completed else { return }
        if let bytes = try? JSONSerialization.data(withJSONObject: reply) {
            result = String(decoding: bytes, as: UTF8.self)
        } else {
            result = "{\"error\":\"encoding_error\"}"
        }
        task = nil
    }

    func take(id: Int64) -> String? {
        lock.lock()
        defer { lock.unlock() }
        guard requestID == id, let reply = result else { return nil }
        result = nil
        return reply
    }

    func cancel(id: Int64) {
        lock.lock()
        defer { lock.unlock() }
        guard requestID == id else { return }
        token = UUID()
        task?.cancel()
        task = nil
        result = nil
        requestID = 0
    }
}

@_cdecl("dcj_apple_ai_availability")
func dcjAvailability() -> UnsafeMutablePointer<CChar>? {
    if #available(iOS 26.0, *) { return strdup(AppleModel.availability()) }
    return strdup("unsupportedOS")
}

@_cdecl("dcj_apple_ai_begin")
func dcjBegin(_ id: Int64, _ instructions: UnsafePointer<CChar>, _ input: UnsafePointer<CChar>) {
    ModelMailbox.shared.begin(id: id, instructions: String(cString: instructions), input: String(cString: input))
}

@_cdecl("dcj_apple_ai_take_result")
func dcjTakeResult(_ id: Int64) -> UnsafeMutablePointer<CChar>? {
    guard let result = ModelMailbox.shared.take(id: id) else { return nil }
    return strdup(result)
}

@_cdecl("dcj_apple_ai_cancel")
func dcjCancel(_ id: Int64) {
    ModelMailbox.shared.cancel(id: id)
}
