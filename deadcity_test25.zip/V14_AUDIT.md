# v14 audit — current limitations are explicit

## Implemented in source
- A bounded Japanese natural-language duration command: `N分/時間/日 待つ/経過/過ごす` (up to 24h per command). Other free text is still keyword rules, not general language understanding.
- NPC home/work/shop destination coordinates and deterministic travel toward them. This is **not** obstacle-aware pathfinding, not independent room navigation, and is not yet a complete commute model. Residents may fail to reach destinations in the simplified road geometry.
- Removed global `census()` leakage from window observation; world knowledge remains separate.
- Generated machine-readable event-to-illustration reference catalog. Existing images are reused; **no new dedicated event illustrations**.
- `advance` capped at 1 day to avoid unbounded UI hangs. This **does not** make decade-long simulation fast. A performance benchmark and simulation-level fast-forward are still required.

## Verification
Static contract test and zip integrity can run here. Godot runtime and iPhone device tests are NOT verified until executed in an installed Godot environment. Tests: `python tests/test_v14_contract.py` and `godot --headless --path . --script res://tests/test_v14_runtime.gd`.
