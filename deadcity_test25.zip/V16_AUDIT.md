# v16 audit and fixes

This release focuses on correctness rather than feature-count claims.

- Fixed a confirmed save compatibility bug: the UI previously migrated only world versions 15/16, rejecting newer v17–v20 worlds even though the world model supported legacy migration.
- Migration now retains household snapshots, resident food shortage counters, existing destinations and home/work coordinates, instead of resetting them.
- Added a conservative negation guard before state-mutating command handlers. This does not constitute natural-language understanding; mixed positive/negative instructions still need a proper intent parser.
- Added static contract and Godot runtime regression tests.

Not verified here: Godot compilation, iPhone execution, illustration completeness, decade-scale performance. Do not present this as finished.
