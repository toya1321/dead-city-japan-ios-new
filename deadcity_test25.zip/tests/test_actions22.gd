extends SceneTree
const Main=preload("res://main.tscn")
const World=preload("res://scripts/world.gd")
var failures:Array[String]=[]
func check(ok:bool,label:String)->void:
	print(("PASS " if ok else "FAIL ")+label)
	if not ok:failures.append(label)
func _initialize()->void:call_deferred("run")
func btn(node:Node,label:String)->Button:
	for child in node.get_children():
		if child is Button and child.text==label:return child
		var found:=btn(child,label)
		if found!=null:return found
	return null
func run()->void:
	root.content_scale_size=Vector2i.ZERO;root.size=Vector2i(1280,720)
	var g=Main.instantiate();root.add_child(g);await process_frame
	g._start_new_game(g.world.DEFAULT_PROFILE.duplicate(true));g._finish_intro();await process_frame
	g.location="台所";g._sync_player_position()
	g.world.s.inventory.bandage=1;g.world.s.injuries=2
	g._on_command("傷を手当てする")
	check(g.world.s.inventory.bandage==0 and g.world.s.injuries==0 and g.world.s.minute==10,"medical treatment consumes bandage and time")
	g.world.s.inventory.wood=1;g.world.s.inventory.parts=1;g.world.s.longplay.shelter_integrity=80
	g._on_command("住居を修繕")
	check(g.world.s.inventory.wood==0 and g.world.s.inventory.parts==0 and g.world.s.longplay.shelter_integrity==95,"home repair consumes both materials")
	g.world.s.equipment.filter=true;g.world.s.rain_water=10;g.world.s.water=2;var water:float=g.world.s.water
	g._on_command("浄水する")
	check(is_equal_approx(g.world.s.water,water+0.8) and g.world.s.rain_water<10,"purification converts finite rainwater")
	g.world.s.plots=[{"growth":1.0,"water":0.0}];var food:float=g.world.s.food
	g._on_command("収穫")
	check(is_equal_approx(g.world.s.food,food+0.5) and g.world.s.inventory.harvest==1 and g.world.s.plots[0].growth==0,"mature harvest consumes grown crop")
	g.location="廊下";g._sync_player_position();g._refresh();await process_frame
	check(g._interpret("窓から外を見る").contains("観察できない"),"hall text rejects inaccessible window observation")
	g.location="薬局";g._sync_player_position();g._refresh();await process_frame
	check(not g._interpret("近くの住民を観察").contains("屋外に出る"),"street shop permits nearby observation")
	var w=World.new();w.s.profile.job="自営業";w.s.sim.payroll=3500
	var bank:int=w.s.bank;w.work_at_home()
	check(w.s.bank==bank+3000 and w.s.sim.payroll<=500,"freelance pay uses own 3000 yen threshold")
	w=World.new();w.s.profile.job="学生";w.s.sim.payroll=0
	w.work_at_home()
	check(w.s.sim.study_sessions==1 and w.s.minute==120 and w.s.bank==250000,"study does not require payroll or create money")
	w=World.new();w.s.profile.job="会社員";w.s.grid_online=false;w.s.equipment.battery=true;w.s.battery=1.01
	bank=w.s.bank;w.work_at_home()
	check(w.s.minute<240 and w.s.bank==bank,"power exhaustion interrupts actual work with no payment")
	# Equivalent natural-language clauses must use the same engine route.
	var other=Main.instantiate();root.add_child(other);await process_frame
	other._start_new_game(other.world.DEFAULT_PROFILE.duplicate(true));other._finish_intro()
	g._start_new_game(g.world.DEFAULT_PROFILE.duplicate(true));g._finish_intro();await process_frame
	await g._on_command("玄関へ行って鍵を開けて屋外へ行く")
	for command in ["玄関へ行く","鍵を開ける","屋外へ行く"]:other._interpret(command)
	check(g.location==other.location and var_to_bytes(g.world.s)==var_to_bytes(other.world.s),"compound text and individual actions produce identical route and world")
	check(g.world.validate_state(g.world.s),"all actions leave valid persistent state")
	g.queue_free();other.queue_free();await process_frame
	print("ACTIONS22: ",failures.size()," failures")
	quit(0 if failures.is_empty() else 1)
