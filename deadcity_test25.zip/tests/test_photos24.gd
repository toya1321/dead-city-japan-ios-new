extends SceneTree
const Main=preload("res://main.tscn")
var bad:=0
func check(ok:bool,label:String)->void:
	print(("PASS " if ok else "FAIL ")+label)
	if not ok:bad+=1
func _initialize()->void:call_deferred("run")
func run()->void:
	var g=Main.instantiate();root.add_child(g);await process_frame
	g._start_new_game(g.world.DEFAULT_PROFILE.duplicate(true));g._finish_intro()
	var paths:Dictionary={}
	for place in g.Navigation.NODES:
		g.location=place;g._sync_player_position();g._refresh();await process_frame
		var path:String=g._scene_path()
		check(ResourceLoader.exists(path) and g.picture.texture!=null,"photo loads for "+place)
		check(g.picture.texture.get_width()>=1280 and g.picture.texture.resource_path==path,"actual displayed photo matches location "+place)
		check(not paths.has(path),"location has distinct background "+place)
		paths[path]=true
	var exact:PackedByteArray=var_to_bytes(g.world.s);g._refresh();g._refresh()
	check(exact==var_to_bytes(g.world.s),"photo refresh cannot mutate autonomous world")
	g.world.s.profile.housing="集合住宅";g.location="建物前";g._refresh()
	check(g.picture.texture.resource_path.ends_with("apartment.jpg"),"apartment entrance differs from detached home")
	g.world.s.minute=900;g.world.s.weather="rain";g._refresh()
	check(g.scene_view.hour>=18 and g.scene_view.weather=="rain","night and weather overlays use actual world")
	g.queue_free();await process_frame
	quit(0 if bad==0 else 1)
