extends SceneTree
const World=preload("res://scripts/world.gd")
const E=preload("res://scripts/world_events.gd")
var failures:Array[String]=[]
func check(ok:bool,label:String)->void:
	print(("PASS " if ok else "FAIL ")+label)
	if not ok:failures.append(label)
func _initialize()->void:call_deferred("run")
func physical(w:RefCounted)->PackedByteArray:
	var copy:Dictionary=w.s.duplicate(true)
	copy.erase("events");copy.erase("last_news")
	for key in ["last_events","event_counts","next_event_id","active","archived_total","archive_years"]:copy.sim.erase(key)
	return var_to_bytes(copy)
func fixture(d:Dictionary)->RefCounted:
	var w=World.new()
	var hour:=9 if d.id in ["commute","school","clinic"] else (12 if d.id=="lunch" else (10 if d.id=="delivery" else 11))
	w.s.minute=35*1440+(hour-8)*60 # Tuesday weekday
	w.s.society={"normal":"normal","alert":"alert","disrupted":"disrupted","long":"emergency","all":"normal"}.get(d.phase,"normal")
	w.s.regional_cases=50;w.s.sim.hospital_load=30;w.s.sim.security=70
	w.s.shops.grocer.stock.food=10.0
	w.s.weather="cloudy"
	w.s.agents[1].health=70
	for a in w.s.agents:
		if a.occupation=="retail":a.health=70
	if d.id=="clear":w.s.weather="rain"
	if d.id=="abandoned":
		for a in w.s.agents:
			if a.occupation=="retail":a.dead=true
	if d.id=="mutual_aid":
		var a:Dictionary=w.s.agents[0];var b:Dictionary=w.s.agents[1]
		a.kind="survivor";b.kind="survivor";a.supplies=5.0;b.supplies=0.0;b.household=a.household;b.x=a.x;b.z=a.z
	if d.id=="repair_grid":w.s.grid_online=false
	if d.id=="repair_water":w.s.water_online=false
	if d.id=="return":w.s.agents[2].departed=true
	if d.id=="pests":w.s.plots=[{"growth":0.6,"water":1.0,"ready":false}]
	if d.id=="filter_wear":w.s.equipment.filter=true;w.s.longplay.water_collected=10.0
	if d.id=="crop_care":w.s.sim.gardens=2
	return w
func run()->void:
	check(E.catalog().size()>=40,"at least 40 stateful catalogue events")
	var kinds:Dictionary={}
	for d in E.catalog():
		var w=fixture(d)
		check(not kinds.has(d.id),"unique catalogue id "+d.id);kinds[d.id]=true
		var before:=physical(w)
		check(E.trigger(w,d.id),"eligible event triggers: "+d.id)
		check(before!=physical(w),"event changes physical simulation: "+d.id)
		check(w.s.events.size()>0 and w.s.events[-1].kind==d.id and not w.s.events[-1].effects.is_empty(),"event history references real effect: "+d.id)
		var after:=var_to_bytes(w.s)
		check(not E.trigger(w,d.id) and after==var_to_bytes(w.s),"cooldown prevents duplicate transaction: "+d.id)
	var w=World.new()
	w.s.shops.grocer.stock.food=0.0
	var total:float=w.s.sim.warehouse.food+w.s.shops.grocer.stock.food
	E.restock(w)
	check(is_equal_approx(total,w.s.sim.warehouse.food+w.s.shops.grocer.stock.food),"delivery conserves finite food")
	var def:Dictionary={"id":"blackout","phase":"disrupted"}
	w=World.new();w.s.society="disrupted"
	check(E.trigger(w,"blackout") and not w.s.grid_online,"outage stops actual power")
	check(E.observe(w,"tv","居間").is_empty(),"unreported event cannot be learned early")
	w.s.minute+=60
	check(not E.observe(w,"radio","居間").is_empty(),"broadcast becomes available after report delay")
	E.emit_event(w,"remote_test","見えない遠方の出来事",{"physical":true},"sight",-1,[1000.0,1000.0],true)
	var seen:=E.observe(w,"sight","寝室")
	check(seen.is_empty(),"remote sight event remains undisclosed")
	check(w.save_file("user://rev21-active.save")==OK,"save active outage")
	var loaded=World.new();check(loaded.load_file("user://rev21-active.save")==OK,"load active outage")
	for minute in range(180):w.step(false);loaded.step(false)
	check(var_to_bytes(w.s)==var_to_bytes(loaded.s),"exact continuation includes active cooldowns and NPC schedules")
	var bad:Dictionary=w.s.duplicate(true);bad.events[-1].position="bad"
	check(not w.validate_state(bad),"corrupt event coordinates rejected")
	var archive=World.new()
	for i in range(2000):E.emit_event(archive,"archive_test","記録",{"n":i},"broadcast",-1,[],true)
	check(archive.s.events.size()==240 and archive.s.sim.archived_total==1760 and archive.s.sim.event_counts.archive_test==2000,"bounded detailed records preserve archived counts")
	var old:Dictionary=World.new().s.duplicate(true);old.erase("sim");old.erase("profile");old.erase("household_members")
	check(not World.new().migrate_legacy(old).is_empty(),"v19 version22 state upgrades without reset")
	var a=World.new();var b=World.new();b.s.seed+=17
	for minute in range(14*1440):a.step(false);b.step(false)
	check(a.validate_state(a.s) and b.validate_state(b.s),"two independently progressed worlds valid after 14 days")
	check(var_to_bytes(a.s.sim.regions)!=var_to_bytes(b.s.sim.regions),"seed changes independent epidemic trajectory")
	print("SIMULATION day14 cases=",a.s.regional_cases," phase=",a.s.society," records=",a.s.sim.event_counts)
	var depart=World.new();depart.s.agents[0].departed=true;depart.s.agents[0].supplies=0.0
	var health:float=depart.s.agents[0].health
	depart.s.minute=1439;depart.step(false)
	check(depart.s.agents[0].health<health,"departed NPC continues finite survival off map")
	var crop=World.new();crop.s.sim.gardens=1;crop.s.sim.garden_planted_at=0
	crop.s.minute=180;var food:float=crop.s.sim.warehouse.food
	E._apply(crop,"crop_care")
	check(crop.s.sim.warehouse.food==food,"new garden cannot harvest immediately")
	crop.s.minute=31*1440;E._apply(crop,"crop_care")
	check(crop.s.sim.warehouse.food>food,"mature cared garden yields seasonal finite harvest")
	print("REVISION21 EVENTS: ",failures.size()," failures")
	quit(0 if failures.is_empty() else 1)
