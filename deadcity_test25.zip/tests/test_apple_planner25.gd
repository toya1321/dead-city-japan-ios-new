extends SceneTree

const Main = preload("res://main.tscn")
const Apple = preload("res://scripts/apple_planner.gd")
var failures := 0

class FakeBridge extends RefCounted:
	var next_content := ""
	var pending := 0
	var request_count := 0
	var cancel_count := 0
	var delayed := false
	var state := "available"
	var input_context: Dictionary

	func availability() -> String:
		return state

	func begin(id: int, _instructions: String, input: String) -> void:
		pending = id
		request_count += 1
		input_context = JSON.parse_string(input)

	func take_result(id: int) -> String:
		if id != pending or delayed:
			return ""
		pending = 0
		return JSON.stringify({"content": next_content})

	func cancel(id: int) -> void:
		if id == pending:
			cancel_count += 1
			pending = 0

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, description: String) -> void:
	print(("PASS " if condition else "FAIL ") + description)
	if not condition:
		failures += 1

func output(commands: Array) -> String:
	return JSON.stringify({"actions": commands.map(func(c): return {"kind":"command","command":c})})

func waiting(duration: String, care: bool, minutes: int = 480) -> String:
	return JSON.stringify({"actions":[{"kind":"wait","duration":duration,"care":care,"minutes":minutes}]})

func run() -> void:
	var bridge := FakeBridge.new()
	Engine.register_singleton(Apple.SINGLETON, bridge)
	var game = Main.instantiate()
	root.add_child(game)
	await process_frame
	game._start_new_game(game.world.DEFAULT_PROFILE.duplicate(true))
	game._finish_intro()

	var before := str(game.picture.texture.resource_path)
	var start_time := int(game.world.s.minute)
	var start_water := float(game.world.s.water_used)
	bridge.next_content = output(["台所へ行く","水を飲む","ニュースを見る"])
	await game._on_command("キッチンで喉を潤して、それから報道をチェック")
	check(bridge.request_count == 1 and game.last_plan.ok, "unrecognized free text reaches the Apple bridge through command submission")
	check(game.location == "台所" and str(game.picture.texture.resource_path) != before, "AI movement updates actual location and picture")
	check(float(game.world.s.water_used) > start_water and int(game.world.s.minute) > start_time and game.log_entries[-1].contains("情報源"), "water, clock and news change through actual game actions")
	check(bridge.input_context.keys().size() == 6 and not bridge.input_context.has("world"), "native planner receives limited game context")

	bridge.next_content = output(["ニュースを見る"])
	start_water = float(game.world.s.water_used)
	await game._on_command("水は飲まずに、ニュースだけ見る")
	check(game.last_plan.ok and float(game.world.s.water_used) == start_water, "negative instruction runs only news")
	var old_count := bridge.request_count
	await game._on_command("持ち物")
	check(bridge.request_count == old_count, "known commands retain offline path")

	var raw := "家でいつもの暮らしを７日間続ける"
	var validated := Apple.decode(game, raw, waiting("7日間", true))
	check(validated.ok and int(validated.actions[0].minutes) == 10080, "Godot converts original seven days; ignores invented 480 minutes")
	check(not Apple.decode(game, raw, waiting("480分", true)).ok, "different duration is rejected")
	check(not Apple.decode(game, raw, output(["寝る"])).ok, "missing explicit duration is rejected")
	check(not Apple.decode(game, "0.5日過ごす", waiting("5日", true)).ok, "decimal duration cannot be read as an integer suffix")
	check(not Apple.decode(game, "30日間過ごす", waiting("30日間", true)).ok, "oversized duration is rejected")
	check(not Apple.decode(game, "7日間、水を飲まずに過ごす", waiting("7日間", false)).ok, "managed wait cannot override a stated care restriction")
	check(not Apple.decode(game, "待ちたい", waiting("7日間", true)).ok, "invented duration is rejected")
	check(not Apple.decode(game, "やって", output(["読込"])).ok, "AI cannot trigger save/load")
	check(not Apple.decode(game, "やって", "bad-json").ok, "invalid JSON rejected")

	game._start_new_game(game.world.DEFAULT_PROFILE.duplicate(true))
	game._finish_intro()
	game.world.s.food = 30
	game.world.s.water = 100
	bridge.next_content = waiting("７日間", true)
	await game._on_command(raw)
	check(game.active_wait.get("target") == 10080 and game.world.s.minute == 10080 and game.world.s.health > 99, "AI-managed seven days run for exactly 10080 minutes")
	check(game.active_wait.meals > 0 and game.active_wait.drinks > 0 and game.active_wait.sleep > 0 and float(game.world.s.food) < 30, "seven days consume stock, drink and sleep")

	var frozen: PackedByteArray = var_to_bytes(game.world.s)
	bridge.next_content = waiting("480分", true)
	await game._on_command(raw)
	check(not game.last_plan.ok and var_to_bytes(game.world.s) == frozen, "bad duration changes no game state")
	bridge.delayed = true
	game._on_command("キッチンで喉を潤したい")
	await process_frame
	check(game.advancing and game.send_button.disabled, "send locks while interpreting")
	game._cancel_action()
	await process_frame
	await process_frame
	check(bridge.cancel_count == 1 and not game.advancing and var_to_bytes(game.world.s) == frozen, "cancel stops request and keeps world intact")
	bridge.delayed = false
	bridge.state = "modelNotReady"
	await game._on_command("持ち物")
	check(game.last_plan.ok and var_to_bytes(game.world.s) == frozen, "offline commands still work if model is not ready")
	game.queue_free()
	await process_frame
	Engine.unregister_singleton(Apple.SINGLETON)
	quit(0 if failures == 0 else 1)
