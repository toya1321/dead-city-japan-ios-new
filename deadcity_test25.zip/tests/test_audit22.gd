extends SceneTree
const Main=preload("res://main.tscn")
const World=preload("res://scripts/world.gd")
const E=preload("res://scripts/world_events.gd")
var failures:Array[String]=[]
func check(ok:bool,label:String)->void:
	print(("PASS " if ok else "FAIL ")+label)
	if not ok:failures.append(label)
func _initialize()->void:call_deferred("run")
func touch(id:int,down:bool,pos:Vector2)->void:
	var ev:=InputEventScreenTouch.new();ev.index=id;ev.pressed=down;ev.position=pos;root.push_input(ev,true)
func drag(id:int,pos:Vector2,relative:Vector2)->void:
	var ev:=InputEventScreenDrag.new();ev.index=id;ev.position=pos;ev.relative=relative;root.push_input(ev,true)
func run()->void:
	root.content_scale_size=Vector2i.ZERO
	root.size=Vector2i(1280,720)
	var game=Main.instantiate();root.add_child(game);await process_frame
	game._start_new_game(game.world.DEFAULT_PROFILE.duplicate(true));game._finish_intro();await process_frame;await process_frame
	# Alias commands must obey the same delayed knowledge and state changes.
	E.emit_event(game.world,"audit_future","未報道の遠方の事件",{"test":true},"broadcast",-1,[],true)
	var result:String=game._interpret("ニュースを確認する")
	check(not result.contains("未報道の遠方の事件") and game.known_events.is_empty(),"NEWS-ALIAS unseen report stays hidden")
	game.world.reset();game.known_events.clear()
	game.world.s.inventory.wood=4;game.world.s.inventory.parts=3;game.world.s.inventory.seeds=2;game.world.s.equipment.filter=true
	result=game._interpret("持ち物")
	check(result.contains("木材") and result.contains("部品") and result.contains("種") and result.contains("浄水器"),"INVENTORY purchased materials and equipment visible")
	game.location="屋外";game._sync_player_position();result=game._interpret("テレビを見る")
	check(result.contains("自宅") or result.contains("テレビがない"),"TV-LOCATION no television conjured on street")
	var w=World.new();w.s.player_pos=[0.0,1.6,12.0];w.s.thirst=20;w.s.water=2.0
	var tap:float=w.s.tap_water_used;var water:float=w.s.water
	w.drink()
	check(w.s.water<water and w.s.tap_water_used==tap,"WATER-LOCATION outdoor drinking consumes carried water")
	w=World.new();w.s.hunger=10;w.s.food=0.1
	check(w.can_eat() and w.eat() and is_zero_approx(w.s.food),"FOOD-PARTIAL available small portion can be eaten")
	w=World.new();var warehouse:float=w.s.sim.warehouse.food
	w.place_order("food",2)
	check(w.s.sim.warehouse.food==warehouse-2,"ORDER-STOCK online order reserves finite stock")
	w=World.new();w.s.sim.warehouse.food=0.0
	var cash:int=w.s.cash
	result=w.place_order("food",2)
	check(w.s.longplay.orders.is_empty() and w.s.cash==cash,"ORDER-EMPTY depleted warehouse rejects transaction")
	w=World.new();w.place_order("water",1);w.s.longplay.orders[0].due=60
	for minute in range(55):w.step(false)
	var known_parcel:=false
	for event in E.observe(w,"sight","玄関"):
		if event.kind=="delivery_arrived":known_parcel=true
	check(known_parcel,"ORDER-KNOWLEDGE own parcel has observable delivery event")
	game.world.reset();game.location="玄関";game._sync_player_position();game._interpret("玄関の扉を開ける");game._interpret("居間へ行く")
	check(game.world.s.door_open,"DOOR-CONTINUITY interior walking does not remotely close door")
	w=World.new();w.s.society="disrupted";w.s.weather="cloudy";E.trigger(w,"rain")
	w.s.minute=10000;E._resolve(w)
	var false_weather_end:=false
	for event in w.s.events:
		if event.kind=="rain_resolved" and w.s.weather=="rain":false_weather_end=true
	check(not false_weather_end,"EVENT-RESOLUTION no false rain-ended report while rain persists")
	w=World.new();w.s.minute=180;w.s.sim.curfew_until=1440
	w.s.agents[1].supplies=6.0;w._update_resident_routines()
	check(w.s.agents[1].destination=="home","CURFEW resident routine honors active external restriction")
	w=World.new();w.s.profile.job="会社員";w.s.grid_online=false;w.s.equipment.battery=true;w.s.battery=1000
	var bank:int=w.s.bank;w.work_at_home()
	check(w.s.bank>bank,"BATTERY-WORK stored power supports home work")
	game.world.reset();game.location="寝室";game._sync_player_position();game._refresh()
	root.size=Vector2i(1280,360);await process_frame;await process_frame;await process_frame
	check(game.command_input.get_global_rect().end.y<=360,"KEYBOARD-SPACE input fits reduced landscape height")
	root.size=Vector2i(1280,720);await process_frame;await process_frame
	if game.has_method("_apply_responsive_layout"):
		for keyboard in [320,400,520]:
			game.safe_margin.add_theme_constant_override("margin_bottom",keyboard)
			game._apply_responsive_layout(Vector2(1280,720),keyboard)
			await process_frame;await process_frame;await process_frame
			check(game.command_input.get_global_rect().end.y<=720-keyboard,"KEYBOARD-INSET input above covered area "+str(keyboard))
		game._update_layout();await process_frame;await process_frame
	for i in range(40):game._append("監査用の行動履歴 %d。左右のパネルと独立して、この長い記録を指で上下に読める。"%i)
	await process_frame;await process_frame
	var scroll:Range=game.get("log_scroll").get_v_scroll_bar() if game.get("log_scroll")!=null else game.story.get_v_scroll_bar()
	await process_frame;await process_frame
	check(scroll.value>0 and scroll.value+scroll.page>=scroll.max_value-1,"LOG-FOLLOW new action history is automatically visible")
	scroll.value=scroll.max_value;await process_frame
	var before_scroll:float=scroll.value
	var pos:Vector2=game.story.get_global_rect().get_center()
	if game.get("log_scroll")!=null:pos=game.log_scroll.get_global_rect().get_center()
	var before_minute:int=game.world.s.minute
	touch(8,true,pos);drag(8,pos+Vector2(0,60),Vector2(0,60));touch(8,false,pos+Vector2(0,60));await process_frame
	check(scroll.value<before_scroll and game.world.s.minute==before_minute,"LOG-TOUCH central history responds to touch swipe")
	game._append("長い報道".repeat(700));game._save()
	check(game._load()=="保存データを読み込んだ。","SAVE-LONG-LOG own long narrative save can be loaded")
	game.world.reset();game.location="寝室";game._sync_player_position();game.known_events.clear();game.observed_news="まだ確認していない"
	E.emit_event(game.world,"audit_report","確認済みの報道",{"test":true},"broadcast",-1,[],true);game.world.s.minute=60
	game._interpret("ニュースを見る");game._interpret("ニュースを見る")
	check(game.observed_news.contains("確認済みの報道"),"NEWS-REPEAT retains last known report")
	var corpse=World.new();corpse.s.health=0;corpse.s.player_pos=[20.0,1.6,19.3]
	var frozen:PackedByteArray=var_to_bytes(corpse.s);corpse.buy_quantity("grocer","food",1)
	check(frozen==var_to_bytes(corpse.s),"DEAD-PURCHASE cannot buy after death")
	var interrupted=World.new();interrupted.s.profile.job="会社員";interrupted.s.sim.communications=0.0
	var before_bank:int=interrupted.s.bank;interrupted.work_at_home()
	check(interrupted.s.bank==before_bank and interrupted.s.minute==0,"WORK-NETWORK blocked work does not mint income")
	var malformed:Dictionary=game.world.s.duplicate(true);malformed.sim=null
	check(game.world.migrate_legacy(malformed).is_empty(),"SAVE-MALFORMED nested malformed state rejected without script error")
	game._save()
	var legacy:Dictionary=JSON.parse_string(FileAccess.get_file_as_string(game.SAVE_PATH))
	legacy.log=["旧版の長い報道".repeat(600)]
	var legacy_file:=FileAccess.open(game.SAVE_PATH,FileAccess.WRITE);legacy_file.store_string(JSON.stringify(legacy));legacy_file.close()
	check(game._load()=="保存データを読み込んだ。" and game.log_entries.size()>1,"SAVE-LEGACY-LONG old TEST21 narrative recovered in bounded chunks")
	game.queue_free();await process_frame
	print("AUDIT22: ",failures.size()," failures")
	quit(0 if failures.is_empty() else 1)
