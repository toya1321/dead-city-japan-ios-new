extends SceneTree
const Main=preload("res://tests/gesture_harness.tscn")
var failures:Array[String]=[]
func check(ok:bool,label:String)->void:
	print(("PASS " if ok else "FAIL ")+label)
	if not ok:failures.append(label)
func _initialize()->void:call_deferred("run")
func button_named(n:Node,label:String)->Button:
	for c in n.get_children():
		if c is Button and c.text==label:return c
		var b:=button_named(c,label)
		if b!=null:return b
	return null
func touch(id:int,down:bool,p:Vector2)->void:
	var e:=InputEventScreenTouch.new();e.index=id;e.position=p;e.pressed=down;Input.parse_input_event(e)
func drag(id:int,p:Vector2,delta:Vector2)->void:
	var e:=InputEventScreenDrag.new();e.index=id;e.position=p;e.relative=delta;Input.parse_input_event(e)
func screen_point(control:Control)->Vector2:
	return root.get_screen_transform()*control.get_global_transform_with_canvas()*(control.size*0.5)
func settle()->void:
	Input.flush_buffered_events()
	for i in range(5):await process_frame
func run()->void:
	Input.emulate_mouse_from_touch=true
	root.content_scale_size=Vector2i(1280,720)
	root.content_scale_mode=Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	root.content_scale_aspect=Window.CONTENT_SCALE_ASPECT_EXPAND
	var g=Main.instantiate();root.add_child(g);await process_frame
	g._start_new_game(g.world.DEFAULT_PROFILE.duplicate(true));g._finish_intro();await settle()
	for physical_size in [Vector2i(1280,720),Vector2i(2556,1179),Vector2i(2622,1206),Vector2i(1920,1080)]:
		root.size=physical_size;await settle()
		g.root_scroll.velocity=0;g.root_scroll.scroll_vertical=0;await settle()
		var button:=button_named(g.actions_box,"周囲を見る");var p:=screen_point(button)
		var before:int=g.world.s.minute
		touch(0,true,p);touch(0,false,p);await settle()
		check(g.world.s.minute==before+1,"right action fires exactly once "+str(physical_size))
		check(g.log_entries[-1].contains("寝室") and g.log_scroll.scroll_vertical+g.log_scroll.get_v_scroll_bar().page>=g.log_scroll.get_v_scroll_bar().max_value-1,"action result becomes visible "+str(physical_size))
		g.root_scroll.velocity=0;g.root_scroll.scroll_vertical=0;await settle()
		button=button_named(g.actions_box,"周囲を見る");p=screen_point(button);before=g.world.s.minute
		touch(1,true,p);drag(1,p-Vector2(0,180),Vector2(0,-180));touch(1,false,p-Vector2(0,180));await settle()
		check(g.root_scroll.scroll_vertical>0 and g.world.s.minute==before,"button-started swipe scrolls without action "+str(physical_size))
		g.root_scroll.velocity=0;g.left_scroll.velocity=0;g.left_scroll.scroll_vertical=0;await settle()
		p=screen_point(g.left_scroll);touch(2,true,p);drag(2,p-Vector2(0,160),Vector2(0,-160));touch(2,false,p-Vector2(0,160));await settle()
		check(g.left_scroll.scroll_vertical>0 and g.world.s.minute==before,"left panel independently swipes "+str(physical_size))
		g.left_scroll.velocity=0;g.root_scroll.velocity=0;g.root_scroll.scroll_vertical=0;await settle()
		button=button_named(g.actions_box,"周囲を見る");p=screen_point(button)
		touch(3,true,p);Input.flush_buffered_events();await process_frame
		g.root_scroll.notification(Node.NOTIFICATION_APPLICATION_PAUSED)
		check(g.root_scroll.pointer==-999 and not button.button_pressed,"pause cancels capture "+str(physical_size))
		touch(3,false,p);await settle()
		before=g.world.s.minute;p=screen_point(button_named(g.actions_box,"周囲を見る"))
		touch(4,true,p);touch(4,false,p);await settle()
		check(g.world.s.minute==before+1,"next tap works after canceled touch "+str(physical_size))
		print("PHONE GEOMETRY physical=",physical_size," logical=",g.get_viewport_rect().size," transform=",root.get_screen_transform())
	# Canvas scaling/translation is also different from the control's canvas
	# rectangle. Real viewport input must be converted before hit-testing.
	root.content_scale_size=Vector2i.ZERO;root.size=Vector2i(1600,900);await settle()
	root.canvas_transform=Transform2D(Vector2(1.1,0),Vector2(0,1.1),Vector2(24,18));await settle()
	g.root_scroll.scroll_vertical=0;g.root_scroll.velocity=0;await settle()
	var p:=screen_point(button_named(g.actions_box,"周囲を見る"));var before:int=g.world.s.minute
	touch(5,true,p);touch(5,false,p);await settle()
	check(g.world.s.minute==before+1,"transformed canvas uses correct touch coordinates")
	root.canvas_transform=Transform2D.IDENTITY
	g.queue_free();await process_frame
	print("PHONE INPUT23: ",failures.size()," failures")
	quit(0 if failures.is_empty() else 1)
