extends SceneTree
const Main=preload("res://main.tscn")
const Client=preload("res://tests/ai_loopback.gd")
var failures:Array[String]=[]
func check(ok:bool,label:String)->void:
	print(("PASS " if ok else "FAIL ")+label)
	if not ok:failures.append(label)
func _initialize()->void:call_deferred("run")
func run()->void:
	var g=Main.instantiate();root.add_child(g);await process_frame
	g._start_new_game(g.world.DEFAULT_PROFILE.duplicate(true));g._finish_intro()
	var client=Client.new();root.add_child(client);await process_frame
	client.endpoint="http://127.0.0.1:"+OS.get_cmdline_user_args()[0]+"/v1/chat/completions";client.api_key="local-fixture-key"
	for mode in ["success","unauthorized","malformed","slow"]:
		client.model=mode;client.request_node.timeout=0.08 if mode=="slow" else 2.0
		var exact:PackedByteArray=var_to_bytes(g.world.s)
		var plan:Dictionary=await client.plan(g,"周囲を見る")
		check(var_to_bytes(g.world.s)==exact,"transport never directly mutates world: "+mode)
		if mode=="success":
			check(plan.ok,"HTTP JSON response validated")
			await g._run_plan(plan);check(g.world.s.minute==1,"validated response executes through real engine")
		else:check(not plan.ok,"HTTP error/malformed/timeout refused: "+mode)
	client.request_node.timeout=3;client.model="cancel"
	var state:PackedByteArray=var_to_bytes(g.world.s)
	var abort:=func():client.cancel()
	create_timer(0.1).timeout.connect(abort)
	var canceled:Dictionary=await client.plan(g,"周囲を見る")
	check(not canceled.ok and state==var_to_bytes(g.world.s),"cancel pending HTTP without state changes")
	client.queue_free();g.queue_free();await process_frame
	quit(0 if failures.is_empty() else 1)
