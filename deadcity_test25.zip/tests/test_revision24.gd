extends SceneTree
const Main=preload("res://main.tscn")
const Plan=preload("res://scripts/action_plan.gd")
const Care=preload("res://scripts/care_wait.gd")
var failures:Array[String]=[]
func check(ok:bool,label:String)->void:
	print(("PASS " if ok else "FAIL ")+label)
	if not ok:failures.append(label)
func _initialize()->void:call_deferred("run")
func reset_game(g)->void:
	g._start_new_game(g.world.DEFAULT_PROFILE.duplicate(true));g._finish_intro()
func run()->void:
	root.size=Vector2i(1280,720)
	var g=Main.instantiate();root.add_child(g);await process_frame;reset_game(g)
	var p:Dictionary=Plan.local(g,"台所へ行って食事し、水を飲んでからニュースを見る")
	check(p.ok and p.actions.size()==4,"compound intention parses all four actions")
	await g._on_command("台所へ行って食事し、水を飲んでからニュースを見る")
	check(g.location=="台所" and g.world.s.minute>=20 and g.log_entries[-1].contains("情報源"),"compound executes movement meal water and news in order")
	var exact:PackedByteArray=var_to_bytes(g.world.s)
	for bad in ["水を飲んで空を飛ぶ","台所へ行って二人分のカレーを作る","水を飲まないで待つ","ニュースを見られる？","30日待つ","999999日待つ","1日待つ、7日待つ"]:
		await g._on_command(bad)
		check(exact==var_to_bytes(g.world.s),"unsupported entire intention does not mutate: "+bad)
	reset_game(g)
	await g._on_command("外に出てニュースを見る")
	check(g.world.s.minute==0 and g.location=="寝室","locked exit stops natural conjugation without partial news")
	await g._on_command("玄関へ行く、外に出る、ニュースを見る")
	check(g.location=="玄関" and g.world.s.minute==2 and not g.log_entries[-1].contains("情報源"),"blocked door stops subsequent plan actions")
	reset_game(g)
	var before:Dictionary=g.world.s.duplicate(true)
	await g._on_command("7日待つ")
	check(g.world.s.health>99 and g.active_wait.elapsed<10080 and g.active_wait.reason.contains("食料"),"initial five-day food stock interrupts seven-day wait alive")
	check(g.active_wait.meals>0 and g.active_wait.drinks>0 and g.active_wait.sleep>0,"long wait actually eats drinks and sleeps")
	check(is_equal_approx(float(before.food)-float(g.world.s.food),float(g.active_wait.food)),"reported player food equals actual deduction")
	check(g.world.validate_state(g.world.s),"interrupted wait leaves valid save state")
	check(not g.advancing and g.command_input.editable and not g.send_button.disabled,"wait completion always restores controls")
	reset_game(g);g.world.s.food=30;g.world.s.water=100
	await g._on_command("自宅で食事と水分を取りながら7日間過ごす。異変があれば中断する")
	check(g.world.s.minute==10080 and g.world.s.health>99 and g.active_wait.reason.is_empty(),"stocked seven-day ordinary life completes without forced disaster")
	check(g.world.s.sim.next_event_id>0 and g.world.s.agents!=before.agents,"world and autonomous NPCs progress during routine")
	var saved:PackedByteArray=var_to_bytes(g.world.s)
	check(g._save()=="保存した。","save after managed wait")
	g.world.advance_safe(10);check(g._load()=="保存データを読み込んだ。" and var_to_bytes(g.world.s)==saved,"exact save load after seven days")
	reset_game(g);g.world.s.water_online=false;g.world.s.water=0;g.world.s.thirst=30
	await g._on_command("1日待つ")
	check(g.active_wait.elapsed==0 and g.world.s.health==100 and g.active_wait.reason.contains("水"),"unavailable drink interrupts before time and damage")
	reset_game(g);g.location="屋外";g._sync_player_position()
	await g._on_command("7日待つ")
	check(g.world.s.minute==0 and g.log_entries[-1].contains("自宅"),"outdoor long wait cannot use home stock")
	reset_game(g);g.world.s.health=80;g.world.s.injuries=2
	await g._on_command("1日待つ")
	check(g.world.s.minute<30 and g.world.s.health>79 and g.active_wait.reason.contains("体調"),"felt health deterioration interrupts early")
	# Same world evolution regardless of frame chunk size.
	reset_game(g);g.world.s.food=30;var h=Main.instantiate();root.add_child(h);await process_frame;reset_game(h);h.world.s.food=30
	var r1:Dictionary=Care.begin(g,1440);var r2:Dictionary=Care.begin(h,1440)
	while not r1.stopped:Care.tick(g,r1,1)
	while not r2.stopped:Care.tick(h,r2,47)
	check(var_to_bytes(g.world.s)==var_to_bytes(h.world.s),"routine frame chunk size cannot alter world state")
	# Remote AI has no direct state writes and cannot introduce new action types.
	for invalid in [{"actions":[{"kind":"set_state","health":100}]},{"actions":[{"kind":"command","command":"現金を増やす"}]},{"actions":[{"kind":"command","command":"読込"}]},{"actions":[{"kind":"wait","minutes":1.5,"care":true}]}]:
		check(not Plan.validate(g,invalid,true).ok,"reject malformed or unauthorized AI plan "+str(invalid))
	var parsed:Dictionary=g.ai_planner.parse_response(JSON.stringify({"choices":[{"message":{"content":JSON.stringify({"actions":[{"kind":"command","command":"周囲を見る"}]})}}]}).to_utf8_buffer(),g)
	check(parsed.ok,"AI response JSON passes same allowlist validator")
	var public:Dictionary=g.ai_planner.public_context(g)
	check(not str(public).contains("symptoms_due") and not public.has("seed") and not public.has("agents"),"AI receives player-known context without hidden infection rules")
	g._open_tool("settings");check(g.drawer.visible and g.settings_box.visible,"AI connection settings open")
	g.ai_fields.key.text="not-a-real-secret";g.ai_fields.model.text="test-model";g.ai_enabled.button_pressed=true;g._apply_ai_settings()
	check(g.ai_planner.configured(),"AI opt-in settings applied")
	g._close_drawer();g._save()
	check(not FileAccess.get_file_as_string(g.SAVE_PATH).contains("not-a-real-secret"),"API credential excluded from saves")
	check(g.command_input is TextEdit and g.command_input.wrap_mode==TextEdit.LINE_WRAPPING_BOUNDARY,"multiline wrapped text is the main control")
	check(g.main_layout.get_child_count()==2,"two-column scene and chronicle layout without action menu")
	g.ai_planner.enabled=false
	g.queue_free();h.queue_free();await process_frame
	print("REVISION24: ",failures.size()," failures")
	quit(0 if failures.is_empty() else 1)
