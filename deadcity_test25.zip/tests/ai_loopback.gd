extends "res://scripts/ai_planner.gd"
# Only test harness permits HTTP loopback. Never exported with the app.
func configured()->bool:return endpoint.begins_with("http://127.0.0.1:")
