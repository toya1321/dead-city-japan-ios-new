#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
GODOT="${GODOT:-godot}"
"$GODOT" --headless --path . --editor --import --quit
"$GODOT" --headless --path . --script res://tests/test_runtime.gd
"$GODOT" --headless --path . --script res://tests/test_main_runtime.gd
