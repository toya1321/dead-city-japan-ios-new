extends SceneTree
const World = preload("res://scripts/world.gd")
var failed: Array[String] = []
func check(ok: bool, label: String) -> void:
    if not ok:
        failed.append(label)
        push_error(label)
func _initialize() -> void:
    var a = World.new()
    var b = World.new()
    check(a.s.agents.size() == 48, "48 residents")
    check(a.validate_state(a.s), "initial save valid")
    check(a.s.agents[0].relations.size() == 2, "household ties")
    check(a.resident_profile(0).history.is_empty(), "no fabricated history")
    a.advance(31*1440)
    b.advance(31*1440)
    check(JSON.stringify(a.s.agents) == JSON.stringify(b.s.agents), "deterministic resident state")
    check(JSON.stringify(a.s.longplay.resident_history) == JSON.stringify(b.s.longplay.resident_history), "deterministic history")
    check(a.s.longplay.resident_history.size() > 0, "personal histories accumulate")
    check(a.s.longplay.resident_history.size() <= 1600, "history bounded")
    check(a.resident_profile(-1).is_empty(), "invalid profile rejected")
    var before: String = JSON.stringify(a.s)
    a.visible_residents()
    a.resident_profile(0)
    check(JSON.stringify(a.s) == before, "observation never changes world")
    check(a.validate_state(a.s), "later save valid")
    print("v11 resident tests: ", "PASS" if failed.is_empty() else "FAIL")
    quit(0 if failed.is_empty() else 1)
