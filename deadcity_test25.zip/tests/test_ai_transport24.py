"""Exercise real Godot HTTPRequest with a local fixture, not a live LLM."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json, os, subprocess, threading, time
root=Path(__file__).resolve().parents[1]
received=[]
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def do_POST(self):
        data=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        received.append(data)
        assert self.path=='/v1/chat/completions'
        assert self.headers['Authorization']=='Bearer local-fixture-key'
        assert data['response_format']=={'type':'json_object'}
        mode=data['model']
        if mode in ('slow','cancel'): time.sleep(0.5)
        body={'choices':[{'message':{'content':json.dumps({'actions':[{'kind':'command','command':'周囲を見る'}]})}}]}
        if mode=='malformed': body={'choices':[{'message':{'content':'{"actions":[{"kind":"set_state"}]}'}}]}
        encoded=json.dumps(body).encode()
        self.send_response(401 if mode=='unauthorized' else 200)
        self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(encoded)));self.end_headers()
        try:self.wfile.write(encoded)
        except (BrokenPipeError,ConnectionResetError):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
try:
    p=subprocess.run([os.environ.get('GODOT','godot'),'--headless','--path',str(root),'--script','res://tests/ai_transport_client.gd','--',str(server.server_port)],capture_output=True,text=True,timeout=25)
    print(p.stdout,p.stderr)
    assert p.returncode==0 and 'FAIL ' not in p.stdout and 'SCRIPT ERROR' not in p.stdout
    assert len(received)==5
    for data in received:
        context=json.loads(data['messages'][1]['content'])['context']
        assert 'seed' not in context and 'agents' not in context and 'private_rules' not in context
    print('PASS real HTTP request, validation, error, timeout and cancellation fixture')
finally:server.shutdown();server.server_close()
