extends SceneTree
const Main=preload("res://main.tscn")
var failures:Array[String]=[]
func check(ok:bool,label:String)->void:
	print(("PASS " if ok else "FAIL ")+label)
	if not ok:failures.append(label)
func _initialize()->void:call_deferred("run")
func point(c:Control)->Vector2:return root.get_screen_transform()*c.get_global_transform_with_canvas()*(c.size*0.5)
func touch(down:bool,p:Vector2)->void:
	var e:=InputEventScreenTouch.new();e.index=0;e.position=p;e.pressed=down;Input.parse_input_event(e)
func drag(p:Vector2,d:Vector2)->void:
	var e:=InputEventScreenDrag.new();e.index=0;e.position=p;e.relative=d;Input.parse_input_event(e)
func settle()->void:
	Input.flush_buffered_events()
	for i in range(5):await process_frame
func run()->void:
	Input.emulate_mouse_from_touch=true
	root.content_scale_size=Vector2i(1280,720);root.content_scale_mode=Window.CONTENT_SCALE_MODE_CANVAS_ITEMS;root.content_scale_aspect=Window.CONTENT_SCALE_ASPECT_EXPAND
	var g=Main.instantiate();root.add_child(g);await process_frame
	g._start_new_game(g.world.DEFAULT_PROFILE.duplicate(true));g._finish_intro();await settle()
	for geometry in [Vector2i(1280,720),Vector2i(2556,1179),Vector2i(2622,1206),Vector2i(1920,1080)]:
		root.size=geometry;await settle()
		g.command_input.text="周囲を見る"
		var p:=point(g.send_button);var before:int=g.world.s.minute
		touch(true,p);touch(false,p);await settle()
		check(g.world.s.minute==before+1 and g.command_input.text.is_empty(),"send tap executes typed action once "+str(geometry))
		check(g.log_scroll.scroll_vertical+g.log_scroll.get_v_scroll_bar().page>=g.log_scroll.get_v_scroll_bar().max_value-1,"latest result visible "+str(geometry))
		var top_before:int=g.log_scroll.scroll_vertical
		p=point(g.log_scroll);touch(true,p);drag(p+Vector2(0,100),Vector2(0,100));touch(false,p+Vector2(0,100));await settle()
		check(g.log_scroll.scroll_vertical<top_before and g.world.s.minute==before+1,"history swipe does not act "+str(geometry))
		g.log_scroll.velocity=0
		g._open_tool("inventory");await settle()
		g.left_scroll.scroll_vertical=0;p=point(g.left_scroll);touch(true,p);drag(p-Vector2(0,100),Vector2(0,-100));touch(false,p-Vector2(0,100));await settle()
		check(g.left_scroll.scroll_vertical>0,"on-demand inventory swipes "+str(geometry))
		g.left_scroll.notification(Node.NOTIFICATION_APPLICATION_PAUSED);check(g.left_scroll.pointer==-999,"pause resets drawer capture "+str(geometry));g._close_drawer();await settle()
		check(g.command_input.get_global_rect().end.y<=g.get_viewport_rect().size.y and g.picture.size.y>100,"text and picture fit landscape "+str(geometry))
	# Editable fields are not swallowed by the scroll handler.
	g._open_tool("settings");await settle()
	var p:=point(g.ai_fields.model);touch(true,p);touch(false,p);await settle()
	check(g.ai_fields.model.has_focus(),"settings text field receives touch keyboard focus")
	p=point(g.ai_enabled);touch(true,p);touch(false,p);await settle()
	check(g.ai_enabled.button_pressed,"AI opt-in toggle responds to native touch")
	g._close_drawer();await settle()
	root.content_scale_size=Vector2i.ZERO;root.size=Vector2i(1280,720);await settle()
	for keyboard in [320,400,520]:
		g.safe_margin.add_theme_constant_override("margin_bottom",keyboard);g._apply_responsive_layout(Vector2(1280,720),keyboard);await settle()
		check(g.command_input.get_global_rect().end.y<=720-keyboard and g.log_scroll.is_visible_in_tree(),"keyboard keeps typed text and result visible "+str(keyboard))
	g._update_layout();await settle()
	g.world.reset();g.location="寝室";g.world.s.food=30
	g._on_command("7日待つ")
	await process_frame
	var progressed:int=g.world.s.minute
	g._cancel_action()
	await settle()
	check(g.world.s.minute==progressed and not g.advancing and not g.send_button.disabled,"cancel long wait stops before next batch and restores entry")
	g._on_command("周囲を見る");await settle()
	check(g.world.s.minute==progressed+1,"text works after cancel")
	g._on_command("7日待つ");await process_frame;progressed=g.world.s.minute
	g.notification(Node.NOTIFICATION_APPLICATION_PAUSED);await settle()
	check(g.world.s.minute==progressed and not g.advancing,"application pause interrupts waiting without extra time")
	g.queue_free();await process_frame
	print("PHONE24: ",failures.size()," failures")
	quit(0 if failures.is_empty() else 1)
