extends SceneTree
const World = preload("res://scripts/world.gd")
func _initialize() -> void:
    var world = World.new()
    assert(world.validate_state(world.s))
    var first: Dictionary = world.s.agents[0]
    assert(first.has("home_x") and first.has("work_x"))
    var old_minute: int = world.s.minute
    world.advance(60)
    assert(world.s.minute == old_minute + 60)
    assert(world.s.agents[0].has("destination"))
    var saved: Dictionary = world.s.duplicate(true)
    world.visible_residents()
    assert(world.s == saved)
    print("v14 runtime PASS")
    quit(0)
