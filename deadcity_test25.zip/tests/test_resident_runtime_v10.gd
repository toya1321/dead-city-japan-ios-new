extends SceneTree
const World = preload("res://scripts/world.gd")
var failed: Array[String] = []
func check(value: bool, name: String) -> void:
    if not value:
        failed.append(name)
        push_error(name)
func _initialize() -> void:
    var a = World.new()
    var b = World.new()
    check(a.validate_state(a.s), "fresh v10 state valid")
    check(a.s.agents.size() == 48, "resident population")
    check(a.s.agents[0].has("household"), "household persistent")
    a.advance(1440)
    b.advance(1440)
    check(JSON.stringify(a.s.agents) == JSON.stringify(b.s.agents), "deterministic residents")
    check(a.s.longplay.population_snapshots.size() == 1, "daily snapshot")
    var before: String = JSON.stringify(a.s)
    a.visible_residents()
    check(JSON.stringify(a.s) == before, "observation does not mutate simulation")
    check(a.validate_state(a.s), "day one state valid")
    print("v10 residents: ", "PASS" if failed.is_empty() else "FAIL")
    quit(0 if failed.is_empty() else 1)
