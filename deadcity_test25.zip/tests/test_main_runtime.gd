extends SceneTree
const MainScene = preload("res://main.tscn")
var failures: Array[String] = []

func check(value: bool, message: String) -> void:
    if not value:
        failures.append(message)
        push_error(message)
    else:
        print("PASS: " + message)

func _initialize() -> void:
    call_deferred("run_tests")

func run_tests() -> void:
    var game = MainScene.instantiate()
    root.add_child(game)
    await process_frame
    check(game.location == "寝室", "initial room")
    check(game.story != null and game.command_input != null, "UI constructed")
    var before: int = int(game.world.s.minute)
    game._interpret("未知の行動xyz")
    check(int(game.world.s.minute) == before, "unsupported command does not advance time")
    check(game._interpret("台所へ移動").contains("移動した") and game.location=="台所", "indirect room movement uses route")
    game._interpret("寝室へ移動")
    check(game._interpret("居間へ移動").contains("移動した"), "adjacent room allowed")
    check(game._interpret("玄関へ移動").contains("移動した"), "move to entrance")
    check(game._interpret("外に出る").contains("鍵"), "locked door blocks exit")
    game._interpret("鍵を開ける")
    game._interpret("外に出る")
    check(game.location == "屋外", "unlocked door allows exit")
    game._interpret("家に戻る")
    check(game.location == "玄関", "can reenter home")
    check(not bool(game.world.s.door_open), "door closes on reentry")
    var original_minute: int = int(game.world.s.minute)
    check(game._save().contains("保存した"), "save succeeded")
    game._interpret("10分進める")
    check(int(game.world.s.minute) == original_minute + 10, "time advanced")
    check(game._load().contains("読み込んだ"), "load succeeded")
    check(int(game.world.s.minute) == original_minute, "load restored time")
    game.queue_free()
    if failures.is_empty():
        print("ALL MAIN TESTS PASSED")
        quit(0)
    else:
        print("FAILED: ", failures)
        quit(1)
