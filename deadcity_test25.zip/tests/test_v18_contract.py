from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]
m=(r/'scripts/main.gd').read_text()
w=(r/'scripts/world.gd').read_text()+'\n'+(r/'scripts/world_legacy.gd').read_text()
a=json.loads((r/'ILLUSTRATION_AUDIT_V18.json').read_text())
assert 'func _parse_wait_minutes' in m
assert 'var wait_minutes: int = _parse_wait_minutes(normalized)' in m
assert 'if wait_minutes > 0:' in m
assert 'func advance_days_bounded' in w
assert 'days > 7' in w
assert a['event_specific_artwork_complete'] is False
assert len(a['images']) == 28
assert all(not x['event_specific'] for x in a['images'])
assert 'window' in m
print('v18 contract: PASS')
