extends SceneTree
const World = preload("res://scripts/world.gd")
var failures: Array[String] = []
func check(ok: bool, label: String) -> void:
	if not ok:
		failures.append(label)
		push_error(label)
func _initialize() -> void:
	var a = World.new()
	var b = World.new()
	check(a.s.society == "normal", "normal start")
	check(a.s.events.is_empty(), "no pre-seeded events")
	var cash_before: int = int(a.s.cash) + int(a.s.bank)
	var response: String = a.place_order("water", 3)
	check(response.contains("注文した"), "order accepted")
	check(a.s.longplay.orders.size() == 1, "order queued")
	check(int(a.s.cash) + int(a.s.bank) == cash_before-540, "charged once")
	check(a.s.longplay.orders[0].status == "pending", "not instantly delivered")
	check(a.place_order("water", 99).contains("1～12"), "invalid order rejected")
	var due: int = int(a.s.longplay.orders[0].due)
	while int(a.s.minute) < due + 60 and float(a.s.health) > 0:
		a.advance_safe(mini(1440, due + 60 - int(a.s.minute)))
	check(a.s.longplay.orders[0].status != "pending", "delivery resolved after due")
	check(a.s.events.size() <= 240, "bounded event log")
	check(a.validate_state(a.s), "valid current save")
	b.advance_days_bounded(3)
	var c = World.new()
	c.advance_days_bounded(3)
	check(JSON.stringify(b.s.events) == JSON.stringify(c.s.events), "deterministic world events")
	check(b.s.regional_cases == c.s.regional_cases, "deterministic outbreak")
	print("v9 runtime checks: ", "PASS" if failures.is_empty() else "FAIL", " (",failures.size()," failures)")
	quit(0 if failures.is_empty() else 1)
