from pathlib import Path
root=Path(__file__).resolve().parents[1]
w=(root/'scripts/world.gd').read_text()+'\n'+(root/'scripts/world_legacy.gd').read_text()
m=(root/'scripts/main.gd').read_text()
assert int(__import__('re').search(r'const VERSION = ([0-9]+)', w)[1]) >= 22
assert 'if not migrated.longplay.has("household_snapshots")' in w
assert 'if not a.has("unfed_days")' in w
assert 'if not a.has("destination")' in w
assert 'world.migrate_legacy(data["world"])' in m
assert 'return "否定の指示を確認した。行動も時間経過も実行していない。"' in m
print('v16 static contract PASS')
