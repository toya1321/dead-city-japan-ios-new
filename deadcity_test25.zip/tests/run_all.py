from pathlib import Path
import subprocess, time, json, os, sys
root = Path(__file__).resolve().parents[1]
logs = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/'test-results'
logs.mkdir(parents=True,exist_ok=True)
results=[]
tests=sorted(p for p in (root/'tests').glob('test*') if p.suffix in ('.gd','.py'))
for p in tests:
    cmd=[os.environ.get('GODOT','godot'),'--headless','--path',str(root),'--script','res://tests/'+p.name] if p.suffix=='.gd' else [sys.executable,str(p)]
    t=time.monotonic()
    try:
        r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
        output=r.stdout; code=r.returncode
    except subprocess.TimeoutExpired as e:
        output=(e.stdout or b'').decode(errors='replace') if isinstance(e.stdout,bytes) else (e.stdout or '')
        code=124
    (logs/(p.stem+'.log')).write_text(output)
    # Godot can return 0 when a script fails during _initialize. Audit output too.
    ok=code==0 and not any(x in output for x in ['SCRIPT ERROR:', 'ERROR:', 'FAIL ', 'FAIL:'])
    result={'test':p.name,'ok':ok,'exit':code,'seconds':round(time.monotonic()-t,3)}
    results.append(result)
    print(json.dumps(result),flush=True)
(logs/'results.json').write_text(json.dumps(results,indent=2))
sys.exit(0 if all(r['ok'] for r in results) else 1)
