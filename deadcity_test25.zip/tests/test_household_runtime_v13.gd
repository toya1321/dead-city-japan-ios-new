extends SceneTree
const World = preload("res://scripts/world.gd")
var errors: Array[String] = []
func check(condition: bool, label: String) -> void:
	if not condition:
		errors.append(label)
		push_error(label)
func _initialize() -> void:
	var world = World.new()
	check(world.validate_state(world.s), "initial state validates")
	# Isolate one household and confirm food conservation and mutual aid.
	for a in world.s.agents:
		a.supplies = 0.0
		a.x = a.home_x
		a.z = a.home_z
	world.s.agents[0].supplies = 0.0
	world.s.agents[1].supplies = 3.0
	world.s.agents[2].supplies = 0.0
	world.s.minute = 1440
	world._allocate_household_meals()
	var total: float = 0.0
	for i in range(3):
		total += float(world.s.agents[i].supplies)
		check(int(world.s.agents[i].unfed_days) == 0, "household member fed %d" % i)
	check(is_equal_approx(total, 0.0), "food conserved")
	check(world.validate_state(world.s), "state validates after allocation")
	var old: Dictionary = world.s.duplicate(true)
	old.version = 17
	old.longplay.erase("household_snapshots")
	var migrated: Dictionary = world.migrate_legacy(old)
	check(not migrated.is_empty() and world.validate_state(migrated), "v12 migration")
	var before: String = JSON.stringify(world.s)
	world.household_status(0)
	check(JSON.stringify(world.s) == before, "inspection is read-only")
	print("v13 household tests: ", "PASS" if errors.is_empty() else "FAIL")
	quit(0 if errors.is_empty() else 1)
