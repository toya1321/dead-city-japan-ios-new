extends SceneTree
const World = preload("res://scripts/world.gd")
var failures: Array[String] = []
func check(ok: bool, label: String) -> void:
	print(("PASS " if ok else "FAIL ") + label)
	if not ok: failures.append(label)
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	# Benchmark world evolution independently of player survival: directly step
	# after death. No vitality resets, no implicit supplies or invulnerability.
	# This is NOT evidence that a player can survive unattended for a year.
	var world = World.new()
	var resumed = World.new()
	var start := Time.get_ticks_msec()
	var last := start
	for day in range(1,366):
		for m in range(1440): world.step(false)
		if day in [7,30,365]:
			check(world.validate_state(world.s), "valid state at day %d" % day)
			var json: String = JSON.stringify(world.s, "", true, true)
			print("BENCHMARK day=%d total_ms=%d interval_ms=%d save_bytes=%d events=%d residents=%d history=%d journal=%d health=%.1f" % [day,Time.get_ticks_msec()-start,Time.get_ticks_msec()-last,json.to_utf8_buffer().size(),world.s.events.size(),world.s.agents.size(),world.s.longplay.resident_history.size(),world.s.longplay.journal.size(),world.s.health])
			last = Time.get_ticks_msec()
			check(world.save_file("user://benchmark_work.save") == OK, "binary world save day %d" % day)
			check(resumed.load_file("user://benchmark_work.save") == OK, "binary world load day %d" % day)
			for m in range(60):
				world.step(false)
				resumed.step(false)
			check(var_to_bytes(world.s) == var_to_bytes(resumed.s), "exact save reload continuation day %d" % day)
			# Do not add an hour to requested benchmark span.
			check(world.load_file("user://benchmark_work.save") == OK, "restore checkpoint day %d" % day)
		if day % 7 == 0: await process_frame
	var normal = World.new()
	var stopped: Dictionary = normal.advance_days_bounded(7)
	check(stopped.stopped and normal.s.health <= 0 and stopped.elapsed < 10080, "unattended wait stops on actual death")
	check(normal.advance_safe(60) == 0, "dead player cannot advance via command")
	check(world.s.events.size() <= 240 and world.s.longplay.resident_history.size() <= 1600 and world.s.longplay.journal.size() <= 600, "bounded histories")
	print("LONGPLAY WORK: ", failures.size(), " failures")
	quit(0 if failures.is_empty() else 1)
