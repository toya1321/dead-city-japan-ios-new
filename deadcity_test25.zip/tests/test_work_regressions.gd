extends SceneTree
const Main = preload("res://main.tscn")
const World = preload("res://scripts/world.gd")
var failures: Array[String] = []
func check(ok: bool, label: String) -> void:
	print(("PASS " if ok else "FAIL ") + label)
	if not ok: failures.append(label)
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	var game = Main.instantiate()
	root.add_child(game)
	await process_frame
	game._start_new_game(game.world.DEFAULT_PROFILE.duplicate(true))
	game._finish_intro()
	game.location = "台所"
	game.world.advance_safe(60)
	for cmd in ["水を飲んで30日待つ", "水を飲む？", "食事をしなくていい", "窓を壊す", "寝るか迷う", "通販で水を100個注文", "通販で水と食料を注文", "水を飲まずに食事する", "ニュースを見ずに寝る", "台所を見てから水を飲む"]:
		var before: String = JSON.stringify(game.world.s)
		game._on_command(cmd)
		check(JSON.stringify(game.world.s) == before, "rejected unchanged: " + cmd)
	game.world.s.regional_cases = 99999999
	game.world.s.minute = 365 * 1440
	game.world.step(false)
	game.world.s.minute = 365 * 1440 + 59
	game.world.step(false)
	check(game.world.validate_state(game.world.s) and int(game.world.s.regional_cases) <= 100000000, "late epidemic remains bounded and saveable")
	var w = World.new()
	w.s.minute = 599 # 17:59
	var stock: float = float(w.s.shops.grocer.stock.food)
	var supplies: float = float(w.s.agents[0].supplies)
	w.s.agents[0].x = -48.0
	w.s.agents[0].z = 38.0
	w.step(false)
	check(float(w.s.agents[0].supplies) == supplies, "no remote shopping")
	check(float(w.s.shops.grocer.stock.food) == stock, "remote shop stock unchanged")
	var orders = World.new()
	for i in range(256): orders.s.longplay.orders.append({"id":i,"item":"food","quantity":1,"price":850,"due":0,"status":"delivered"})
	orders.s.cash = 0
	orders.s.bank = 0
	var order_before: String = JSON.stringify(orders.s)
	orders.place_order("water", 1)
	check(order_before == JSON.stringify(orders.s), "failed order preserves full order history")
	game.queue_free()
	await process_frame
	print("WORK REGRESSIONS: ", failures.size(), " failures")
	quit(0 if failures.is_empty() else 1)
