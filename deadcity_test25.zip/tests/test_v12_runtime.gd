extends SceneTree
const World = preload("res://scripts/world.gd")
var failures: Array[String] = []
func check(ok: bool, label: String) -> void:
    if not ok:
        failures.append(label)
        push_error(label)
func _initialize() -> void:
    var w = World.new()
    check(w.validate_state(w.s), "fresh world valid")
    check(w.s.agents[0].has("unfed_days"), "resident hunger field")
    var previous: float = float(w.s.shops.grocer.stock.food)
    for actor in w.s.agents: previous += float(actor.supplies)
    w.advance(1440)
    var after: float = float(w.s.shops.grocer.stock.food)
    for actor in w.s.agents: after += float(actor.supplies)
    check(after <= previous, "total shop + resident food conserved")
    check(w.validate_state(w.s), "day one valid")
    var old = w.s.duplicate(true)
    old.version = 16
    for a in old.agents:
        a.erase("unfed_days")
        a.erase("last_meal_minute")
    var migrated = w.migrate_legacy(old)
    check(not migrated.is_empty() and w.validate_state(migrated), "v11 migration")
    print("v12 checks: ", "PASS" if failures.is_empty() else "FAIL")
    quit(0 if failures.is_empty() else 1)
