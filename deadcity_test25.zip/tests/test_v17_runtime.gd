extends SceneTree
const World = preload("res://scripts/world.gd")
var errors: Array[String] = []
func check(ok: bool, description: String) -> void:
    if not ok:
        errors.append(description)
        push_error(description)
func _initialize() -> void:
    var a = World.new()
    var b = World.new()
    check(a.validate_state(a.s), "initial state valid")
    check(a.s.agents.size() == 48, "resident count")
    var before = JSON.stringify(a.s)
    a.visible_residents()
    check(JSON.stringify(a.s) == before, "observation has no side effects")
    check(a.advance_safe(1441) == 0, "reject unsafe long advance")
    check(a.s.minute == 0, "invalid duration does not change world")
    check(a.advance_safe(120) == 120, "valid duration advances")
    b.advance_safe(120)
    check(JSON.stringify(a.s) == JSON.stringify(b.s), "deterministic replay")
    check(a.validate_state(a.s), "post-advance state valid")
    var old = a.s.duplicate(true)
    old.version = 21
    var migrated = a.migrate_legacy(old)
    check(not migrated.is_empty(), "v16 world migration")
    check(a.validate_state(migrated), "migrated state valid")
    print("v17 runtime: PASS" if errors.is_empty() else "v17 runtime: FAIL " + str(errors))
    quit(0 if errors.is_empty() else 1)
