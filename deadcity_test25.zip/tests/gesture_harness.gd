extends Control
# Isolated regression fixture for reusable GestureScroll; production has no
# action menu. This preserves the TEST23 event-order regression independently.
const G=preload("res://scripts/gesture_scroll.gd")
const W=preload("res://scripts/world.gd")
var world=W.new()
var actions_box:VBoxContainer
var root_scroll:ScrollContainer
var left_scroll:ScrollContainer
var log_scroll:ScrollContainer
var log_entries:Array[String]=[]
func _ready()->void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var row:=HBoxContainer.new();row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);add_child(row)
	for i in range(3):
		var scroll=G.new();scroll.size_flags_horizontal=Control.SIZE_EXPAND_FILL;scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;row.add_child(scroll)
		var col:=VBoxContainer.new();col.size_flags_horizontal=Control.SIZE_EXPAND_FILL;scroll.add_child(col)
		if i==0:left_scroll=scroll
		elif i==1:log_scroll=scroll
		else:root_scroll=scroll;actions_box=col
		for j in range(25):
			var b:=Button.new();b.custom_minimum_size.y=80;b.text="周囲を見る" if j==0 else "gesture fixture %d"%j;col.add_child(b)
			b.pressed.connect(func():world.advance_safe(1);log_entries.append("寝室");log_scroll.scroll_vertical=100000)
func _start_new_game(_p:Dictionary)->void:pass
func _finish_intro()->void:pass
