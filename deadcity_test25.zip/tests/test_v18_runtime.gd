extends SceneTree
const World = preload("res://scripts/world.gd")
const Main = preload("res://scripts/main.gd")
var failures: Array[String] = []
func check(ok: bool, label: String) -> void:
    if not ok:
        failures.append(label)
        push_error(label)
func _initialize() -> void:
    var world = World.new()
    check(world.validate_state(world.s), "initial world validates")
    var before: String = JSON.stringify(world.s)
    world.visible_residents()
    check(JSON.stringify(world.s) == before, "observation is pure")
    check(world.advance_days_bounded(8).ok == false, "long advance rejected")
    check(int(world.s.minute) == 0, "rejected advance changes nothing")
    check(world.advance_safe(60) == 60, "one-hour advance")
    check(world.validate_state(world.s), "advanced world validates")
    var ui = Main.new()
    check(ui._parse_wait_minutes("30分待つ") == 30, "simple wait")
    check(ui._parse_wait_minutes("2時間待つ") == 120, "hour wait")
    check(ui._parse_wait_minutes("2日待つ") == -2, "oversized wait")
    check(ui._parse_wait_minutes("水を飲んで30分待つ") == -1, "compound not partially executed")
    check(ui._parse_wait_minutes("30分待たない") == -1, "negated wait not executed")
    ui.free()
    print("v18 runtime: PASS" if failures.is_empty() else "v18 runtime: FAIL " + str(failures))
    quit(0 if failures.is_empty() else 1)
