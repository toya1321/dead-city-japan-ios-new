from pathlib import Path
root=Path(__file__).resolve().parents[1]
w=(root/'scripts/world.gd').read_text()+'\n'+(root/'scripts/world_legacy.gd').read_text()
m=(root/'scripts/main.gd').read_text()
assert int(__import__('re').search(r'const VERSION = ([0-9]+)', w)[1]) >= 22
assert 'eater_at_home and donor_at_home' in w
assert '0.0 if at_destination else 0.65' in w
assert 'Route by road corridors' in w
assert '経過させない' in m
assert 'if cmd.contains("10分"):' not in m
assert '生成した実写風の場所イメージ' in m and '人物・在庫・出来事は記録を参照' in m
print('v15 static checks PASS')
