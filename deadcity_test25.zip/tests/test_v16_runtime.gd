extends SceneTree
const World = preload("res://scripts/world.gd")
func _initialize() -> void:
    var w = World.new()
    assert(w.validate_state(w.s), "new game valid")
    w.advance(1440)
    assert(w.validate_state(w.s), "after one day valid")
    var saved = w.s.duplicate(true)
    saved.version = 20
    var first = saved.agents[0]
    first.supplies = 12.0
    first.unfed_days = 4
    first.destination = "work"
    saved.longplay.household_snapshots.append({"day":2,"households":16,"food_units":12.0,"shortages":0})
    var migrated = w.migrate_legacy(saved)
    assert(not migrated.is_empty(), "v15 to v16 migration")
    assert(migrated.agents[0].supplies == 12.0, "food preserved")
    assert(migrated.agents[0].unfed_days == 4, "hunger preserved")
    assert(migrated.agents[0].destination == "work", "destination preserved")
    assert(migrated.longplay.household_snapshots.size() > 0, "history preserved")
    assert(w.validate_state(migrated), "migrated state valid")
    print("v16 runtime PASS")
    quit(0)
