extends SceneTree
const Main = preload("res://main.tscn")
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	var first = Main.instantiate()
	var second = Main.instantiate()
	root.add_child(first)
	root.add_child(second)
	await process_frame
	first.world.advance_safe(120)
	var saved: String = first._save()
	var loaded: String = second._load()
	for i in range(180):
		first.world.step(false)
		second.world.step(false)
	var same: bool = var_to_bytes(first.world.s) == var_to_bytes(second.world.s)
	print("SAVE PRECISION: ", same and saved == "保存した。" and loaded.contains("読み込んだ"))
	first.queue_free()
	second.queue_free()
	await process_frame
	quit(0 if same else 1)
