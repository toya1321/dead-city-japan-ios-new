extends SceneTree
const World = preload("res://scripts/world.gd")
func _initialize() -> void:
    var w = World.new()
    assert(w.validate_state(w.s))
    var first: Dictionary = w.s.agents[0]
    var second: Dictionary = w.s.agents[1]
    first.x = 0.0
    first.z = 18.5
    first.supplies = 0.0
    second.x = 0.0
    second.z = 18.5
    second.supplies = 10.0
    w.s.minute = 1440
    w._allocate_household_meals()
    assert(int(first.unfed_days) == 1, "No long-distance meal transfer")
    assert(float(second.supplies) == 9.0, "Resident consumes own food")
    first.x = first.home_x
    first.z = first.home_z
    second.x = second.home_x
    second.z = second.home_z
    w._allocate_household_meals()
    assert(int(first.unfed_days) == 0, "Food can be shared when co-located")
    assert(w.validate_state(w.s))
    print("v15 runtime PASS")
    quit(0)
