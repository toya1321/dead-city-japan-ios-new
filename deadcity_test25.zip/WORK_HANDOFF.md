# Workへの引き継ぎ指示（そのまま貼り付け可）

添付の DEAD_CITY_JAPAN_CHRONICLE_LONGPLAY_v5.zip を使ってください。旧3D版ではなく、文章＋挿絵主体のGodot 4.4プロジェクトです。

1. ZIPを展開し、project.godot を確認する。GitHubの旧3D版と混ぜない。
2. Godot 4.4+ の headless editor import、GDScript構文解析、`tests/test_runtime.gd` と `tests/test_main_runtime.gd` を実行する。失敗した場合は修正し再テストする。
3. GUI操作、文章入力、全5部屋、屋外出入り、食事・飲水、睡眠、探索、栽培、修繕、日誌、セーブ・ロードを実際にテストする。
4. 数日〜数年の長期シミュレーションについて、死亡・食料枯渇・経年劣化・感染・セーブサイズ・速度を測定し、重大な問題を修正する。ゲームの長期バランスは未検証。
5. iOS向けエクスポート設定、必要な署名／未署名の条件を確認し、iPhoneでインストール可能なIPAをビルドする。未署名IPAは通常そのままではインストールできない。IPAとビルドログ、テスト結果を納品する。
6. できれば安定版の新規リポジトリまたは新規ブランチに配置し、旧3D版のファイルを誤って混ぜない。

重要：このv5は完成版を名乗らない。長期シミュレーションの基礎を実装した検証候補。自由文の完全理解、何年分ものコンテンツ、実機検証、完成度保証は未達。


## v6 visual QA
- Open the project in Godot to import JPGs; check that image loads, scales and caption updates.
- Test bedroom, living, kitchen, entrance, street; test `窓を見る` before and after social phases.
- Ensure images remain bundled in iOS export, no network requests. Check iPhone text clipping and performance.
- These are concept-art-derived illustrations, not action-by-action AI generation; expand art only after testing.
