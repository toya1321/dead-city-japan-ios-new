# DEAD CITY JAPAN — CHRONICLE / v9 development status

## Implemented in source (not yet Godot-runtime-verified)

- Existing landscape 1280x720 interface, five indoor/outdoor scenes, status panels and command UI
- Independent hourly infection / infrastructure simulation and daily longplay state
- Seeded world event records for routine life, first reports, shortages, traffic disruption, evacuation reports, outages, snowfall and vegetation changes
- Event history capped at 240; save validation checks event shapes
- Knowledge boundary: events are visible in the player's event journal only after the player receives regional news or directly observes a recent local event. Opening a menu does not create world events
- Event-to-art lookup reuses existing 28 JPG images; missing dedicated event images are **not** generated or claimed
- Before-collapse online orders for food and water: payment, delivery queue, delivery ETA, delayed fulfillment and failure if logistics collapse. Orders persist in saves; older saves lacking the order array are migrated on load
- Door fortification and bandaging accessible via text commands
- Added v9 structural tests and Godot runtime test script

## Known limitations / not completed

- Godot engine execution and iPhone landscape UI testing were unavailable in this environment. **Do not ship an IPA without running these tests.**
- Free-form natural language interpretation remains keyword-based; it is not a general language model
- World NPCs are limited; no persistent complex relationships, schedules, individual households or advanced AI
- No unique illustration for every possible event. Reused scene artwork can be semantically approximate
- No online image generation, no dynamic scene composition for weather/person/position
- No full economic simulation or real courier NPC route. Order completion is abstracted
- Shops and street navigation in text mode are incomplete; indoor base play works only with supported commands
- No performance profiling for decade-scale fast-forward; per-minute simulation is computationally expensive
- Order failures currently do not refund automatically; this is shown explicitly in the event text

## How Work should verify

1. Unzip project and import with Godot 4.4 or compatible Godot 4 version.
2. Run `godot --headless --path . --script res://tests/test_system_runtime_v9.gd` and existing runtime tests.
3. Run the main scene; test `窓を見る`, `ニュースを見る`, `世界の出来事`, `通販で水を3個注文`, `配送状況`, room movement, door lock/unlock, food/water, save/load.
4. Confirm visual assets and input focus on actual iPhone 17 Pro landscape (safe areas, Dynamic Island, keyboard).
5. Fix all errors and only then produce unsigned IPA for signing via user's workflow.
