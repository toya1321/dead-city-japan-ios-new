# v11 — persistent resident relationships and histories

## Implemented

- Each of 48 simulated residents has stable ID, household ties and relationship strength (0–100).
- Household relationships evolve once per simulated day with deterministic seeded draws, whether or not the player is watching.
- A resident's death, isolation, reunification and monthly status are recorded as bounded world history.
- A resident profile API provides history for future discovery and interaction features. **The UI does not expose the profile API**; it only labels nearby visible residents with stable IDs. The game must not disclose private NPC history merely because it exists in the simulation.
- Existing v10 world-state saves (world version 15) are migrated to world version 16 on load, with new fields initialized. Older history cannot be reconstructed retroactively.
- Save validation checks the new relationships and historical records; events and historical arrays are bounded.
- A Godot runtime regression script `tests/test_resident_runtime_v11.gd` was added.

## Not implemented / not verified

- No complex NPC pathfinding, conversation or trust negotiation, relationships beyond households, event-specific illustrations, or multi-decade performance proof.
- No actual Godot execution or iPhone deployment was possible in this environment. Static Python checks do not prove runtime correctness.
- Previous v10 saves are only migrated when their remaining fields validate; corrupted saves remain rejected.

## Verification commands

`python3 tests/test_static.py && python3 tests/test_system_v9.py`

`godot --headless --path . --script res://tests/test_resident_runtime_v11.gd`
