# GitHub Actions build for CHRONICLE TEST 19

This source keeps the tested v19 game code and adds the previous working iOS unsigned build pipeline.

- Godot 4.6.3 stable, GitHub Actions macos-15.
- Builds an arm64 iPhoneOS app without Apple signing, strips any vendor ad-hoc signatures, and packages Payload/DeadCityJapan.app into an IPA for subsequent SideStore re-signing.
- Uses the existing app bundle identifier com.deadcityjapan.prototype, version 0.19.0 (19).
- Includes assets/private_rules.json and font license explicitly in the exported game pack.
- Runs all 23 Godot/Python test files before compiling the iOS app.
- SHA256SUMS.txt is generated from the final IPA.

TEST_REPORT_V19.md and IOS_BUILD_V19.md describe the earlier local Linux stage before this GitHub build. Refer to the completed GitHub Actions run and release for actual iOS build status. iPhone installation and real device UI remain unverified until tested by the user.
