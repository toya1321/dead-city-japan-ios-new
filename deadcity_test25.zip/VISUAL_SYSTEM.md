# Visual system v6

- Scene JPGs are bundled locally, so iOS works offline without image-generation API fees.
- Main scene image responds to room, window/news observation, and world phase (normal/alert/collapse/overgrown).
- Phase is derived from the autonomous world state, not from observing or interacting with the picture.
- Time/weather/day are shown in a caption; this version does not yet render unique images for every weather/time combination.
- Visuals are cropped from generated concept art; some smaller scene images are lower resolution and some phase variants are graded versions of the same artwork. These are **not** full bespoke illustrations for every action.
- Images are not a substitute for detailed event art or procedural scene generation. No image-generation API is embedded.
- Godot editor must import images before headless runtime tests or export; run `godot --headless --path . --editor --quit` then tests.
