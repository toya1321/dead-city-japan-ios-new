# DEAD CITY JAPAN — CHRONICLE TEST 24

Godot 4.6.3。`project.godot` を開いて実行。iPhone横画面向けテスト版。

右の行動メニューを撤去し、下部の文章入力で行動する。例：

- 台所へ行って食事し、水を飲んでからニュースを見る
- 玄関へ行って鍵を開けて食品店へ行く
- 店の在庫を見る
- 食料を3個買う
- 家に帰って7日待つ

長期待機は飲食・睡眠を含み、有限の物資を消費する。不足・体調悪化で中断する。屋外で自宅備蓄を使う長期待機はできない。

左が写真風の現在地、右が行動記録、下が複数行入力。持ち物・記録・保存・読込・設定は上部から開く。

初期状態はオフライン解析。AI解釈には設定画面でHTTPSのChat Completions互換接続先、モデル、APIキーを設定する。キーはセッション中のみで保存しない。AIが未知の仕組みを作ったりNPCを強制的に従わせたりする機能はない。実LLMの接続試験は未実施。対応範囲・試験結果・制限は `TEST_REPORT_V24.md` を参照。

テスト：`python3 tests/run_all.py test-results`。iOSビルドは `build_scripts/build-ios-unsigned.sh`（macOS/Xcode）とGitHub Actionsを使用。

写真素材は本プロジェクト用の生成画像。12枚の割当・生成情報は `PHOTO_ASSETS_V24.json`。以前の文書は過去版の記録で、最新の状況はTEST_REPORT_V24を優先する。
