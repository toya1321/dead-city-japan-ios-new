# iOSビルド引き継ぎ / TEST 19

## 今回の到達点

GodotでiOSエクスポートを実行しましたが、Godot 4.6.3用の `ios.zip` テンプレートがなく失敗しました。実行ログは `evidence/ios_export_attempt.log` です。
この環境はLinuxで、macOS・Xcode・iOS SDK・Apple署名環境もありません。**IPAもXcodeプロジェクトも生成していません。**
用意したものはGodotプロジェクト、iOSプリセット、Mac用のエクスポート補助スクリプトです。

## Macで続ける手順

1. Godot 4.6.3と同じ版のExport Templates、XcodeとiOSプラットフォームをインストールします。
2. このプロジェクトをGodotで開いて起動確認します。
3. Project → Export → `iOS Test` を選びます。ApplicationのTeam IDを自分のMacで入力し、Bundle Identifierが自分の署名設定で使えることを確認します。Appleのパスワードや証明書秘密鍵をチャットに送る必要はありません。
4. プリセットは `application/export_project_only=true` です。まずXcodeプロジェクトを書き出します。Godot GUIのExport Projectを使用するか、以下を実行します。

```bash
GODOT=/Applications/Godot.app/Contents/MacOS/Godot bash tools/export_ios_macos.sh
```

5. 生成された `.xcodeproj` をXcodeで開きます。Signing & Capabilitiesで自分のTeam、署名とプロビジョニングを設定します。接続したiPhoneを選択し、開発用ビルドをRunします。
6. 配布用IPAが必要なら、利用する署名方式に合わせてArchive → Distribute Appから書き出します。あるいは適切な署名情報を設定したうえでGodotのExport Project Onlyをオフにします。

スクリプトはmacOSの有無、Xcode、Godot版、Team ID未設定を検査します。Mac上での実行は未検証です。
署名なしIPAの生成・SideStoreでの再署名・JITの要否や動作は今回は確認していません。

## 実機で未確認の項目

- iPhone横画面と反対向き、Dynamic Island・ホームインジケータのセーフエリア
- 日本語キーボード／変換中の入力／送信と画面押し上げ
- スワイプ、タップの誤操作、文字サイズ
- バックグラウンド復帰、アプリ終了後の保存復元、低メモリ時
- 実機処理時間、温度、消費電力

1280×720の実行画面と、1560×720・1280×590のレイアウト検査はLinuxのGodotで取得・実行したものです。iPhone実機の画面ではありません。

## 公式資料

- https://docs.godotengine.org/en/4.6/tutorials/export/exporting_for_ios.html
- https://docs.godotengine.org/en/4.6/classes/class_editorexportplatformios.html

確認時点では公式手順もmacOSとXcode、Godot Export Templatesを前提としています。
