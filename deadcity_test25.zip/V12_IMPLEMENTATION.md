# v12 — survival consistency and save hardening

- NPC food no longer magically refills from the district stockpile each minute.
- Resident food stock decreases once per simulation day; shopping/search can replenish it probabilistically.
- Hunger accumulates when supplies run out and can eventually cause death; shortage is recorded in private resident history.
- v10 (world version 15) and v11 (world version 16) data migrate to v12 world version 17.
- Both raw world save/load and app-level load validate state before committing loaded data.
- Visual coverage audit included. No new illustration was created; unique event illustrations are **not** complete.

## Limitations

This remains a prototype. No Godot/iPhone runtime execution was performed here. Daily food is simplified, there is no household sharing, and starvation consequences are not a calibrated medical model. The old per-minute simulator is not performance-validated for multi-decade play. A complete autonomous world and free-form language action system do not yet exist.
