# v13: Household resource sharing

## Implemented
- Living survivors in the same household can share **finite** food supplies at the daily meal tick.
- No resource creation in the transfer step; exactly one food unit is deducted per successful meal.
- Priority rotates daily to avoid systematically starving the same person during shortages.
- Failed meals increment individual `unfed_days` and record a bounded shortage event.
- `household_status` exposes an internal aggregate without mutating simulation state. UI must still enforce player knowledge.
- Daily bounded `household_snapshots` (365-day rolling history) record household food and shortages.
- Save format version 18; migration supports versions 15, 16, 17.
- Godot headless test: `godot --headless --path . --script res://tests/test_household_runtime_v13.gd`.

## Not yet implemented
- Shared housing locations, real travel to household addresses, reciprocal trades, NPC negotiations, complex decisions, births/aging, full long-horizon optimization, comprehensive illustrated event variants, and iPhone IPA.
- Godot runtime and iPhone device checks have not been executed in this environment.
