extends ScrollContainer
# Own press/release arbitration before child buttons consume GUI events.
# Native wheel scrolling remains available. Touch-generated mouse events are
# suppressed so a single finger tap can never activate a button twice.
var interaction_enabled := true:
	set(value):
		interaction_enabled=value
		if not value:_cancel_gesture()
var pointer := -999
var start_pos := Vector2.ZERO
var start_scroll := 0
var dragging := false
var moved := false
var pressed_button: Button
var last_touch_ms := -1000
var drag_threshold := 14.0
var velocity := 0.0
var last_y := 0.0
var last_ms := 0

func _ready() -> void:
	scroll_deadzone = 14
	follow_focus = false
	mouse_filter = Control.MOUSE_FILTER_PASS

func _button_at(node: Node, pos: Vector2) -> Button:
	var children := node.get_children()
	children.reverse()
	for child in children:
		if child is Control and not child.is_visible_in_tree(): continue
		var found := _button_at(child, pos)
		if found != null: return found
	if node is Button and node.is_visible_in_tree() and node.get_global_rect().has_point(pos):
		return node as Button
	return null

func _editable_at(node: Node, pos: Vector2) -> bool:
	if node is Control and not node.is_visible_in_tree():return false
	if (node is LineEdit or node is TextEdit or node is CheckButton) and node.get_global_rect().has_point(pos):return true
	for child in node.get_children():
		if _editable_at(child,pos):return true
	return false

func _input(event: InputEvent) -> void:
	if not interaction_enabled or not is_visible_in_tree(): return
	var touch := event is InputEventScreenTouch or event is InputEventScreenDrag
	var mouse := event is InputEventMouseButton or event is InputEventMouseMotion
	if not touch and not mouse: return
	var pos: Vector2 = get_canvas_transform().affine_inverse()*event.position
	var inside := get_global_rect().has_point(pos)
	# Editable settings and toggles need Godot GUI focus/keyboard handling.
	if pointer==-999 and inside and _editable_at(self,pos):return
	# Godot dispatches the emulated mouse BEFORE its source touch. A time
	# window after the touch cannot suppress that first emulated press, and
	# leaves pointer=-1 captured forever once native touches take over.
	# Only these scroll areas suppress emulation; title/forms/navigation keep
	# their normal GUI mouse emulation.
	if mouse and event.device == InputEvent.DEVICE_ID_EMULATION:
		if inside or pointer != -999: get_viewport().set_input_as_handled()
		return
	if touch: last_touch_ms = Time.get_ticks_msec()
	var id: int = event.index if touch else -1
	if event is InputEventMouseButton and event.button_index != MOUSE_BUTTON_LEFT: return
	var pressed: bool = (event is InputEventScreenTouch or event is InputEventMouseButton) and event.pressed
	var released: bool = (event is InputEventScreenTouch or event is InputEventMouseButton) and not event.pressed
	if pressed:
		if not inside: return
		# Leave the narrow native scroll bar usable for desktop users.
		if mouse and pos.x >= get_global_rect().end.x-18: return
		if pointer != -999:
			get_viewport().set_input_as_handled()
			return
		pointer = id
		start_pos = pos
		start_scroll = scroll_vertical
		last_y = pos.y
		last_ms = Time.get_ticks_msec()
		velocity = 0.0
		dragging = false
		moved = false
		pressed_button = _button_at(self, pos)
		if pressed_button != null and not pressed_button.disabled:
			pressed_button.set_pressed_no_signal(true)
		get_viewport().set_input_as_handled()
	elif pointer == id:
		if released:
			var button := pressed_button
			var canceled: bool = event.canceled if event is InputEventScreenTouch else false
			var activate := not canceled and not moved and not dragging and is_instance_valid(button) and not button.disabled and button.get_global_rect().has_point(pos) and inside
			if is_instance_valid(button): button.set_pressed_no_signal(false)
			pointer = -999
			pressed_button = null
			get_viewport().set_input_as_handled()
			if activate:
				velocity = 0.0
				button.pressed.emit()
		else:
			var delta := pos-start_pos
			if delta.length() >= drag_threshold:moved=true
			if not dragging and absf(delta.y) >= drag_threshold and absf(delta.y) >= absf(delta.x)*0.7:
				dragging = true
				if is_instance_valid(pressed_button): pressed_button.set_pressed_no_signal(false)
			if dragging:
				scroll_vertical = start_scroll + int(start_pos.y-pos.y)
				var now := Time.get_ticks_msec()
				velocity = clampf((last_y-pos.y)*1000.0/maxf(16.0,float(now-last_ms)), -1500.0,1500.0)
				last_y = pos.y
				last_ms = now
			get_viewport().set_input_as_handled()

func _process(delta: float) -> void:
	if pointer == -999 and absf(velocity) > 15.0:
		scroll_vertical += int(velocity*delta)
		velocity *= exp(-9.0*delta)
	else:
		if pointer == -999: velocity = 0.0

func _cancel_gesture() -> void:
	if is_instance_valid(pressed_button):pressed_button.set_pressed_no_signal(false)
	pointer=-999
	pressed_button=null
	dragging=false
	moved=false
	velocity=0.0
func _notification(what: int) -> void:
	if what in [NOTIFICATION_WM_WINDOW_FOCUS_OUT,NOTIFICATION_APPLICATION_PAUSED,NOTIFICATION_EXIT_TREE]:
		_cancel_gesture()
	elif what==NOTIFICATION_VISIBILITY_CHANGED and not is_visible_in_tree():
		_cancel_gesture()
