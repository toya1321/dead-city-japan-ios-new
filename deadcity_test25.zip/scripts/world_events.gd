extends RefCounted
const REGION_NAMES = ["北海道","東北","関東","中部","関西","中国","四国","九州"]
const CATALOG_PATH = "res://assets/event_catalog.json"
static var definitions: Array = []
static func catalog() -> Array:
	if definitions.is_empty(): definitions = JSON.parse_string(FileAccess.get_file_as_string(CATALOG_PATH))
	return definitions
static func region_for_address(address: String) -> int:
	if address.contains("北海道"):return 0
	for key in ["青森","岩手","宮城","秋田","山形","福島","東北"]:
		if address.contains(key):return 1
	for key in ["大阪","京都","兵庫","奈良","滋賀","和歌山","関西"]:
		if address.contains(key):return 4
	for key in ["広島","岡山","鳥取","島根","山口","中国"]:
		if address.contains(key):return 5
	for key in ["徳島","香川","愛媛","高知","四国"]:
		if address.contains(key):return 6
	for key in ["福岡","佐賀","長崎","熊本","大分","宮崎","鹿児島","沖縄","九州"]:
		if address.contains(key):return 7
	for key in ["愛知","岐阜","静岡","長野","新潟","富山","石川","福井","山梨","中部"]:
		if address.contains(key):return 3
	return 2
static func fresh_sim() -> Dictionary:
	var regions: Array = []
	for i in range(8):regions.append({"id":i,"name":REGION_NAMES[i],"population":20000,"active":0,"cumulative":0,"reported":0,"food":10000.0,"water":30000.0})
	return {"schema":1,"local_region":2,"regions":regions,"logistics":100.0,"security":100.0,"communications":100.0,"hospital_load":0.0,"contact_factor":1.0,"traffic":1.0,"phone_charge":100.0,"payroll":50000000.0,"panic":false,"rationing":false,"schools_open":true,"clinic_open":true,"road_blocked_until":0,"curfew_until":0,"gardens":0,"garden_planted_at":0,"garden_last_harvest":0,"study_sessions":0,"warehouse":{"food":50000.0,"water":100000.0,"wood":4000.0,"parts":4000.0,"seeds":4000.0,"bandage":4000.0,"filter":10.0,"solar":5.0,"battery":5.0},"salvage_parts":300.0,"last_events":{},"event_counts":{},"active":[],"next_event_id":1,"archived_total":0,"archive_years":{},"emissions_hour":-1,"emissions_count":0,"initial_society":"normal"}
static func initialize(w: RefCounted) -> void:
	w.s.sim=fresh_sim()
	for a in w.s.agents:
		if int(a.id)%12==0:
			a.occupation="student"
			a.role="学生"
	upgrade_data(w.s)
static func upgrade_data(data: Dictionary) -> void:
	if not data.has("profile"):data.profile={"name":"トウヤ","age":31,"address":"東京都渋谷区笹塚","job":"無職","housing":"一戸建て","cohabitants":0,"companion_names":[],"seed":int(data.get("seed",481516)),"has_key":true}
	if not data.has("household_members"):data.household_members=[]
	if not data.has("sim"):data.sim=fresh_sim()
	for field in ["garden_planted_at","garden_last_harvest"]:
		if not data.sim.has(field):data.sim[field]=0
	if not data.get("shops") is Dictionary or not data.get("agents") is Array:return
	for shop_id in data.shops:
		var shop=data.shops[shop_id]
		if not shop is Dictionary:continue
		for field in {"open":true,"closed_until":0,"abandoned":false,"queue_minutes":0,"till":0.0}:
			if not shop.has(field):shop[field]={"open":true,"closed_until":0,"abandoned":false,"queue_minutes":0,"till":0.0}[field]
		if shop_id=="hardware" and shop.get("stock") is Dictionary:
			for field in {"filter":4.0,"solar":2.0,"battery":2.0}:
				if not shop.stock.has(field):shop.stock[field]={"filter":4.0,"solar":2.0,"battery":2.0}[field]
	for actor in data.agents:
		if not actor is Dictionary:continue
		if not actor.has("work_shop"):actor.work_shop=["grocer","hardware","pharmacy"][(int(actor.get("id",0))/4)%3] if actor.get("occupation")=="retail" else ""
		if not actor.has("age"):actor.age=16 if actor.get("occupation")=="student" else 20+int(actor.get("id",0))%50
		for field in {"cash":3000.0,"departed":false,"sick_until":0,"remote_until":0,"override_until":0,"override_activity":"home","override_destination":"home"}:
			if not actor.has(field):actor[field]={"cash":3000.0,"departed":false,"sick_until":0,"remote_until":0,"override_until":0,"override_activity":"home","override_destination":"home"}[field]
static func seasonal_weather(w: RefCounted,day: int) -> String:
	var calendar:=Time.get_datetime_dict_from_unix_time(int(Time.get_unix_time_from_datetime_string(w.START_TIME))+day*86400)
	var roll:int=w.draw(day,0,"weather")
	if roll<4300:return "clear"
	if roll<7800:return "cloudy"
	if int(calendar.month) in [12,1,2] and roll>9400:return "snow"
	return "rain"
static func tick(w: RefCounted) -> void:
	var sim:Dictionary=w.s.sim
	var minute:=int(w.s.minute)
	var hour:=int(w.hour_of_day())
	sim.phone_charge=clampf(float(sim.phone_charge)+(10.0 if w.s.grid_online and float(w.s.player_pos[2])<3.0 else -1.0),0,100)
	_resolve(w)
	sim.clinic_open=hour>=9 and hour<17 and float(sim.hospital_load)<95
	_epidemic(w)
	_shops(w)
	if hour>=21 or hour<8:sim.traffic=0.25
	elif not _active(sim,"commute"):sim.traffic=1.0 if w.s.society in ["normal","alert"] else 0.3
	for shop_id in w.s.shops:
		if not _active(sim,"lunch"):w.s.shops[shop_id].queue_minutes=0
	# Up to two independently rolled catalogue events per hour. Scheduling and
	# preconditions are checked before any effect or cooldown is committed.
	var accepted:=0
	var candidates: Array=catalog().duplicate()
	candidates.sort_custom(func(a,b):return w.draw(minute/60,0,str(a.id)+"-priority")<w.draw(minute/60,0,str(b.id)+"-priority"))
	for definition in candidates:
		if accepted>=2:break
		if not eligible(w,definition):continue
		if w.draw(minute/60,int(sim.local_region),"event-"+str(definition.id),10000)>=int(definition.chance):continue
		if trigger(w,str(definition.id)):accepted+=1
static func _epidemic(w: RefCounted) -> void:
	var minute:=int(w.s.minute)
	if minute%360!=0:return
	var sim:Dictionary=w.s.sim
	var active_total:=0
	var reported_total:=0
	for region in sim.regions:
		var id:=int(region.id)
		if minute>=3*1440 and int(region.active)==0 and int(region.cumulative)<int(region.population) and w.draw(minute,id,"independent-introduction",10000)<60:
			region.active=1
			region.cumulative+=1
		if int(region.active)>0:
			var susceptible:=int(region.population)-int(region.cumulative)
			var fractional:float=float(region.active)*(0.16+float(w.draw(minute,id,"spread-variation",15))/100.0)*float(sim.contact_factor)
			var growth:=int(fractional)
			if w.draw(minute,id,"spread-rounding",10000)<int(fmod(fractional,1)*10000):growth+=1
			growth=mini(susceptible,growth)
			var recovered:=int(float(region.active)*0.045)
			region.active=maxi(0,int(region.active)+growth-recovered)
			region.cumulative+=growth
			region.reported=mini(int(region.cumulative),int(region.reported)+maxi(0,int(float(region.active)*0.08)))
		active_total+=int(region.active)
		reported_total+=int(region.reported)
	w.s.regional_cases=reported_total
	w.s.outbreak_pressure=clampf(float(active_total)/160000.0*500.0,0,100)
	sim.hospital_load=clampf(float(sim.hospital_load)*0.88+float(w.s.outbreak_pressure)*0.12,0,100)
	if active_total>100:sim.logistics=maxf(0,float(sim.logistics)-float(w.s.outbreak_pressure)*0.035)
	elif float(sim.logistics)<100:sim.logistics=minf(100,float(sim.logistics)+0.5)
	sim.security=clampf(float(sim.security)+(0.08 if active_total<100 else -float(w.s.outbreak_pressure)*0.015)-maxf(0,60-float(sim.logistics))*0.003,0,100)
	var previous:String=w.s.society
	if float(sim.logistics)<30 or float(sim.hospital_load)>80:w.s.society="emergency"
	elif float(sim.logistics)<65 or float(sim.hospital_load)>45:w.s.society="disrupted"
	elif reported_total>=20:w.s.society="alert"
	else:w.s.society="normal"
	if previous!=w.s.society:
		emit_event(w,"society_change","地域の生活状況に変化が報じられた。",{"society_before":previous,"society_after":w.s.society},"broadcast",-1,[],true)
	# Local infections are a consequence of prevalence, never an observation.
	if w.s.society!="normal":
		for actor in w.s.agents:
			if not actor.dead and not actor.departed and actor.kind=="survivor" and int(actor.exposure)<0 and w.draw(minute,int(actor.id),"background-infection",10000)<int(float(w.s.outbreak_pressure)*1.5*float(sim.contact_factor)):
				actor.exposure=minute
				actor.symptoms_due=minute+w.incubation(int(actor.id))
static func _shops(w: RefCounted) -> void:
	var hour:float=w.hour_of_day()
	for id in w.s.shops:
		var shop:Dictionary=w.s.shops[id]
		var open_now:bool=hour>=8 and hour<21 and int(shop.closed_until)<=int(w.s.minute) and not bool(shop.abandoned) and _has_staff(w,str(id))
		if open_now!=bool(shop.open):
			shop.open=open_now
			emit_event(w,"shop_open" if open_now else "shop_close",str(shop.name)+("が営業を始めた。" if open_now else "が営業を終了した。"),{"shop":id,"open":open_now},"sight",-1,[float(shop.x),float(shop.z)],true)
static func _active(sim: Dictionary,id: String) -> bool:
	for event in sim.active:
		if event.kind==id:return true
	return false
static func _resolve(w: RefCounted) -> void:
	var sim:Dictionary=w.s.sim
	var pending:Array=[]
	for event in sim.active:
		if int(event.until)>int(w.s.minute):pending.append(event);continue
		match str(event.kind):
			"network":sim.communications=100.0
			"panic":sim.panic=false
			"ration":sim.rationing=false
			"notice":sim.contact_factor=1.0
			"blackout":
				if w.s.grid_online:continue
				if float(sim.logistics)<15 or float(sim.warehouse.parts)<2:
					event.until=int(w.s.minute)+1440;pending.append(event);continue
				sim.warehouse.parts-=2;w.s.grid_online=true
			"water_outage":
				if w.s.water_online:continue
				if float(sim.logistics)<15 or float(sim.warehouse.parts)<2:
					event.until=int(w.s.minute)+1440;pending.append(event);continue
				sim.warehouse.parts-=2;w.s.water_online=true
			"cold":pass
		var notices:Dictionary={"network":"通信サービスが復旧した。","panic":"買い置き需要の急増が落ち着いてきた。","ration":"店舗の購入制限が解除された。","notice":"集会の自粛要請期間が終了した。","blackout":"地域の電力供給が復旧した。","water_outage":"地域の水道供給が復旧した。","road":"通行止めが解除された。","curfew":"外出自粛要請の期間が終了した。"}
		if notices.has(event.kind):emit_event(w,str(event.kind)+"_resolved",notices[event.kind],{"resolved":event.kind},"broadcast",-1,[],true)
	sim.active=pending
static func eligible(w: RefCounted,d: Dictionary) -> bool:
	var sim:Dictionary=w.s.sim
	var m:=int(w.s.minute)
	if m-int(sim.last_events.get(d.id,-100000000))<int(d.cooldown) or _active(sim,str(d.id)):return false
	var society:String=w.s.society
	if d.phase=="normal" and society!="normal":return false
	if d.phase=="alert" and society=="normal":return false
	if d.phase=="disrupted" and society not in ["disrupted","emergency"]:return false
	if d.phase=="long" and society!="emergency" and m<30*1440:return false
	var hour:=int(w.hour_of_day())
	match str(d.id):
		"commute":return hour==9 and (2+m/1440)%7<5 and not _living(w).is_empty()
		"school":
			if hour!=9 or (2+m/1440)%7>=5:return false
			for a in _living(w):
				if a.occupation=="student":return true
			return false
		"delivery":return hour==10 and float(sim.logistics)>=25 and float(sim.warehouse.food)>0
		"lunch":return hour==12 and w.can_trade("grocer")
		"neighbour","park":return hour>=10 and hour<18 and not _living(w).is_empty()
		"clinic":return hour==9
		"maintenance":return float(sim.warehouse.parts)>=2 and float(sim.logistics)>60
		"rain":return w.s.weather!="rain"
		"clear":return w.s.weather!="clear"
		"rumour":return int(w.s.regional_cases)>0
		"ambulance","absence":return _patient(w)!=null
		"panic":return float(w.s.shops.grocer.stock.food)>0 and not _living(w).is_empty()
		"delay":return float(sim.logistics)>10
		"shortage":return _retailer(w)!=null
		"hospital":return float(sim.hospital_load)>10
		"notice","remote","ration":return not _living(w).is_empty()
		"road":return int(sim.road_blocked_until)<=m
		"network":return float(sim.communications)>0
		"blackout":return bool(w.s.grid_online)
		"water_outage":return bool(w.s.water_online)
		"curfew","patrol","evacuation":return not _living(w).is_empty()
		"fire":return not _living(w).is_empty() and float(sim.security)<85
		"abandoned":return _empty_shop(w)!=""
		"mutual_aid":return _aid_pair(w).size()==2
		"repair_grid":return not w.s.grid_online and float(sim.warehouse.parts)>=4 and _living(w).size()>=2
		"repair_water":return not w.s.water_online and float(sim.warehouse.parts)>=4 and _living(w).size()>=2
		"garden":return float(sim.warehouse.seeds)>=2 and _living(w).size()>=2 and int(sim.gardens)<12
		"workshop":return float(sim.salvage_parts)>0 and not _living(w).is_empty()
		"trade":return float(sim.logistics)>10 and float(sim.regions[(int(sim.local_region)+1)%8].food)>=20
		"return":
			for a in w.s.agents:
				if not a.dead and bool(a.departed):return true
			return false
		"cold":return int(_calendar(w).month) in [11,12,1,2] and w.s.weather in ["cloudy","snow"]
		"pests":return not w.s.plots.is_empty() and float(w.s.plots[0].growth)>0.2
		"filter_wear":return bool(w.s.equipment.filter) and float(w.s.longplay.filter_condition)>0 and float(w.s.longplay.water_collected)>0
		"crop_care":return int(sim.gardens)>0 and hour==11 and float(sim.warehouse.water)>=2 and not _living(w).is_empty()
	return false
static func trigger(w: RefCounted,id: String) -> bool:
	var definition:Dictionary={}
	for d in catalog():
		if d.id==id:definition=d;break
	if definition.is_empty() or not eligible(w,definition):return false
	var effect:=_apply(w,id)
	if effect.is_empty():return false
	w.s.sim.last_events[id]=int(w.s.minute)
	if int(definition.duration)>0:w.s.sim.active.append({"kind":id,"until":int(w.s.minute)+int(definition.duration)})
	var actor_id:=int(effect.get("actor",-1))
	var position:Array=effect.get("position",[])
	var channel:String=effect.get("channel","broadcast")
	var verified:bool=id!="rumour"
	emit_event(w,id,str(definition.title)+"。"+str(effect.get("summary","")),effect,channel,actor_id,position,verified)
	return true
static func _apply(w: RefCounted,id: String) -> Dictionary:
	var sim:Dictionary=w.s.sim
	var m:=int(w.s.minute)
	match id:
		"commute":sim.traffic=1.4;return {"traffic":1.4,"position":[0.0,14.0],"channel":"sight","summary":"通りの交通量が増えている。"}
		"school":
			sim.schools_open=true
			for a in _living(w):
				if a.occupation=="student":_send(w,a,"work","work",480)
			return {"school_open":true,"summary":"通学と授業が行われている。"}
		"delivery":
			var moved:=restock(w)
			return {"transferred":moved,"position":[20.0,19.3],"channel":"sight","summary":"倉庫の物資が店へ運ばれた。"} if moved>0 else {}
		"lunch":w.s.shops.grocer.queue_minutes=5;return {"queue_minutes":5,"position":[20.0,19.3],"channel":"sight","summary":"買い物客で会計に時間がかかる。"}
		"neighbour":
			var a:Dictionary=_living(w)[0];_send(w,a,"shopping","shopping",120)
			return {"actor":int(a.id),"position":[float(a.x),float(a.z)],"channel":"sight","summary":"住民が食品店へ向かっている。"}
		"park":
			var a:Dictionary=_living(w)[-1];_send(w,a,"rest","park",120)
			return {"actor":int(a.id),"position":[float(a.x),float(a.z)],"channel":"sight","summary":"住民が近隣の散歩に出た。"}
		"clinic":sim.clinic_open=true;sim.hospital_load=maxf(0,float(sim.hospital_load)-5);return {"hospital_load":sim.hospital_load,"position":[-22.0,19.3],"channel":"sight","summary":"外来診療が始まった。"}
		"maintenance":sim.warehouse.parts-=2;sim.security=minf(100,float(sim.security)+3);return {"parts_used":2,"security":sim.security,"summary":"保守資材が使われ、設備点検が行われた。"}
		"rain":w.s.weather="rain";return {"weather":"rain","position":[0.0,14.0],"channel":"sight","summary":"雨が降り始めた。"}
		"clear":w.s.weather="clear";return {"weather":"clear","position":[0.0,14.0],"channel":"sight","summary":"雲が切れ、日差しが届いている。"}
		"rumour":sim.logistics=maxf(0,float(sim.logistics)-1);return {"verified":false,"channel":"sns","summary":"情報の真偽は確認されていない。受注の問い合わせが増えている。"}
		"ambulance":
			var a:Dictionary=_patient(w);_send(w,a,"rest","clinic",180)
			return {"actor":int(a.id),"position":[float(a.x),float(a.z)],"channel":"sight","summary":"体調の悪い住民が診療所へ向かっている。"}
		"absence":
			var a:Dictionary=_patient(w);a.sick_until=m+1440;_send(w,a,"rest","home",1440)
			return {"actor":int(a.id),"summary":"勤務の予定が取り消され、住民は自宅で休む。"}
		"panic":sim.panic=true;return {"demand_target":6,"summary":"住民の買い置き需要が増え、購入時の量が変わった。"}
		"delay":
			sim.logistics=maxf(0,float(sim.logistics)-12)
			var delayed:=0
			for order in w.s.longplay.orders:
				if order.status=="pending":order.due+=720;delayed+=1
			return {"logistics":sim.logistics,"delayed_orders":delayed,"summary":"未配達の注文は予定が12時間遅れた。"}
		"shortage":
			var a:Dictionary=_retailer(w)
			var shop_id:String=a.work_shop
			for colleague in _living(w):
				if str(colleague.get("work_shop",""))==shop_id:colleague.sick_until=m+720;_send(w,colleague,"rest","home",720)
			w.s.shops[shop_id].closed_until=m+720;w.s.shops[shop_id].open=false
			return {"actor":int(a.id),"shop":shop_id,"closed_until":m+720,"position":[float(w.s.shops[shop_id].x),float(w.s.shops[shop_id].z)],"channel":"sight","summary":"従業員の隔離で店舗が一時休業した。"}
		"hospital":sim.hospital_load=minf(100,float(sim.hospital_load)+15);return {"hospital_load":sim.hospital_load,"summary":"診療の待ち時間が長くなっている。"}
		"notice":sim.contact_factor=0.65;return {"contact_factor":0.65,"summary":"集会が縮小され、接触機会が減った。"}
		"remote":
			var changed:=0
			for a in _living(w):
				if a.occupation=="office":a.remote_until=m+2880;_send(w,a,"work","home",2880);changed+=1
			return {"residents":changed,"summary":"事務職の住民は在宅へ勤務先を切り替えた。"} if changed>0 else {}
		"ration":sim.rationing=true;return {"rationing":true,"summary":"店舗で購入できる数に制限が設けられた。"}
		"road":sim.road_blocked_until=m+720;return {"blocked_connector":50,"detour_connector":-50,"position":[50.0,26.0],"channel":"sight","summary":"住民は反対側の接続路へ迂回する。"}
		"network":sim.communications=0.0;return {"communications":0,"summary":"SNS・通販などの通信が利用できなくなった。"}
		"blackout":w.s.grid_online=false;return {"grid_online":false,"summary":"電力の供給が止まった。"}
		"water_outage":w.s.water_online=false;return {"water_online":false,"summary":"水道から水が出なくなった。"}
		"curfew":
			sim.curfew_until=m+1440;sim.traffic=0.2
			for a in _living(w):_send(w,a,"shelter","home",720)
			return {"curfew_until":sim.curfew_until,"summary":"住民は外出を控えている。プレイヤーの外出は禁止されていない。"}
		"patrol":
			var a:Dictionary=_living(w)[0];_send(w,a,"work","park",720);sim.security=minf(100,float(sim.security)+10)
			return {"actor":int(a.id),"security":sim.security,"position":[0.0,38.0],"channel":"sight","summary":"見回りのため住民が移動している。"}
		"evacuation":
			var a:Dictionary=_living(w)[-1];_send(w,a,"shelter","boundary",1440)
			return {"actor":int(a.id),"position":[float(a.x),float(a.z)],"channel":"sight","summary":"住民が地区の外へ移動し始めた。"}
		"fire":
			var shop:Dictionary=w.s.shops.hardware
			var loss:float=minf(4,float(shop.stock.wood));shop.stock.wood-=loss;shop.closed_until=m+1440;shop.open=false;sim.security=maxf(0,float(sim.security)-10)
			for a in _living(w):
				if Vector2(float(a.x),float(a.z)).distance_to(Vector2(38,19.3))<10:_send(w,a,"shelter","home",720)
			return {"shop":"hardware","stock_lost":loss,"position":[38.0,19.3],"channel":"sight","summary":"金物店の資材の一部が失われ、付近の人は離れた。自宅への火災ではない。"}
		"abandoned":
			var shop_id:=_empty_shop(w);w.s.shops[shop_id].abandoned=true;w.s.shops[shop_id].open=false
			return {"shop":shop_id,"position":[float(w.s.shops[shop_id].x),float(w.s.shops[shop_id].z)],"channel":"sight","summary":"店舗の営業が再開されなくなった。残った在庫は有限。"}
		"mutual_aid":
			var pair:=_aid_pair(w);pair[0].supplies-=1.0;pair[1].supplies+=1.0
			return {"actor":int(pair[0].id),"receiver":int(pair[1].id),"food_transferred":1,"position":[float(pair[0].x),float(pair[0].z)],"channel":"sight","summary":"同じ世帯の住民が食料を融通した。"}
		"repair_grid":sim.warehouse.parts-=4;w.s.grid_online=true;return {"parts_used":4,"grid_online":true,"summary":"残っていた資材を使い、電力が復旧した。"}
		"repair_water":sim.warehouse.parts-=4;w.s.water_online=true;return {"parts_used":4,"water_online":true,"summary":"残っていた資材を使い、水道が復旧した。"}
		"garden":
			sim.warehouse.seeds-=2;sim.gardens+=1;sim.garden_planted_at=m;var a:Dictionary=_living(w)[0];_send(w,a,"work","farm",1440)
			return {"actor":int(a.id),"seeds_used":2,"gardens":sim.gardens,"position":[-35.0,38.0],"channel":"sight","summary":"種を持ち寄り、住民が畑の世話を始めた。"}
		"workshop":
			var parts:float=minf(3,float(sim.salvage_parts));sim.salvage_parts-=parts;sim.warehouse.parts+=parts
			return {"parts_recovered":parts,"position":[38.0,19.3],"channel":"sight","summary":"回収可能な廃材から部品を確保した。"}
		"trade":
			var region:Dictionary=sim.regions[(int(sim.local_region)+1)%8];region.food-=20;sim.warehouse.food+=20;sim.logistics=maxf(0,float(sim.logistics)-0.5)
			return {"from_region":region.id,"food_transferred":20,"position":[55.0,38.0],"channel":"sight","summary":"隣接地域の備蓄から物資が運び込まれた。"}
		"return":
			for a in w.s.agents:
				if not a.dead and a.departed:a.departed=false;_send(w,a,"home","home",1440);return {"actor":int(a.id),"position":[float(a.x),float(a.z)],"channel":"sight","summary":"地区を離れていた住民が帰ってきた。"}
		"cold":w.s.weather="snow";return {"weather":"snow","position":[0.0,14.0],"channel":"sight","summary":"冷え込みで移動と屋外活動に時間がかかる。"}
		"pests":var loss:float=minf(0.12,float(w.s.plots[0].growth));w.s.plots[0].growth-=loss;return {"growth_lost":loss,"channel":"inspect","summary":"育てていた作物の一部が傷んでいる。"}
		"filter_wear":w.s.longplay.filter_condition=maxf(0,float(w.s.longplay.filter_condition)-2);return {"filter_condition":w.s.longplay.filter_condition,"channel":"inspect","summary":"浄水設備の消耗が進んだ。"}
		"crop_care":
			sim.warehouse.water-=2
			var harvested:=0.0
			if m-maxi(int(sim.garden_planted_at),int(sim.garden_last_harvest))>=30*1440:
				harvested=float(sim.gardens)*12.0*w._crop_growth_factor()
				sim.warehouse.food+=harvested
				sim.garden_last_harvest=m
			var actor:Dictionary=_living(w)[0];_send(w,actor,"work","farm",240)
			return {"actor":int(actor.id),"water_used":2,"food_grown":harvested,"position":[-35.0,38.0],"channel":"sight","summary":"共同菜園に水と労力を使った。"+("収穫物が共同倉庫に運ばれた。" if harvested>0 else "作物は育成中。")}

	return {}
static func restock(w: RefCounted) -> float:
	var total:=0.0
	for id in w.s.shops:
		var shop:Dictionary=w.s.shops[id]
		if shop.abandoned:continue
		for item in shop.stock:
			var target:=120.0 if item=="food" else (240.0 if item=="water" else (4.0 if item in ["filter","solar","battery"] else 40.0))
			var amount:float=minf(maxf(0,target-float(shop.stock[item])),float(w.s.sim.warehouse.get(item,0)))
			shop.stock[item]+=amount
			w.s.sim.warehouse[item]-=amount
			total+=amount
	return total
static func _living(w: RefCounted) -> Array:
	var result:Array=[]
	for a in w.s.agents:
		if not a.dead and not bool(a.get("departed",false)) and a.kind=="survivor":result.append(a)
	return result
static func _patient(w: RefCounted) -> Variant:
	for a in _living(w):
		if (int(a.exposure)>=0 or float(a.health)<85) and int(a.sick_until)<=int(w.s.minute):return a
	return null
static func _retailer(w: RefCounted) -> Variant:
	for a in _living(w):
		if a.occupation=="retail" and (int(a.exposure)>=0 or float(a.health)<85) and int(a.sick_until)<=int(w.s.minute):return a
	return null
static func _empty_shop(w: RefCounted) -> String:
	for id in w.s.shops:
		if w.s.shops[id].abandoned:continue
		var living_staff:=0
		for a in _living(w):
			if a.occupation=="retail" and str(a.work_shop)==str(id):living_staff+=1
		if living_staff==0:return str(id)
	return ""
static func _aid_pair(w: RefCounted) -> Array:
	for a in _living(w):
		if float(a.supplies)<2:continue
		for b in _living(w):
			if a.id!=b.id and a.household==b.household and float(b.supplies)<1 and Vector2(float(a.x),float(a.z)).distance_to(Vector2(float(b.x),float(b.z)))<2:return [a,b]
	return []
static func _send(w: RefCounted,a: Dictionary,activity: String,destination: String,duration: int) -> void:
	a.override_until=int(w.s.minute)+duration
	a.override_activity=activity
	a.override_destination=destination
	a.activity=activity
	a.destination=destination
static func _calendar(w: RefCounted) -> Dictionary:
	return Time.get_datetime_dict_from_unix_time(int(Time.get_unix_time_from_datetime_string(w.START_TIME))+int(w.s.minute)*60)
static func emit_event(w: RefCounted,kind: String,text: String,effects: Dictionary,channel: String,actor: int,position: Array,verified: bool) -> void:
	var sim:Dictionary=w.s.sim
	var serial:=int(sim.next_event_id)
	sim.next_event_id=serial+1
	sim.event_counts[kind]=int(sim.event_counts.get(kind,0))+1
	if w.s.events.size()>=240:
		var old:Dictionary=w.s.events.pop_front()
		var year:=str(int(old.minute)/(365*1440))
		if not sim.archive_years.has(year):sim.archive_years[year]={}
		var summary:Dictionary=sim.archive_years[year]
		summary[str(old.kind)]=int(summary.get(str(old.kind),0))+1
		sim.archived_total+=1
		while sim.archive_years.size()>120:sim.archive_years.erase(sim.archive_years.keys()[0])
	var record:Dictionary={"id":"E%012d"%serial,"minute":int(w.s.minute),"kind":kind,"text":text,"visual":"context","scope":"regional" if channel in ["broadcast","sns"] else "local","channel":channel,"region":int(sim.local_region),"actor":actor,"position":position.duplicate(),"verified":verified,"report_at":int(w.s.minute)+(60 if channel in ["broadcast","sns"] else 0),"effects":effects.duplicate(true)}
	w.s.events.append(record)
	if channel=="broadcast":w.s.last_news=text
static func observe(w: RefCounted,channel: String,location: String) -> Array:
	var result:Array=[]
	for event in w.s.events:
		if not event.has("channel"):continue
		var accessible:=false
		if channel in ["tv","sns","radio"] and int(event.report_at)<=int(w.s.minute):
			accessible=event.channel=="broadcast" or (channel=="sns" and event.channel=="sns")
		elif channel=="inspect" and event.channel=="inspect":accessible=location in ["寝室","居間","台所","廊下","玄関"]
		elif channel=="sight" and event.channel=="sight" and int(event.region)==int(w.s.sim.local_region) and int(w.s.minute)-int(event.minute)<=60 and event.position.size()==2:
			var origin:=Vector2(float(w.s.player_pos[0]),float(w.s.player_pos[2]))
			if location in ["寝室","居間","台所"]:origin=Vector2(0,12)
			accessible=origin.distance_to(Vector2(float(event.position[0]),float(event.position[1])))<=18
		if accessible:result.append(event.duplicate(true))
	result.reverse()
	return result
static func valid_data(data: Dictionary) -> bool:
	if not data.get("sim") is Dictionary or not data.get("household_members") is Array:return false
	var sim:Dictionary=data.sim
	for key in ["local_region","logistics","security","communications","hospital_load","contact_factor","traffic","phone_charge","payroll","road_blocked_until","curfew_until","gardens","study_sessions","next_event_id","archived_total"]:
		if not (sim.get(key) is int or sim.get(key) is float) or not is_finite(float(sim[key])) or float(sim[key])<0:return false
	if int(sim.local_region)>7:return false
	for key in ["logistics","security","communications","hospital_load","phone_charge"]:
		if float(sim[key])>100:return false
	for key in ["panic","rationing","schools_open","clinic_open"]:
		if not sim.get(key) is bool:return false
	for key in ["warehouse","last_events","event_counts","archive_years"]:
		if not sim.get(key) is Dictionary or sim[key].size()>256:return false
	for required in fresh_sim().warehouse:
		if not sim.warehouse.has(required):return false
	for amount in sim.warehouse.values():
		if not (amount is int or amount is float) or not is_finite(float(amount)) or float(amount)<0:return false
	for key in ["last_events","event_counts"]:
		for value in sim[key].values():
			if not (value is int or value is float) or not is_finite(float(value)) or float(value)<0:return false
	for year in sim.archive_years:
		if not sim.archive_years[year] is Dictionary:return false
		for count in sim.archive_years[year].values():
			if not (count is int or count is float) or not is_finite(float(count)) or float(count)<0:return false
	if not sim.get("regions") is Array or sim.regions.size()!=8:return false
	for region in sim.regions:
		if not region is Dictionary:return false
		for key in ["id","population","active","cumulative","reported","food","water"]:
			if not (region.get(key) is int or region.get(key) is float) or not is_finite(float(region[key])) or float(region[key])<0:return false
		if int(region.id)>7 or int(region.active)>int(region.population) or int(region.cumulative)>int(region.population) or int(region.reported)>int(region.cumulative):return false
	if not sim.get("active") is Array or sim.active.size()>64:return false
	for active in sim.active:
		if not active is Dictionary or not active.get("kind") is String or not (active.get("until") is int or active.get("until") is float):return false
	for event in data.events:
		if not event.has("channel"):continue # v19 record, retained as old known history
		for key in ["id","channel"]:
			if not event.get(key) is String:return false
		if event.channel not in ["broadcast","sns","sight","inspect"] or not event.get("verified") is bool or not event.get("effects") is Dictionary:return false
		if not event.get("position") is Array or event.position.size() not in [0,2]:return false
		for number in event.position:
			if not (number is int or number is float) or not is_finite(float(number)):return false
		for key in ["region","report_at"]:
			if not (event.get(key) is int or event.get(key) is float) or not is_finite(float(event[key])):return false
		if int(event.region)<0 or int(event.region)>7:return false
	if data.household_members.size()>3:return false
	for person in data.household_members:
		if not person is Dictionary or not person.get("name") is String or not person.get("location") is String or not person.get("activity") is String:return false
		for key in ["health","hunger","thirst","fatigue","food_used","water_used"]:
			if not (person.get(key) is int or person.get(key) is float) or not is_finite(float(person[key])) or float(person[key])<0:return false
	for actor in data.agents:
		if not actor.get("work_shop") is String or str(actor.work_shop) not in ["","grocer","hardware","pharmacy"]:return false
		for key in ["sick_until","remote_until","override_until","age"]:
			if not (actor.get(key) is int or actor.get(key) is float) or not is_finite(float(actor[key])) or float(actor[key])<0:return false
		for key in ["override_activity","override_destination"]:
			if not actor.get(key) is String:return false
		if not actor.get("departed") is bool or not (actor.get("cash") is int or actor.get("cash") is float) or not is_finite(float(actor.cash)) or float(actor.cash)<0:return false
	for id in data.shops:
		var shop:Dictionary=data.shops[id]
		if not shop.get("open") is bool or not shop.get("abandoned") is bool:return false
		for key in ["closed_until","queue_minutes","till"]:
			if not (shop.get(key) is int or shop.get(key) is float) or not is_finite(float(shop[key])) or float(shop[key])<0:return false
	return true

static func _has_staff(w: RefCounted,id: String) -> bool:
	for a in _living(w):
		if str(a.get("work_shop",""))==id and int(a.sick_until)<=int(w.s.minute):return true
	return false
