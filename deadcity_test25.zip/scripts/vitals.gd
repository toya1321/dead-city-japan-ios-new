extends RefCounted
static func values(state: Dictionary) -> Dictionary:
	return {"体力":clampf(float(state.health),0,100),"満腹度":100.0-clampf(float(state.hunger),0,100),"水分状態":100.0-clampf(float(state.thirst),0,100),"休息状態":100.0-clampf(float(state.fatigue),0,100)}
static func description(value: float) -> String:
	if value <= 15.0: return "危険"
	if value <= 40.0: return "不足"
	if value <= 65.0: return "やや低下"
	return "良好"
static func warning(state: Dictionary) -> String:
	var lines: Array[String] = []
	if float(state.health) <= 0: return "死亡しています。保存した記録を読み込めます。"
	if float(state.hunger) >= 85: lines.append("食事が必要です。満腹度が尽きると体力が減少します。")
	if float(state.thirst) >= 85: lines.append("水分が不足しています。飲料水を飲んでください。")
	if float(state.fatigue) >= 85: lines.append("休息が必要です。寝室で眠れます。")
	return "\n".join(lines)
