extends RefCounted
const NODES = ["寝室","居間","台所","廊下","玄関","共用廊下","建物前","屋外","食品店","金物店","薬局"]
const ALIASES = {"寝室":"寝室","自室":"寝室","リビング":"居間","居間":"居間","台所":"台所","キッチン":"台所","廊下":"廊下","室内":"廊下","玄関":"玄関","共用部分":"共用廊下","共用廊下":"共用廊下","建物の共用部分":"共用廊下","建物前":"建物前","建物の外":"建物前","街路":"屋外","外":"屋外","屋外":"屋外","食品店":"食品店","スーパー":"食品店","金物店":"金物店","薬局":"薬局","家":"玄関","自宅":"玄関"}
static func graph(housing: String) -> Dictionary:
	var g := {"寝室":["居間","廊下"],"居間":["寝室","台所","廊下","玄関"],"台所":["居間","廊下"],"廊下":["寝室","居間","台所","玄関"],"玄関":["居間","廊下"],"共用廊下":["玄関","建物前"],"建物前":["屋外"],"屋外":["建物前","食品店","金物店","薬局"],"食品店":["屋外"],"金物店":["屋外"],"薬局":["屋外"]}
	if housing == "集合住宅":
		g["玄関"].append("共用廊下")
		g["建物前"].append("共用廊下")
	else:
		g["玄関"].append("建物前")
		g["建物前"].append("玄関")
		g["共用廊下"] = []
	return g
static func route(from: String, to: String, housing: String) -> Array[String]:
	var g := graph(housing)
	if not g.has(from) or not g.has(to): return []
	var queue: Array = [[from]]
	var visited := {from:true}
	while not queue.is_empty():
		var path: Array = queue.pop_front()
		var current: String = path[-1]
		if current == to:
			var result: Array[String] = []
			for place in path: result.append(str(place))
			return result
		for neighbour in g[current]:
			if not visited.has(neighbour):
				visited[neighbour] = true
				var next := path.duplicate()
				next.append(neighbour)
				queue.append(next)
	return []
static func destination(raw: String) -> String:
	var cmd := raw.strip_edges().trim_suffix("。").replace("　", " ")
	if cmd in ["外に出る","外へ出る","外出する"]: return "屋外"
	if cmd in ["家に帰る","自宅に帰る","家に戻る","帰宅する","家に入る"]: return "玄関"
	var re := RegEx.new()
	re.compile("^(.+?)(?:へ|に)(?:移動(?:する)?|行く|戻る|帰る|出る)(?:してください)?$")
	var match_value := re.search(cmd)
	if match_value != null and ALIASES.has(match_value.get_string(1)): return str(ALIASES[match_value.get_string(1)])
	return ""
static func indoor(place: String) -> bool:
	return place in ["寝室","居間","台所","廊下","玄関"]
static func position(place: String) -> Array:
	match place:
		"玄関": return [0.0,1.6,2.0]
		"共用廊下": return [0.0,1.6,5.0]
		"建物前": return [0.0,1.6,8.5]
		"屋外": return [0.0,1.6,12.0]
		"食品店": return [20.0,1.6,19.3]
		"金物店": return [38.0,1.6,19.3]
		"薬局": return [-22.0,1.6,19.3]
	return [0.0,3.35,-2.0]
static func duration(from: String, to: String) -> int:
	if from in ["食品店","金物店","薬局"] or to in ["食品店","金物店","薬局"]: return 3
	return 1
