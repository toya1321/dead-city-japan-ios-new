extends Control
# Runtime overlays only. The photo is a location image, never an illustration
# of a specific event, a stock count, or a particular resident.
const PHOTO_NAMES={"寝室":"bedroom","居間":"living","台所":"kitchen","廊下":"hall","玄関":"entrance","共用廊下":"corridor","建物前":"building","屋外":"street","食品店":"grocer","金物店":"hardware","薬局":"pharmacy"}
var place:="寝室"
var hour:=8.0
var weather:="cloudy"
var power:=true
var shop_open:=true
var people:=0
var context:=""
var cache:Dictionary={}
func location_texture(location: String, override_name: String = "") -> Texture2D:
	var file:String=override_name if not override_name.is_empty() else PHOTO_NAMES.get(location,"")
	if file.is_empty():return null
	if not cache.has(file):cache[file]=load("res://assets/photos/"+file+".jpg")
	return cache[file]
func update_view(next_place:String,next_hour:float,next_weather:String,next_power:bool,next_shop_open:bool,visible_people:int,next_context:String)->void:
	place=next_place;hour=next_hour;weather=next_weather;power=next_power;shop_open=next_shop_open;people=visible_people;context=next_context
	queue_redraw()
func _draw()->void:
	var outdoor:bool=place in ["建物前","屋外","共用廊下","食品店","金物店","薬局"]
	var night:bool=hour<6 or hour>=18
	if night or (not outdoor and not power):draw_rect(Rect2(Vector2.ZERO,size),Color(0.02,0.04,0.09,0.64 if outdoor or not power else 0.18))
	if outdoor and weather in ["rain","snow"]:
		for i in range(35):
			var p:=Vector2(fmod(float(i)*53.0,maxf(size.x,1)),fmod(float(i)*37.0,maxf(size.y,1)))
			if weather=="rain":draw_line(p,p+Vector2(-5,15),Color(0.65,0.8,0.9,0.5),1)
			else:draw_circle(p,2,Color("#dbe4ed"))
