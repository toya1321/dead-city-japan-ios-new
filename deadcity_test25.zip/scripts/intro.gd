extends RefCounted
# Prologue is a presentation of the initial situation, never a world event.
# No hidden outbreak facts or future outcomes are exposed here.
const PAGES = [
	{
		"title": "いつもの朝",
		"body": "2026年11月10日、午前8時。東京・笹塚。\n\nカーテンの隙間から差し込む光で、目が覚めた。\n聞こえてくるのは、遠くを走る車の音。昨日と変わらない、住宅街の朝だ。\n\nあなたの名前はトウヤ。31歳。この家で、一人で暮らしている。\n今日、出勤する予定はない。急いで起き上がる理由も、今のところはない。"
	},
	{
		"title": "暮らしのある場所",
		"body": "寝室を出れば居間があり、テレビとテーブルが置かれている。台所には、普段の買い置きの食料と飲料水。玄関の鍵は閉まっている。\n\n朝食は、いつも食べない。このまま家でゆっくり過ごしてもいいし、外の様子を見に行ってもいい。\n\nテレビでニュースを確かめることも、必要なものを通販で注文することもできる。何から始めるかは、まだ決めていない。"
	},
	{
		"title": "今日をどう過ごそうか",
		"body": "窓の向こうには、あなたの暮らす街がある。\nそこで暮らす人たちにも、それぞれ帰る家があり、仕事や日々の用事がある。あなたに見られていない場所でも、人々は自分たちの生活を続けている。\n\n今、あなたがいるのは自宅の寝室。今日の予定は、まだ白紙だ。\n\nまずは窓をのぞいてみようか。ニュースをつけようか。それとも、居間へ行こうか。\nこの一日を、どう始める？"
	}
]

static func pages(profile: Dictionary) -> Array:
	var result: Array=PAGES.duplicate(true)
	var identity: String="あなたの名前は%s。%d歳。"%[str(profile.name),int(profile.age)]
	result[0].body=str(result[0].body).replace("あなたの名前はトウヤ。31歳。",identity).replace("東京・笹塚。",str(profile.address)+"。")
	var household: String="この%sで、一人で暮らしている。"%str(profile.housing)
	if int(profile.cohabitants)>0:household="この%sで、%d人の同居人と暮らしている。"%[str(profile.housing),int(profile.cohabitants)]
	result[0].body=str(result[0].body).replace("この家で、一人で暮らしている。",household)
	if profile.job!="無職":result[0].body=str(result[0].body).replace("今日、出勤する予定はない。急いで起き上がる理由も、今のところはない。","職業は%s。今日の過ごし方は、これから自分で決められる。"%str(profile.job))
	if profile.housing=="集合住宅":result[1].body=str(result[1].body)+"\n\n玄関の外は建物の共用廊下に通じている。"
	return result
