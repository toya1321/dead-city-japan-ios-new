# v17 audit (2026-11-10)

## Four pillars
1. Japanese input: rejects multiple clauses without side effects, negative instructions remain blocked, wait action reports *actual* elapsed time if the player dies early. This is NOT free-form semantic understanding.
2. NPC travel: existing road-lane navigation remains basic; optimized survivor threat checks to use a single snapshot of symptomatic positions per minute. Not full pathfinding or building collision.
3. Illustrations: existing coverage manifest checked, but NO new event illustrations were produced. All-event artwork remains incomplete.
4. Longplay: added `advance_safe` that refuses invalid intervals and returns actual elapsed minutes, rather than silently truncating. Does NOT implement multiyear fast-forward.

## Testing
`python tests/test_static.py`, `python tests/test_system_v9.py`, `python tests/test_v17_contract.py` are static tests only. `godot --headless --path . --script res://tests/test_v17_runtime.gd` must run on Godot 4.4+ before release. Existing version-pinned tests for v14-v16 intentionally fail on the new version and must be treated as historical checks, not current release gates. No Godot or iPhone execution verified.
