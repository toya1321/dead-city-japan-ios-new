# v15 audit and remaining work

Changes in executable source:
- Household meal sharing requires both giver and recipient at their common home; no remote food teleportation.
- Residents with home/shelter activity continue moving until arrival; earlier code stopped them immediately.
- Road-corridor waypoints added for basic home/work travel; not full pathfinding.
- Explicit negated wait commands no longer advance time; removed unsafe implicit `10分`/`1時間` fallback.
- Event images are explicitly labeled generic reference backgrounds; no claim of complete bespoke illustration coverage.
- State version bumped to 20 with migration from 19.

Important remaining issues:
- Existing residents can start on the road, and street routes are still simplistic. Some paths can remain blocked by geometry.
- No arbitrary Japanese natural-language planner; only supported commands execute.
- `advance()` is still minute-by-minute, maximum 1440 minutes per call; decades of fast-forward are not solved.
- All events do NOT have bespoke art. Visual references are mostly reused backgrounds.
- Runtime Godot and iPhone testing is required before claiming functionality.
