extends SceneTree

const Main = preload("res://main.tscn")
const Apple = preload("res://scripts/apple_planner.gd")
var failures := 0

class Bridge extends RefCounted:
	var state := "unsupportedOS"
	var pending := 0
	var response := ""
	var received: Dictionary = {}
	var stalled := false

	func availability() -> String:
		return state

	func begin(id: int, _instructions: String, input: String) -> void:
		pending = id
		received = JSON.parse_string(input)

	func take_result(id: int) -> String:
		if id != pending or stalled:
			return ""
		pending = 0
		return JSON.stringify({"content": response})

	func cancel(id: int) -> void:
		if id == pending:
			pending = 0

func _initialize() -> void:
	call_deferred("run")

func check(ok: bool, label: String) -> void:
	print(("PASS " if ok else "FAIL ") + label)
	if not ok:
		failures += 1

func run() -> void:
	var bridge := Bridge.new()
	Engine.register_singleton(Apple.SINGLETON, bridge)
	var game = Main.instantiate()
	root.add_child(game)
	await process_frame
	var profile: Dictionary = game.world.DEFAULT_PROFILE.duplicate(true)
	profile.cohabitants = 2
	profile.companion_names = ["美咲", "ユウタ"]
	game._start_new_game(profile)
	game._finish_intro()
	var world = game.world

	await game._on_command("美咲を呼ぶ")
	check(world.s.household_members[0].location == "寝室" and world.s.household_members[1].location == "居間", "calling moves only the named awake household member")
	check(game.log_entries[-1].begins_with("美咲「") and game.command_input.placeholder_text.contains("美咲と会話中"), "the resident answers and opens a dialogue")
	var before_food := float(world.s.food)
	await game._on_command("飲み水はどれくらいある？")
	check(game.log_entries[-1].contains("6.0リットル"), "offline reply uses real household stock")
	await game._on_command("それはあとどれくらい？")
	check(game.log_entries[-1].contains("6.0リットル"), "follow-up resolves its topic from recent turns")
	check(float(world.s.food) == before_food, "conversation alone does not consume food")
	await game._on_command("台所へ行く")
	check(game.location == "台所" and game.dialogue.partner == -1, "normal movement still works and ends dialogue on separation")

	bridge.state = "available"
	bridge.response = '{"reply":"今日は家で話していたいな。何か気がかり？"}'
	await game._on_command("美咲、今日はどうしたい？")
	check(game.log_entries[-1] == "美咲「今日は家で話していたいな。何か気がかり？」", "free dialogue uses the Apple bridge when available")
	check(bridge.received.recent_dialogue.size() == 3 and not bridge.received.has("world"), "AI receives recent turns and limited facts, without the world state")
	bridge.response = '{"actions":[{"kind":"command","command":"水を飲む"}]}'
	var used := float(world.s.water_used)
	await game._on_command("「水はある？」")
	check(game.log_entries[-1].contains("飲料水は残り") and float(world.s.water_used) == used, "invalid AI reply falls back and does not execute actions")
	bridge.stalled = true
	var before_minute := int(world.s.minute)
	game._cancel_action.call_deferred()
	await game._on_command("ちょっと聞いて")
	check(game.log_entries[-1] == "会話を中断した。" and world.s.minute == before_minute, "cancelled response changes neither time nor conversation memory")
	bridge.stalled = false
	await game._on_command("会話を終える")
	check(game.dialogue.partner == -1 and game.command_input.placeholder_text == "どうする？", "conversation can be ended explicitly")

	var history: Dictionary = game.dialogue.history.duplicate(true)
	check(game._save() == "保存した。", "dialogue history saves")
	game.dialogue.history.clear()
	check(game._load() == "保存データを読み込んだ。" and game.dialogue.history == history, "dialogue history survives a reload")

	world.s.minute = 59
	world.step(false)
	await game._on_command("美咲を呼ぶ")
	check(world.s.household_members[0].location == "屋外" and game.log_entries[-1].contains("外出中"), "an absent resident cannot answer")
	world.s.minute = 899
	world.step(false)
	await game._on_command("美咲を呼ぶ")
	check(world.s.household_members[0].activity == "睡眠" and game.log_entries[-1].contains("眠っている"), "a sleeping resident is not summoned")

	profile.companion_names = ["美咲", "美咲"]
	game._start_new_game(profile)
	game._finish_intro()
	await game._on_command("美咲を呼ぶ")
	check(game.dialogue.partner == -1 and game.log_entries[-1].contains("番号"), "duplicate names require disambiguation")
	await game._on_command("同居人2を呼ぶ")
	check(game.dialogue.partner == 1, "numbered addressing disambiguates identical names")
	await game._on_command("太郎に話しかける")
	check(game.log_entries[-1].contains("同居人はいない"), "unknown name never impersonates an existing resident")
	game.queue_free()
	await process_frame
	Engine.unregister_singleton(Apple.SINGLETON)
	quit(0 if failures == 0 else 1)
