extends SceneTree

const Main = preload("res://main.tscn")
const Plan = preload("res://scripts/action_plan.gd")
var failures := 0

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, description: String) -> void:
	print(("PASS " if condition else "FAIL ") + description)
	if not condition:
		failures += 1

func run() -> void:
	var game = Main.instantiate()
	root.add_child(game)
	await process_frame
	game._start_new_game(game.world.DEFAULT_PROFILE.duplicate(true))
	game._finish_intro()
	check(not game.apple_planner.available() and not game.ai_planner.configured(), "no AI backend")
	for phrase in [
		"キッチンで喉を潤して、それから報道をチェック",
		"台所で喉をうるおして、その後報道を確認する。",
		"台所で水を飲んでからニュースをチェックする",
	]:
		var plan := Plan.local(game, phrase)
		var commands: Array = plan.actions.map(func(action): return action.command)
		check(plan.ok and commands == ["台所へ行く", "水を飲む", "ニュースを見る"], phrase)

	var start_water := float(game.world.s.water_used)
	var start_time := int(game.world.s.minute)
	var start_picture := str(game.picture.texture.resource_path)
	game.command_input.text = "キッチンで喉を潤して、それから報道をチェック"
	game.send_button.pressed.emit()
	check(game.last_plan.ok and game.location == "台所", "reported input moves the player through the real send button")
	check(float(game.world.s.water_used) > start_water and int(game.world.s.minute) > start_time, "drinking and elapsed time change")
	check(str(game.picture.texture.resource_path) != start_picture and game.log_entries[-1].contains("情報源"), "location picture and news log update")

	var frozen := var_to_bytes(game.world.s)
	for phrase in [
		"キッチンで喉を潤して、それから報道をチェックできる？",
		"キッチンで喉を潤して、それから報道をチェックしない",
		"キッチンで喉を潤して、それから報道をチェック、ほかの家を見に行く",
	]:
		await game._on_command(phrase)
		check(not game.last_plan.ok and var_to_bytes(game.world.s) == frozen, "ambiguous or unsupported suffix leaves world unchanged: " + phrase)
	game.queue_free()
	await process_frame
	quit(0 if failures == 0 else 1)
