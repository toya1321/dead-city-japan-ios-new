extends Control
# Text-first UI. The world model advances ONLY when an action consumes time.
const WorldScript = preload("res://scripts/world.gd")
const IntroScript = preload("res://scripts/intro.gd")
const Navigation = preload("res://scripts/navigation.gd")
const Vitals = preload("res://scripts/vitals.gd")
const GestureScroll = preload("res://scripts/gesture_scroll.gd")
const TitleScreen = preload("res://scripts/title_screen.gd")
const SceneView = preload("res://scripts/scene_view.gd")
const Plan = preload("res://scripts/action_plan.gd")
const CareWait = preload("res://scripts/care_wait.gd")
const AIPlanner = preload("res://scripts/ai_planner.gd")
const ApplePlanner = preload("res://scripts/apple_planner.gd")
var ai_planner: Node
var apple_planner: Node
var apple_status: Label
var drawer: Control
var drawer_margin: MarginContainer
var drawer_title: Label
var settings_box: VBoxContainer
var settings_message: Label
var ai_fields: Dictionary = {}
var ai_enabled: CheckButton
var input_mode_label: Label
var progress_row: HBoxContainer
var progress_label: Label
var cancel_button: Button
var cancel_requested := false
var active_wait: Dictionary = {}
var last_plan: Dictionary = {}
const SAVE_PATH = "user://chronicle_v5.json"
const SAVE_VERSION = 5
const ROOM_LINKS = {"寝室":[],"居間":[],"台所":[],"廊下":[],"玄関":[],"共用廊下":[],"建物前":[],"屋外":[],"食品店":[],"金物店":[],"薬局":[]}
var title_screen: Control
var vitals_bars: Dictionary = {}
var vitals_values: Dictionary = {}
var warning_label: Label
var scene_view: Control
var selected_event: Dictionary = {}
var intro_active := false
var intro_page := 0
var intro_layer: Control
var intro_margin: MarginContainer
var intro_heading: Label
var intro_counter: Label
var intro_body: RichTextLabel
var intro_previous: Button
var intro_next: Button
var intro_message: Label
var advancing := false
var safe_margin: MarginContainer
var left_scroll: ScrollContainer
var world = WorldScript.new()
var location := "寝室"
var log_entries: Array[String] = []
var picture: TextureRect
var clock_label: Label
var status_label: Label
var story: RichTextLabel
var command_input: TextEdit
var backdrop: ColorRect
var scene_caption: Label
var sidebar_status: Label
var world_status: Label
var inventory_status: Label
var view_tabs: HFlowContainer
var main_layout: HBoxContainer
var left_panel: VBoxContainer
var scene_picture_min_height := 260.0
var header_row: HBoxContainer
var entry_row: HBoxContainer
var send_button: Button
var scene_panel: Control
var log_panel: Control
var log_follow_queued := false
var log_scroll: ScrollContainer
var right_panel: VBoxContainer
var content_column: VBoxContainer
var visual_focus := ""
var event_visual := ""
var known_events: Array[String] = []
var observed_news := "まだ確認していない"

func _ready() -> void:
	_build_ui()
	_refresh()
	_show_title()

func _panel(parent: Node, title: String) -> VBoxContainer:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _style(Color("#101b28"), Color("#405b76"), 9))
	parent.add_child(panel)
	var body := VBoxContainer.new()
	body.add_theme_constant_override("separation", 8)
	panel.add_child(body)
	var label := Label.new()
	label.text = title
	label.add_theme_font_size_override("font_size", 16)
	label.add_theme_color_override("font_color", Color("#d9e9fb"))
	body.add_child(label)
	return body

func _style(bg: Color, edge: Color, radius: int = 9) -> StyleBoxFlat:
	var st := StyleBoxFlat.new()
	st.bg_color = bg
	st.border_color = edge
	st.set_border_width_all(1)
	st.set_corner_radius_all(radius)
	st.content_margin_left = 12
	st.content_margin_right = 12
	st.content_margin_top = 10
	st.content_margin_bottom = 10
	return st

func _action_button(parent: Node, label: String, command: String) -> void:
	var btn := Button.new()
	btn.text = label
	btn.custom_minimum_size = Vector2(95, 42)
	btn.add_theme_stylebox_override("normal", _style(Color("#182b40"), Color("#557594")))
	btn.add_theme_stylebox_override("hover", _style(Color("#21466d"), Color("#81b8ed")))
	btn.pressed.connect(_on_command.bind(command))
	parent.add_child(btn)

func _build_ui() -> void:
	var theme_ui:=Theme.new()
	theme_ui.default_font=load("res://assets/NotoSansCJKjp-Regular.otf") as Font
	theme_ui.default_font_size=22
	theme=theme_ui
	var bg:=ColorRect.new();bg.color=Color("#080e15");bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);add_child(bg)
	safe_margin=MarginContainer.new();safe_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);add_child(safe_margin)
	var base:=VBoxContainer.new();base.add_theme_constant_override("separation",10);safe_margin.add_child(base)
	header_row=HBoxContainer.new();header_row.add_theme_constant_override("separation",12);base.add_child(header_row)
	var title:=Label.new();title.text="CHRONICLE  /  TEST 26";title.add_theme_font_size_override("font_size",18);header_row.add_child(title)
	clock_label=Label.new();clock_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL;clock_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;clock_label.add_theme_font_size_override("font_size",18);header_row.add_child(clock_label)
	for spec in [["持ち物","inventory"],["記録","records"],["保存","save"],["読込","load"],["設定","settings"]]:
		var b:=Button.new();b.text=spec[0];b.custom_minimum_size=Vector2(68,48);b.add_theme_font_size_override("font_size",18);b.pressed.connect(_open_tool.bind(spec[1]));header_row.add_child(b)
	main_layout=HBoxContainer.new();main_layout.size_flags_vertical=Control.SIZE_EXPAND_FILL;main_layout.add_theme_constant_override("separation",12);base.add_child(main_layout)
	content_column=VBoxContainer.new();content_column.size_flags_horizontal=Control.SIZE_EXPAND_FILL;content_column.size_flags_stretch_ratio=1.22;main_layout.add_child(content_column)
	var frame:=_panel(content_column,"SCENE  /  現在地")
	scene_panel=frame.get_parent();scene_panel.size_flags_vertical=Control.SIZE_EXPAND_FILL
	picture=TextureRect.new();picture.size_flags_vertical=Control.SIZE_EXPAND_FILL;picture.expand_mode=TextureRect.EXPAND_IGNORE_SIZE;picture.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_COVERED;picture.clip_contents=true;frame.add_child(picture)
	scene_view=SceneView.new();scene_view.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);scene_view.mouse_filter=Control.MOUSE_FILTER_IGNORE;picture.add_child(scene_view)
	scene_caption=Label.new();scene_caption.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;scene_caption.add_theme_font_size_override("font_size",15);frame.add_child(scene_caption)
	var vitals_row:=HBoxContainer.new();vitals_row.add_theme_constant_override("separation",10);content_column.add_child(vitals_row)
	for key in ["体力","満腹度","水分状態","休息状態"]:
		var column:=VBoxContainer.new();column.size_flags_horizontal=Control.SIZE_EXPAND_FILL;vitals_row.add_child(column)
		var label:=Label.new();label.text=key;label.add_theme_font_size_override("font_size",16);column.add_child(label)
		var value:=Label.new();value.add_theme_font_size_override("font_size",15);column.add_child(value);vitals_values[key]=value
		var bar:=ProgressBar.new();bar.custom_minimum_size.y=9;bar.show_percentage=false;bar.step=0.0;column.add_child(bar);vitals_bars[key]=bar
	warning_label=Label.new();warning_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;warning_label.add_theme_font_size_override("font_size",16);warning_label.add_theme_color_override("font_color",Color("#ffb594"));content_column.add_child(warning_label)
	right_panel=VBoxContainer.new();right_panel.size_flags_horizontal=Control.SIZE_EXPAND_FILL;right_panel.size_flags_stretch_ratio=1.0;main_layout.add_child(right_panel)
	var story_body:=_panel(right_panel,"CHRONICLE  /  状況・行動記録")
	log_panel=story_body.get_parent();log_panel.size_flags_vertical=Control.SIZE_EXPAND_FILL
	log_scroll=GestureScroll.new();log_scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL;log_scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;story_body.add_child(log_scroll)
	story=RichTextLabel.new();story.size_flags_horizontal=Control.SIZE_EXPAND_FILL;story.fit_content=true;story.scroll_active=false;story.bbcode_enabled=false;story.add_theme_font_size_override("normal_font_size",22);log_scroll.add_child(story)
	progress_row=HBoxContainer.new();progress_row.visible=false;base.add_child(progress_row)
	progress_label=Label.new();progress_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL;progress_label.add_theme_font_size_override("font_size",18);progress_row.add_child(progress_label)
	cancel_button=Button.new();cancel_button.text="中断";cancel_button.custom_minimum_size=Vector2(100,48);cancel_button.pressed.connect(_cancel_action);progress_row.add_child(cancel_button)
	entry_row=HBoxContainer.new();entry_row.add_theme_constant_override("separation",10);base.add_child(entry_row)
	command_input=TextEdit.new();command_input.placeholder_text="どうする？ 行動を自由に入力\n例：台所へ行って食事し、水を飲む";command_input.wrap_mode=TextEdit.LINE_WRAPPING_BOUNDARY;command_input.size_flags_horizontal=Control.SIZE_EXPAND_FILL;command_input.custom_minimum_size.y=96;entry_row.add_child(command_input)
	send_button=Button.new();send_button.text="実行";send_button.custom_minimum_size=Vector2(96,96);send_button.pressed.connect(func():_on_command(command_input.text));entry_row.add_child(send_button)
	input_mode_label=Label.new();input_mode_label.add_theme_font_size_override("font_size",14);input_mode_label.text="文章入力 / オフライン解析 · 長期待機は飲食・睡眠を含み、危険時に中断";base.add_child(input_mode_label)
	# On-demand information drawer; no action menu or movement buttons.
	drawer=Control.new();drawer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);drawer.visible=false;add_child(drawer)
	var shade:=ColorRect.new();shade.color=Color(0.01,0.025,0.04,0.95);shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);drawer.add_child(shade)
	drawer_margin=MarginContainer.new();drawer_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);drawer.add_child(drawer_margin)
	var column:=VBoxContainer.new();drawer_margin.add_child(column)
	var bar:=HBoxContainer.new();column.add_child(bar)
	drawer_title=Label.new();drawer_title.size_flags_horizontal=Control.SIZE_EXPAND_FILL;bar.add_child(drawer_title)
	var close:=Button.new();close.text="閉じる";close.custom_minimum_size=Vector2(120,60);close.pressed.connect(_close_drawer);bar.add_child(close)
	left_scroll=GestureScroll.new();left_scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL;left_scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;column.add_child(left_scroll)
	left_panel=VBoxContainer.new();left_panel.size_flags_horizontal=Control.SIZE_EXPAND_FILL;left_scroll.add_child(left_panel)
	inventory_status=Label.new();inventory_status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;left_panel.add_child(inventory_status)
	world_status=Label.new();world_status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;left_panel.add_child(world_status)
	settings_box=VBoxContainer.new();left_panel.add_child(settings_box)
	apple_status=Label.new()
	apple_status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	settings_box.add_child(apple_status)
	var info:=Label.new();info.text="外部AIの接続設定\n有効にすると入力文・現在地・体調・備蓄・確認済み情報を接続先へ送ります。\nキーは今回の起動中のみ保持し、セーブやソースには保存しません。\n利用料金は接続先の契約に従います。未設定でもオフライン解析で遊べます。";info.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;info.add_theme_font_size_override("font_size",18);settings_box.add_child(info)
	ai_enabled=CheckButton.new();ai_enabled.text="外部AIを使用する";ai_enabled.custom_minimum_size.y=54;settings_box.add_child(ai_enabled)
	for spec in [["接続先（HTTPS / Chat Completions形式）","endpoint"],["モデル名","model"],["APIキー（この起動中のみ）","key"]]:
		var l:=Label.new();l.text=spec[0];l.add_theme_font_size_override("font_size",18);settings_box.add_child(l)
		var edit:=LineEdit.new();edit.custom_minimum_size.y=58;edit.secret=spec[1]=="key";settings_box.add_child(edit);ai_fields[spec[1]]=edit
	var apply:=Button.new();apply.text="設定を適用";apply.custom_minimum_size.y=60;apply.pressed.connect(_apply_ai_settings);settings_box.add_child(apply)
	settings_message=Label.new();settings_message.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;settings_message.add_theme_font_size_override("font_size",18);settings_box.add_child(settings_message)
	ai_planner=AIPlanner.new();add_child(ai_planner)
	apple_planner=ApplePlanner.new();add_child(apple_planner)
	_refresh_input_mode()
	get_viewport().size_changed.connect(_update_layout)
	_update_layout()

func _open_tool(key: String) -> void:
	if intro_active or is_instance_valid(title_screen) or advancing:return
	if key in ["save","load"]:_utility(key);return
	drawer_title.text={"inventory":"体調・持ち物・備蓄","records":"確認した情報・記録","settings":"文章入力の設定"}.get(key,"")
	inventory_status.visible=key=="inventory"
	world_status.visible=key=="records"
	settings_box.visible=key=="settings"
	inventory_status.text=_inventory_text()+"\n\n"+_profile_text()+"\n"+_household_text()
	world_status.text="確認した報道\n"+observed_news+"\n\n"+_execute_command("生存記録")
	if key=="settings":
		_refresh_input_mode()
		ai_fields.endpoint.text=ai_planner.endpoint;ai_fields.model.text=ai_planner.model;ai_fields.key.text=ai_planner.api_key;ai_enabled.button_pressed=ai_planner.enabled
	drawer.show();log_scroll.interaction_enabled=false
	left_scroll.scroll_vertical=0
func _close_drawer() -> void:
	drawer.hide();log_scroll.interaction_enabled=true
func _apply_ai_settings() -> void:
	var endpoint:String=ai_fields.endpoint.text.strip_edges()
	if ai_enabled.button_pressed and (not endpoint.begins_with("https://") or ai_fields.model.text.strip_edges().is_empty() or ai_fields.key.text.strip_edges().is_empty()):
		settings_message.text="HTTPSの接続先・モデル名・APIキーを入力してください。";return
	ai_planner.endpoint=endpoint;ai_planner.model=ai_fields.model.text.strip_edges();ai_planner.api_key=ai_fields.key.text.strip_edges();ai_planner.enabled=ai_enabled.button_pressed
	settings_message.text="設定を適用しました。"
	_refresh_input_mode()
func _refresh_input_mode() -> void:
	apple_status.text=apple_planner.status()
	if ai_planner.configured():
		input_mode_label.text="文章入力 / 外部AI"
	elif apple_planner.available():
		input_mode_label.text="文章入力 / Appleの端末内AI"
	else:
		input_mode_label.text="文章入力 / オフライン解析"
func _cancel_action() -> void:
	cancel_requested=true
	ai_planner.cancel()
	apple_planner.cancel()
func _notification(what: int) -> void:
	if what==NOTIFICATION_APPLICATION_PAUSED and advancing:_cancel_action()
	if what==NOTIFICATION_APPLICATION_RESUMED and is_instance_valid(apple_planner):
		_refresh_input_mode()
func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and event.keycode==KEY_ENTER and event.ctrl_pressed:
		_on_command(command_input.text);get_viewport().set_input_as_handled()

func _process(_delta: float) -> void:
	# Keyboard and safe area can change without a viewport resize on iOS.
	if OS.has_feature("mobile"):
		_update_layout()

func _update_layout() -> void:
	if main_layout == null: return
	var vp := get_viewport_rect().size
	var scale_factor: float = vp.x / maxf(1.0, float(DisplayServer.window_get_size().x))
	var inset_left := 16
	var inset_right := 16
	var inset_top := 12
	var inset_bottom := 12
	if OS.has_feature("mobile"):
		var safe := DisplayServer.get_display_safe_area()
		var screen := DisplayServer.screen_get_size()
		inset_left = maxi(16, int(safe.position.x * scale_factor))
		inset_right = maxi(16, int((screen.x - safe.end.x) * scale_factor))
		inset_top = maxi(12, int(safe.position.y * scale_factor))
		inset_bottom = maxi(12, int((screen.y - safe.end.y) * scale_factor))
	if is_instance_valid(intro_margin):
		intro_margin.add_theme_constant_override("margin_left", inset_left + 16)
		intro_margin.add_theme_constant_override("margin_right", inset_right + 16)
		intro_margin.add_theme_constant_override("margin_top", inset_top + 12)
		intro_margin.add_theme_constant_override("margin_bottom", inset_bottom + 12)
	var keyboard: int = int(DisplayServer.virtual_keyboard_get_height() * scale_factor) if DisplayServer.has_feature(DisplayServer.FEATURE_VIRTUAL_KEYBOARD) else 0
	safe_margin.add_theme_constant_override("margin_left", inset_left)
	safe_margin.add_theme_constant_override("margin_right", inset_right)
	safe_margin.add_theme_constant_override("margin_top", inset_top)
	safe_margin.add_theme_constant_override("margin_bottom", maxi(inset_bottom, keyboard))
	_apply_responsive_layout(vp,keyboard)

func _apply_responsive_layout(vp: Vector2, keyboard: int) -> void:
	var available:float=vp.y-maxf(keyboard,safe_margin.get_theme_constant("margin_bottom"))-safe_margin.get_theme_constant("margin_top")
	var compact:bool=keyboard>0 or available<430
	scene_panel.visible=not compact
	content_column.visible=not compact
	header_row.visible=available>=290
	input_mode_label.visible=available>=240
	main_layout.visible=available>=170
	picture.custom_minimum_size.y=60
	log_scroll.custom_minimum_size.y=50
	command_input.custom_minimum_size.y=64 if compact else 96
	send_button.custom_minimum_size.y=64 if compact else 96
	for side in ["left","right"]:drawer_margin.add_theme_constant_override("margin_"+side,safe_margin.get_theme_constant("margin_"+side)+16)
	drawer_margin.add_theme_constant_override("margin_top",safe_margin.get_theme_constant("margin_top")+12)
	drawer_margin.add_theme_constant_override("margin_bottom",maxi(12,keyboard)+12)

func _apply_font(node: Node, font: Font) -> void:
	if node is Control:
		(node as Control).add_theme_font_override("font", font)
	for child in node.get_children():
		_apply_font(child, font)

func _show_title() -> void:
	left_scroll.interaction_enabled=false
	log_scroll.interaction_enabled=false
	if is_instance_valid(title_screen): return
	title_screen = TitleScreen.new()
	title_screen.save_exists = FileAccess.file_exists(SAVE_PATH)
	title_screen.new_game_requested.connect(_start_new_game)
	title_screen.continue_requested.connect(_continue_from_title)
	add_child(title_screen)

func _start_new_game(profile: Dictionary) -> void:
	if not world.configure(profile):
		if is_instance_valid(title_screen): title_screen.message.text = "主人公の設定を確認してください。"
		return
	if is_instance_valid(title_screen):
		title_screen.hide()
		title_screen.queue_free()
	title_screen = null
	location = "寝室"
	log_entries.clear()
	known_events.clear()
	observed_news = "まだ確認していない"
	visual_focus = ""
	event_visual = ""
	selected_event.clear()
	intro_page = 0
	_show_intro()

func _continue_from_title() -> void:
	var result := _load()
	if result != "保存データを読み込んだ。":
		title_screen.message.text = result
		return
	title_screen.hide()
	title_screen.queue_free()
	title_screen = null
	left_scroll.interaction_enabled=true
	log_scroll.interaction_enabled=true
	_append(result)
	_refresh()

func _intro_pages() -> Array:
	return IntroScript.pages(world.s.profile)

func _show_intro() -> void:
	left_scroll.interaction_enabled=false
	log_scroll.interaction_enabled=false
	_sync_player_position()
	_refresh()
	intro_active = true
	intro_layer = Control.new()
	intro_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	intro_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(intro_layer)
	var shade := ColorRect.new()
	shade.color = Color("#070d15")
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	intro_layer.add_child(shade)
	intro_margin = MarginContainer.new()
	intro_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	intro_layer.add_child(intro_margin)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _style(Color("#101b28"), Color("#405b76"), 12))
	intro_margin.add_child(panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 14)
	panel.add_child(column)
	var header := HBoxContainer.new()
	column.add_child(header)
	var logo := Label.new()
	logo.text = "DEAD CITY JAPAN  /  CHRONICLE"
	logo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	logo.add_theme_font_size_override("font_size", 22)
	header.add_child(logo)
	intro_counter = Label.new()
	header.add_child(intro_counter)
	intro_heading = Label.new()
	intro_heading.add_theme_font_size_override("font_size", 34)
	intro_heading.add_theme_color_override("font_color", Color("#dfc89b"))
	column.add_child(intro_heading)
	intro_body = RichTextLabel.new()
	intro_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	intro_body.custom_minimum_size.y = 80
	intro_body.bbcode_enabled = false
	intro_body.add_theme_font_size_override("normal_font_size", 28)
	column.add_child(intro_body)
	intro_message = Label.new()
	intro_message.text = "読み進めている間、ゲーム内の時間は進みません。"
	intro_message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	intro_message.add_theme_font_size_override("font_size", 18)
	column.add_child(intro_message)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	column.add_child(row)
	intro_previous = Button.new()
	intro_previous.text = "戻る"
	intro_previous.custom_minimum_size = Vector2(130, 80)
	intro_previous.pressed.connect(_intro_turn.bind(-1))
	row.add_child(intro_previous)
	var skip := Button.new()
	skip.text = "導入を閉じる"
	skip.custom_minimum_size = Vector2(190, 80)
	skip.pressed.connect(_finish_intro)
	row.add_child(skip)
	if FileAccess.file_exists(SAVE_PATH):
		var resume := Button.new()
		resume.text = "続きから"
		resume.custom_minimum_size = Vector2(150, 80)
		resume.pressed.connect(_resume_from_intro)
		row.add_child(resume)
	intro_next = Button.new()
	intro_next.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	intro_next.custom_minimum_size = Vector2(250, 80)
	intro_next.pressed.connect(_intro_turn.bind(1))
	row.add_child(intro_next)
	_render_intro_page()
	_update_layout()

func _render_intro_page() -> void:
	intro_heading.text = str(_intro_pages()[intro_page].title)
	intro_counter.text = "PROLOGUE  %d / %d" % [intro_page + 1, _intro_pages().size()]
	intro_body.text = str(_intro_pages()[intro_page].body)
	intro_body.scroll_to_line(0)
	intro_previous.disabled = intro_page == 0
	intro_next.text = "この一日を始める" if intro_page == _intro_pages().size() - 1 else "次へ"

func _intro_turn(direction: int) -> void:
	if not intro_active: return
	if direction > 0 and intro_page == _intro_pages().size() - 1:
		_finish_intro()
		return
	intro_page = clampi(intro_page + direction, 0, _intro_pages().size() - 1)
	_render_intro_page()

func _finish_intro() -> void:
	if not intro_active: return
	for page in _intro_pages():
		_append(str(page.title) + "\n" + str(page.body))
	_append("何をする？ 下の入力欄に行動を書ける（例：窓を見る／ニュースを見る／居間へ移動）。")
	_close_intro_layer()
	_refresh()

func _close_intro_layer() -> void:
	left_scroll.interaction_enabled=true
	log_scroll.interaction_enabled=true
	intro_active = false
	if is_instance_valid(intro_layer):
		intro_layer.hide()
		intro_layer.queue_free()
	intro_layer = null
	intro_margin = null

func _resume_from_intro() -> void:
	if not intro_active: return
	var response := _load()
	if response == "保存データを読み込んだ。":
		_close_intro_layer()
		_append(response)
		_refresh()
	else:
		intro_message.text = response

func _append(line: String) -> void:
	# Never produce a save that our own bounded loader will reject.
	for offset in range(0,maxi(1,line.length()),2000):
		log_entries.append(line.substr(offset,2000))
	while log_entries.size()>100:log_entries.pop_front()
	if story!=null:
		story.text="\n\n".join(log_entries)
		call_deferred("_scroll_log_to_end")
func _scroll_log_to_end() -> void:
	if log_follow_queued or not is_inside_tree():return
	log_follow_queued=true
	# RichTextLabel fit_content and ScrollContainer bounds settle on later
	# layout passes. Following before that pass leaves the new entry offscreen.
	await get_tree().process_frame
	await get_tree().process_frame
	if is_instance_valid(log_scroll):log_scroll.scroll_vertical=int(log_scroll.get_v_scroll_bar().max_value)
	log_follow_queued=false

func _refresh() -> void:
	clock_label.text = "%s  |  %s" % [world.clock(), location]
	var normalized := Vitals.values(world.s)
	for key in normalized:
		var value: float = normalized[key]
		vitals_bars[key].value = value
		vitals_values[key].text = "%.0f · %s" % [value,Vitals.description(value)]
		var style := StyleBoxFlat.new()
		style.bg_color = Color("#c87559") if value <= 15 else (Color("#bda05d") if value <= 40 else Color("#689b91"))
		vitals_bars[key].add_theme_stylebox_override("fill",style)
	warning_label.text = Vitals.warning(world.s)
	warning_label.visible = not warning_label.text.is_empty()
	inventory_status.text = "食料 %.1f人日\n飲料水 %.1f L\n雨水 %.1f L\n現金 %d円\n銀行 %d円\n住居耐久 %.0f / 100" % [float(world.s.food),float(world.s.water),float(world.s.rain_water),int(world.s.cash),int(world.s.bank),float(world.s.longplay.shelter_integrity)]
	world_status.text = "%s / %s\n%s\n\n確認した報道\n%s" % [str(world.s.profile.name),str(world.s.profile.housing),str(world.s.profile.address),observed_news]
	world_status.add_theme_font_size_override("font_size",18)
	var shop_id: String = {"食品店":"grocer","金物店":"hardware","薬局":"pharmacy"}.get(location,"")
	var visible_count := 0
	if not Navigation.indoor(location) or visual_focus == "window": visible_count = world.visible_residents().size()
	scene_view.update_view(location,world.hour_of_day(),str(world.s.weather),world.has_home_power() if Navigation.indoor(location) else bool(world.s.grid_online),world.can_trade(shop_id) if not shop_id.is_empty() else true,visible_count,visual_focus)
	picture.texture = scene_view.location_texture(location,"apartment" if world.s.profile.housing=="集合住宅" and location=="建物前" else "")
	scene_caption.text = _scene_caption()

func _on_command(raw: String) -> void:
	if intro_active or is_instance_valid(title_screen) or drawer.visible or advancing:return
	var cmd:=raw.strip_edges()
	if cmd.is_empty():return
	if cmd.length()>1200:_append("文章は1200文字以内で入力してください。何も実行していません。");return
	command_input.clear()
	command_input.release_focus()
	DisplayServer.virtual_keyboard_hide()
	_append("▶ "+cmd)
	cancel_requested=false
	last_plan=Plan.local(self,cmd)
	if not last_plan.ok:
		if ai_planner.configured():
			_set_busy(true,"外部AIが文章を解釈しています…")
			last_plan=await ai_planner.plan(self,cmd)
			_set_busy(false)
		elif apple_planner.available():
			_set_busy(true,"端末内AIが文章を解釈しています…")
			last_plan=await apple_planner.plan(self,cmd)
			_set_busy(false)
			if last_plan.ok:
				_append("端末内AIで解釈しました。")
			elif not cancel_requested:
				_append("端末内AIで解釈できませんでした。")
		elif OS.get_name() == "iOS":
			_append(apple_planner.status())
	if cancel_requested:
		_append("文章の解釈を中断しました。何も実行していません。")
		return
	if not last_plan.ok:_append(str(last_plan.clarification));return
	await _run_plan(last_plan)

func _set_busy(value: bool, message: String = "") -> void:
	advancing=value
	command_input.editable=not value
	send_button.disabled=value
	progress_row.visible=value
	progress_label.text=message

func _run_plan(plan: Dictionary) -> void:
	var validated:Dictionary=Plan.validate(self,plan)
	if not validated.ok:_append(str(validated.clarification));return
	var long_running:=false
	for action in validated.actions:
		if action.kind=="wait" and int(action.minutes)>60:long_running=true
	if long_running:_set_busy(true,"日常生活を進めています…")
	var index:=0
	for action in validated.actions:
		if cancel_requested:_append("指示を中断しました。完了した行動と経過した時間は維持しています。");break
		index+=1
		if action.kind=="wait":
			active_wait=CareWait.begin(self,int(action.minutes),bool(action.care))
			if not active_wait.ok:_append(str(active_wait.reason));break
			while not active_wait.stopped:
				if cancel_requested:active_wait.reason="操作またはアプリ中断により待機を中断しました。";active_wait.stopped=true
				else:CareWait.tick(self,active_wait,30)
				if long_running:
					progress_label.text="%d / %d分 · 食事%d回 / 水分補給%d回"%[int(active_wait.elapsed),int(active_wait.target),int(active_wait.meals),int(active_wait.drinks)]
					_refresh()
					await get_tree().process_frame
			_append(CareWait.summary(active_wait))
			if not str(active_wait.reason).is_empty():break
		else:
			var before:PackedByteArray=var_to_bytes(world.s)
			var old_location:=location
			var command := str(action.command)
			var already_there: bool = world.s.health > 0 and Navigation.destination(command) == old_location
			var result:=_interpret(command)
			_append(("%d. "%index if validated.actions.size()>1 else "")+result)
			var unchanged:=before==var_to_bytes(world.s) and location==old_location
			if unchanged and not already_there and command not in Plan.QUERIES and command not in ["保存","読込"]:
				if index<validated.actions.size():_append("この行動が成立しなかったため、後続の指示は実行していません。")
				break
		_refresh()
	_set_busy(false)
	_refresh()

# A world event is not player knowledge until it is witnessed or reported.
func _event_id(e: Dictionary) -> String:
	return str(e.id) if e.has("id") else "%d:%s" % [int(e.minute), str(e.kind)]

func _remember_event(e: Dictionary) -> void:
	var id := _event_id(e)
	if not known_events.has(id):
		known_events.append(id)
	if known_events.size() > 240:
		known_events.pop_front()

func _parse_wait_minutes(cmd: String) -> int:
	# Return -1 for unsupported input, -2 for a supported but oversized wait.
	# Anchoring prevents e.g. "水を飲んで30分待つ" from silently waiting.
	var pattern := RegEx.new()
	pattern.compile("^(?:時間を)?([0-9]{1,4})\\s*(分|時間|日)(?:だけ)?(?:待つ|待機する|経過させる|過ごす|進める)$")
	var found := pattern.search(cmd)
	if found == null:
		return -1
	var amount: int = int(found.get_string(1))
	var unit: String = found.get_string(2)
	var minutes: int = amount * (1 if unit == "分" else (60 if unit == "時間" else 1440))
	if minutes <= 0 or minutes > 1440:
		return -2
	return minutes

# Full-command recognition precedes every mutation. Unknown subjects,
# questions, alternatives and compound instructions cannot fall through to
# substring-based execution. This is a bounded Japanese grammar, not an LLM.
func _canonical_command(raw: String) -> String:
	var cmd := raw.strip_edges().trim_suffix("。").replace("　", " ")
	for ending in ["してください", "して下さい", "してほしい"]:
		if cmd.ends_with(ending): cmd = cmd.trim_suffix(ending) + "する"
	var aliases := {
		"窓を見る":"窓から外を見る", "窓の外を見る":"窓から外を見る",
		"外の様子を見る":"窓から外を見る", "ニュースを確認する":"ニュースを見る",
		"テレビを見る":"ニュースを見る", "ご飯を食べる":"食事する",
		"食事をする":"食事する", "食べる":"食事する", "水を飲みたい":"水を飲む",
		"眠る":"寝る", "睡眠を取る":"寝る", "休憩する":"1時間休息",
		"休憩":"1時間休息", "持ち物を確認する":"持ち物", "状態を確認する":"状態",
		"セーブ":"保存", "セーブする":"保存", "保存する":"保存",
		"ロード":"読込", "ロードする":"読込", "読み込む":"読込",
		"NPCを観察する":"近くの住民を観察", "住民を観察する":"近くの住民を観察",
		"家に入る":"家に戻る", "周りを見る":"周囲を見る"
	}
	if aliases.has(cmd): return aliases[cmd]
	var exact := ["周囲を見る", "窓から外を見る", "ニュースを見る", "生存記録", "日誌", "世界の出来事", "出来事の記録", "配送状況", "注文履歴", "1時間休息", "寝る", "食事する", "水を飲む", "持ち物", "状態", "保存", "読込", "近くの住民を観察", "住民を観察", "NPCを観察", "玄関を補強", "住居を修繕", "家を修理", "浄水する", "プランターを作る", "種を植える", "水やり", "水をやる", "収穫", "収穫する", "物資を探索する", "街を観察する", "外に出る", "家に戻る", "鍵を開ける", "鍵を閉める", "施錠する", "傷を手当てする", "買い物する"]
	if cmd in exact: return cmd
	if _parse_wait_minutes(cmd) != -1: return cmd
	var movement := RegEx.new()
	movement.compile("^(寝室|居間|リビング|台所|キッチン|玄関)(へ|に)(移動|移動する|行く|戻る)$")
	var moved := movement.search(cmd)
	if moved != null: return moved.get_string(1) + "へ移動"
	var order := RegEx.new()
	order.compile("^(?:通販で)?(水|飲料水|食料)を([0-9]+)(?:個|箱|セット)注文(?:する)?$")
	var found := order.search(cmd)
	if found != null:
		var quantity: String = found.get_string(2)
		if quantity.length() > 2 or int(quantity) < 1 or int(quantity) > 12: return "invalid_order"
		return "通販で%sを%d個注文" % [found.get_string(1), int(quantity)]
	return ""

func _interpret(raw: String) -> String:
	var clean := raw.strip_edges().trim_suffix("。")
	var target := Navigation.destination(clean)
	if not target.is_empty(): return _move_to(target)
	if clean in ["鍵を開ける","玄関の鍵を開ける","鍵を閉める","玄関の鍵を閉める","施錠する","玄関の扉を開ける","扉を閉める"]: return _door_action(clean)
	if clean in ["玄関の補強を外す","補強を外す"]:
		if location not in ["玄関","共用廊下","建物前"]:return "玄関のそばで作業してください。"
		if location!="玄関" and not world.s.profile.has_key:return "外から取り外すには自宅の鍵が必要です。"
		return world.action("unfortify")
	if clean == "主人公情報": return _profile_text()
	if clean == "同居人の様子を見る": return _household_text()
	if clean in ["在宅で仕事をする","勉強する"]:
		if not Navigation.indoor(location): return "自宅で作業する必要がある。"
		if world.s.health<=0:return "死亡している。"
		return world.work_at_home()
	if clean in ["ニュースを見る","テレビを見る","SNSを見る","スマホでニュースを見る","ラジオを聞く"]: return _read_news(clean)
	if clean in ["店の在庫を見る","買い物する"]:return _shop_inventory()
	if clean == "住居を点検":return _observe("inspect")
	var purchase := RegEx.new()
	purchase.compile("^(?:(食品店|金物店|薬局)で)?(食料|水|飲料水|木材|部品|種|包帯|浄水器|ソーラーパネル|蓄電池)を(?:([0-9]{1,2})(?:個|箱|セット))?(?:買う|購入する)$")
	var bought := purchase.search(clean)
	if bought != null:
		var id: String = {"食品店":"grocer","金物店":"hardware","薬局":"pharmacy"}.get(location,"")
		if id.is_empty():return "購入するには店頭へ移動してください。"
		if not bought.get_string(1).is_empty() and bought.get_string(1)!=location:return "指定した店の前にいない。"
		var item: String = {"食料":"food","水":"water","飲料水":"water","木材":"wood","部品":"parts","種":"seeds","包帯":"bandage","浄水器":"filter","ソーラーパネル":"solar","蓄電池":"battery"}[bought.get_string(2)]
		var amount: int = 1 if bought.get_string(3).is_empty() else int(bought.get_string(3))
		return world.buy_quantity(id,item,amount)
	var cmd := _canonical_command(raw)
	if cmd == "invalid_order": return "注文数は1～12個で指定する。何も注文していない。"
	if not cmd.is_empty() and cmd!=clean:return _interpret(cmd)
	if cmd.is_empty():
		return "その文章はまだ正確に処理できない。行動・時間・物資は変更していない。一つの行動を具体的に入力して（例：窓を見る／30分待つ）。"
	var before_minute: int = int(world.s.minute)
	var before_location := location
	var response := _execute_command(cmd)
	# Illustration focus changes only after a recognized, successful action.
	if int(world.s.minute) != before_minute or location != before_location:
		if cmd.contains("窓") or cmd == "街を観察する":
			visual_focus = "window"
			event_visual = ""
		elif cmd == "ニュースを見る":
			if visual_focus != "event": visual_focus = "news"
		else:
			if not (cmd == "玄関を補強" and response.begins_with("玄関を補強")):
				visual_focus = ""
				event_visual = ""
	return response

func _execute_command(cmd: String) -> String:
	# The deterministic parser handles ONE action at a time. Never execute
	# the first action of a compound instruction and silently ignore the rest.
	var normalized: String = cmd.strip_edges().trim_suffix("。")
	for separator in ["。", "、", "それから", "そのあと", "続けて", "してから"]:
		if normalized.contains(separator):
			return "複数の行動は一つずつ入力して。今回は何も実行していない。"
	# Safety-first: do not execute an action mentioned in a negative instruction.
	# This is not a complete Japanese-language parser; ambiguous instructions are rejected.
	var negated := ["しない", "しません", "しないで", "するな", "やめて", "待たない", "寝ない", "食べない", "飲まない", "開けない", "閉めない", "注文しない", "買わない", "移動しない", "行かない", "経過させない", "過ごさない"]
	for negative in negated:
		if cmd.contains(negative):
			return "否定の指示を確認した。行動も時間経過も実行していない。"
	if float(world.s.health) <= 0.0 and not (cmd.contains("ロード") or cmd.contains("読込") or cmd.contains("保存") or cmd.contains("セーブ") or cmd.contains("状態")):
		return "死亡している。保存済みの記録を読み込める。"
	if cmd.contains("近くの住民") or cmd.contains("住民を観察") or cmd.contains("NPCを観察"):
		if Navigation.indoor(location): return "住民の様子を直接観察するには屋外に出る必要がある。"
		var visible: Array = world.visible_residents()
		if visible.is_empty(): return "見える範囲に人影はない。"
		var lines: Array[String] = []
		for person in visible.slice(0,8):
			lines.append("住民#%d %s：%s（%s）" % [int(person.id),str(person.role),str({"home":"在宅","work":"仕事・通学","shopping":"買い物","searching":"物資を探している","shelter":"自宅へ避難","rest":"休養","clinic":"受診","park":"散歩","boundary":"地区外へ移動","farm":"農作業"}.get(str(person.activity),"移動中")),str({"healthy":"目立つ異変なし","symptomatic":"体調が悪そう","injured":"けがをしている","unknown":"不明"}.get(str(person.condition),str(person.condition)))])
		return "\n".join(lines)
	if cmd.contains("持ち物"):return _inventory_text()
	if cmd.contains("状態"):
		return _status_text()
	if cmd.contains("セーブ") or cmd.contains("保存"):
		return _save()
	if cmd.contains("ロード") or cmd.contains("読込"):
		return _load()
	if cmd.contains("生存記録") or cmd.contains("日誌"):
		var journal: Array = world.s.longplay.journal
		var result: Array[String] = []
		for entry in journal.slice(maxi(0,journal.size()-12)):
			result.append("%d日目：%s" % [int(entry.minute/1440),str(entry.text)])
		return "\n".join(result) if not result.is_empty() else "記録はまだない。"
	if cmd.contains("世界の出来事") or cmd.contains("出来事の記録"):
		var items: Array = []
		for e in world.recent_events(240):
			if known_events.has(_event_id(e)):
				items.append(e)
			if items.size() >= 12: break
		if items.is_empty(): return "まだ自分で確認した出来事はない。ニュースや窓から情報を得られる。"
		var lines: Array[String] = []
		for e in items:
			lines.append("%d日目：%s" % [int(e.minute)/1440,str(e.text)])
		event_visual = str(items[0].visual)
		visual_focus = "event"
		return "\n".join(lines)
	if cmd.contains("玄関を補強") or cmd.contains("バリケード"):
		if location != "玄関": return "玄関で作業する必要がある。"
		var response := world.action("fortify")
		if response.begins_with("玄関を補強"):
			event_visual = "shelter"
			visual_focus = "event"
		return response
	if cmd.contains("包帯") or cmd.contains("手当て"):
		var response := world.action("bandage")
		if response.begins_with("傷を手当て"):
			world.advance(10)
		return response
	if cmd.contains("配送状況") or cmd.contains("注文履歴"):
		return world.order_status()
	if cmd.contains("通販") or cmd.contains("注文"):
		if location not in ["寝室", "居間"]: return "注文端末は寝室か居間で操作する。"
		var item := "water" if (cmd.contains("水") or cmd.contains("飲料")) else ("food" if cmd.contains("食料") else "")
		if item.is_empty(): return "注文する物資を指定して。例：通販で水を3個注文"
		var amount := 1
		var pattern := RegEx.new()
		pattern.compile("([0-9]{1,2})\\s*(個|箱|セット)")
		var matched := pattern.search(cmd)
		if matched != null: amount = int(matched.get_string(1))
		return world.place_order(item, amount)
	if cmd.contains("買い物") or cmd.contains("購入"):
		return "店頭購入には店の位置まで移動する必要がある。現在の文章版では商店への移動は未実装。"
	if cmd.contains("1時間休息") or cmd.contains("休憩"):
		return world.longplay_action("rest")
	if cmd.contains("住居を修繕") or cmd.contains("家を修理"):
		if location != "玄関" and location != "台所": return "住居の修繕は玄関か台所から行う。"
		return world.longplay_action("maintain")
	if cmd.contains("浄水"):
		if location != "台所": return "台所で浄水設備を操作する。"
		return world.longplay_action("purify")
	if cmd.contains("物資を探索") or cmd.contains("探索する"):
		if location != "屋外": return "探索には屋外に出る必要がある。"
		return world.longplay_action("scavenge")
	if cmd.contains("プランター") and (cmd.contains("作") or cmd.contains("製作")):
		if location != "台所": return "台所で製作する。"
		return world.action("craft")
	if cmd.contains("種を植") or cmd.contains("植え付"):
		if location != "台所": return "台所で植え付ける。"
		return world.action("plant")
	if cmd.contains("水やり") or cmd.contains("水をやる"):
		if location != "台所": return "台所で水やりをする。"
		var result: String = world.action("tend")
		if result.begins_with("最初の鉢"): world.advance(10)
		return result
	if cmd.contains("収穫"):
		if location != "台所": return "台所で収穫する。"
		var result: String = world.action("harvest")
		if result.begins_with("収穫した"): world.advance(30)
		return result
	# Only a complete, unambiguous wait command advances time. A number in
	# a question or in another action must never trigger a partial action.
	var wait_minutes: int = _parse_wait_minutes(normalized)
	if wait_minutes > 0:
		var elapsed: int = world.advance_safe(wait_minutes)
		return "%d分が経過した。" % elapsed
	if wait_minutes == -2:
		return "一度に進められるのは24時間まで。期間を短く指定して。"
	if cmd.contains("寝る") or cmd.contains("睡眠"):
		if location != "寝室":
			return "寝室に移動する必要がある。"
		var elapsed: int = world.advance_safe(480, true)
		return "%d分眠った。目が覚めると、外の様子も変わっているかもしれない。" % elapsed
	if cmd.contains("食事") or cmd.contains("食べ"):
		if location != "台所":
			return "食事をするには台所へ行こう。"
		if not world.can_eat():
			return "今は食事が不要、または食料が足りない。"
		if not world.eat(): return "食事ができなかった。"
		world.advance(15)
		return "食事を取った。"
	if cmd.contains("水を飲") or cmd.contains("飲み水"):
		if not world.can_drink():
			return "今は水分補給が不要、または飲める水がない。"
		if not world.drink(): return "水を飲めなかった。"
		world.advance(2)
		return "水を飲んだ。"
	if cmd.contains("ニュース") or cmd.contains("テレビ"):
		if not bool(world.s.grid_online): return "停電でテレビを使えない。携帯通信・ラジオ受信の文章操作は未実装。"
		world.advance(5)
		observed_news = str(world.s.last_news)
		var events := world.recent_events(8)
		var headlines: Array[String] = [str(world.s.last_news)]
		var report_visual := ""
		for e in events:
			if str(e.scope) == "regional":
				_remember_event(e)
				headlines.append(str(e.text))
				if report_visual.is_empty(): report_visual = str(e.visual)
			if headlines.size() >= 4: break
		if not report_visual.is_empty():
			event_visual = report_visual
			visual_focus = "event"
		return "\n".join(headlines)
	if cmd.contains("窓") or cmd.contains("街を観察"):
		if location not in ["寝室","居間","台所","屋外","建物前","共用廊下"]:return "ここからは窓の外を観察できない。"
		world.advance_safe(2)
		visual_focus="window" if Navigation.indoor(location) else ""
		var observed:=_observe("sight")
		return "通りを観察した。天候：%s。\n%s"%[_weather_text(),observed]

	if cmd.contains("鍵を閉") or cmd.contains("施錠"):
		if location != "玄関": return "玄関にいない。"
		world.s.door_locked = true
		world.s.door_open = false
		world.advance(1)
		return "玄関を閉めて施錠した。"
	if cmd.contains("鍵を開"):
		if location != "玄関":
			return "玄関にいない。"
		world.s.door_locked = false
		world.advance(1)
		return "玄関の鍵を開けた。"
	if cmd.contains("外に出"):
		if location != "玄関":
			return "外に出るには玄関へ移動しよう。"
		if world.s.door_locked:
			return "玄関には鍵がかかっている。"
		location = "屋外"
		visual_focus = ""
		_sync_player_position()
		world.s.door_open = true
		world.advance(1)
		return "家の前に出た。道路には日常の生活音がある。"
	if cmd.contains("家に戻") or cmd.contains("家に入"):
		if location != "屋外":
			return "今は家の外にいない。"
		if world.s.door_locked:
			return "扉が施錠されていて、入れない。"
		location = "玄関"
		visual_focus = ""
		world.s.door_open = false
		_sync_player_position()
		world.advance(1)
		return "玄関に戻った。"
	var destinations := {"寝室":"寝室", "居間":"居間", "リビング":"居間", "台所":"台所", "キッチン":"台所", "玄関":"玄関"}
	for key in destinations:
		if cmd.contains(key) and (cmd.contains("移動") or cmd.contains("行く") or cmd.contains("戻る")):
			if location == "屋外":
				return "まず家に戻る必要がある。"
			var dest: String = destinations[key]
			if dest == location: return "すでに%sにいる。" % location
			if not ROOM_LINKS[location].has(dest):
				return "ここから%sへ直接は行けない。隣の部屋を経由する必要がある。" % dest
			location = dest
			visual_focus = ""
			_sync_player_position()
			world.advance(1)
			return "%sへ移動した。" % location
	if cmd.contains("周囲") or cmd.contains("見回"):
		world.advance(1)
		return _look()
	return "その行動はまだ処理できない。世界の状態や時間は変更していない。"


# Illustration choice is a pure function of current location, observation and
# independently simulated world state. Viewing never changes the outbreak.
func _visual_phase() -> String:
	var society := str(world.s.society)
	var day := int(world.s.minute) / 1440
	if society == "normal" and int(world.s.regional_cases) < 10:
		return "normal"
	if day >= 365 and society != "normal":
		return "overgrown"
	if society == "normal" or society == "alert" or int(world.s.regional_cases) < 200:
		return "alert"
	return "collapse"

func _scene_path() -> String:
	var photo:String="apartment" if location=="建物前" and world.s.profile.housing=="集合住宅" else str(SceneView.PHOTO_NAMES.get(location,""))
	return "res://assets/photos/"+photo+".jpg"
func _weather_text() -> String:
	return str({"clear":"晴れ","cloudy":"くもり","rain":"雨","snow":"雪"}.get(world.s.weather,"不明"))
func _scene_caption() -> String:
	var shop:String={"食品店":"grocer","金物店":"hardware","薬局":"pharmacy"}.get(location,"")
	return "%s / %s / %s%s\n生成した実写風の場所イメージ。人物・在庫・出来事は記録を参照。"%[location,_weather_text(),"夜" if world.hour_of_day()<6 or world.hour_of_day()>=18 else "昼",(" / 営業中" if world.can_trade(shop) else " / 休業中") if not shop.is_empty() else ""]
func _sync_player_position() -> void:
	world.s.player_pos=Navigation.position(location)
func _look() -> String:
	var neighbours: Array = Navigation.graph(str(world.s.profile.housing)).get(location,[])
	var detail := "%s。%sへ移動できる。"%[location,"・".join(neighbours)]
	if location=="玄関":detail+="玄関は%s。"%("施錠中" if world.s.door_locked else "解錠済み")
	if location in ["食品店","金物店","薬局"]:detail+="店頭にいる。"+_shop_inventory()
	return detail+"\n"+_observe("sight")

func _move_to(destination: String) -> String:
	if world.s.health<=0:return "死亡している。保存した記録を読み込める。"
	var path := Navigation.route(location,destination,str(world.s.profile.housing))
	if path.is_empty():return "この住居からその場所へ移動する経路がない。"
	if path.size()==1:return "すでに%sにいる。"%destination
	# Validate every door before moving. A failed journey never walks partway.
	for index in range(1,path.size()):
		var from_place: String=path[index-1]
		var to_place: String=path[index]
		if ((from_place=="玄関" and not Navigation.indoor(to_place)) or (to_place=="玄関" and not Navigation.indoor(from_place))) and int(world.s.barricade)>0:return "玄関の補強が通路を塞いでいる。玄関のそばで「玄関の補強を外す」と通れる。"
		if from_place=="玄関" and not Navigation.indoor(to_place) and bool(world.s.door_locked):return "玄関には鍵がかかっている。まず鍵を開ける必要がある。"
		if to_place=="玄関" and not Navigation.indoor(from_place) and bool(world.s.door_locked) and not bool(world.s.profile.has_key):return "玄関が施錠されており、鍵を持っていない。"
	var started:=int(world.s.minute)
	for index in range(1,path.size()):
		var previous:=location
		location=path[index]
		_sync_player_position()
		var entry_locked:bool=bool(world.s.door_locked) and location=="玄関" and not Navigation.indoor(previous)
		var crossing_door:bool=(previous=="玄関" and not Navigation.indoor(location)) or (location=="玄関" and not Navigation.indoor(previous))
		if crossing_door:
			world.s.door_locked=false
			world.s.door_open=true
		var elapsed:int=world.advance_safe(Navigation.duration(previous,location)+(1 if entry_locked else 0))
		if crossing_door:world.s.door_open=false
		if entry_locked:world.s.door_locked=true
		if elapsed<=0 or world.s.health<=0:break
	visual_focus=""
	event_visual=""
	selected_event.clear()
	return "%sへ移動した（%d分 / %s）。\n%s"%[location,int(world.s.minute)-started," → ".join(path),_look()]
func _door_action(command: String) -> String:
	if world.s.health<=0:return "死亡している。"
	if location not in ["玄関","共用廊下","建物前"]:return "玄関のそばで操作する必要がある。"
	if command=="扉を閉める":
		world.s.door_open=false
		world.advance_safe(1)
		return "玄関の扉を閉めた。"
	if command.contains("閉め") or command=="施錠する":
		if location!="玄関" and not world.s.profile.has_key:return "玄関の鍵を持っていない。"
		world.s.door_open=false
		world.s.door_locked=true
		world.advance_safe(1)
		return "玄関を閉めて施錠した。"
	if not world.s.profile.has_key:return "玄関の鍵を持っていない。"
	world.s.door_locked=false
	world.s.door_open=command=="玄関の扉を開ける"
	world.advance_safe(1)
	return "玄関の扉を開けた。" if world.s.door_open else "玄関の鍵を開けた。"
func _shop_inventory() -> String:
	var id: String={"食品店":"grocer","金物店":"hardware","薬局":"pharmacy"}.get(location,"")
	if id.is_empty():return "店の前へ移動すると、営業状態と在庫を確認できる。"
	var lines: Array[String]=["営業中" if world.can_trade(id) else "休業中"]
	for item in world.CATALOG:
		if str(world.CATALOG[item].shop)==id:lines.append("%s：在庫 %.1f / %d円"%[world.CATALOG[item].name,float(world.s.shops[id].stock.get(item,0)),int(world.CATALOG[item].price)])
	return "\n".join(lines)
func _profile_text() -> String:
	var profile:Dictionary=world.s.profile
	return "%s / %d歳\n%s / %s\n職業：%s / 同居人：%d人"%[profile.name,int(profile.age),profile.address,profile.housing,profile.job,int(profile.cohabitants)]
func _household_text() -> String:
	if world.s.household_members.is_empty():return "同居人はいない。"
	if not Navigation.indoor(location):return "自宅で様子を確認できる。"
	var lines: Array[String]=[]
	for person in world.s.household_members:
		lines.append("%s：%s / %s"%[person.name,person.location,"応答がない" if float(person.health)<=0 else person.activity])
	return "\n".join(lines)
func _observe(channel: String) -> String:
	var found: Array=world.Events.observe(world,channel,location)
	var lines: Array[String]=[]
	for event in found:
		if known_events.has(_event_id(event)):continue
		_remember_event(event)
		selected_event=event
		lines.append(("【未確認情報】" if not bool(event.verified) else "")+str(event.text))
		if lines.size()>=4:break
	return "\n".join(lines) if not lines.is_empty() else "新しく確認できた出来事はない。"
func _read_news(command: String) -> String:
	if world.s.health<=0:return "死亡している。"
	var indoor:bool=Navigation.indoor(location)
	if command=="テレビを見る" and not indoor:return "ここにはテレビがない。自宅で操作してください。"
	var channel:String="radio" if command=="ラジオを聞く" else ("sns" if command in ["SNSを見る","スマホでニュースを見る"] or not indoor else "tv")
	if channel=="tv" and not world.has_home_power():channel="sns"
	if channel=="sns" and (float(world.s.sim.communications)<30 or float(world.s.sim.phone_charge)<=0):return "通信またはスマートフォンの電池が利用できず、情報を受信できない。"
	if channel=="radio" and not bool(world.s.radio):return "使用できるラジオがない。"
	world.advance_safe(5)
	if channel=="tv" and not world.has_home_power():return "受信中に電力が途絶え、新しい報道を確認できなかった。"
	if channel=="sns":
		if float(world.s.sim.communications)<30 or float(world.s.sim.phone_charge)<=0:return "受信中に通信が途絶え、新しい情報を確認できなかった。"
		world.s.sim.phone_charge=maxf(0,float(world.s.sim.phone_charge)-0.5)
	var report:=_observe(channel)
	if report!="新しく確認できた出来事はない。":observed_news=report
	elif observed_news=="まだ確認していない":observed_news="新しい報道は確認できない。"
	visual_focus="news"
	return "情報源：%s\n%s%s"%[{"tv":"テレビ","sns":"スマートフォン・SNS","radio":"ラジオ"}[channel],"新しい報道はない。前回確認した内容：\n" if report=="新しく確認できた出来事はない。" and observed_news!="新しい報道は確認できない。" else "",observed_news]
func _inventory_text() -> String:
	var lines:Array[String]=[_status_text(),"\n資材・道具"]
	var labels:Dictionary={"wood":"木材","parts":"部品","seeds":"種","bandage":"包帯","planter":"未使用プランター","harvest":"累積収穫量"}
	for id in labels:lines.append("%s：%s"%[labels[id],str(world.s.inventory[id])])
	lines.append("栽培中：%d鉢"%world.s.plots.size())
	lines.append("\n設備")
	for id in {"solar":"ソーラーパネル","battery":"蓄電池","camera":"カメラ","filter":"浄水器"}:
		lines.append("%s：%s"%[{"solar":"ソーラーパネル","battery":"蓄電池","camera":"カメラ","filter":"浄水器"}[id],"所持" if world.s.equipment[id] else "なし"])
	lines.append("蓄電量：%.0f Wh / 浄水器状態：%.0f / 玄関の鍵：%s"%[float(world.s.battery),float(world.s.longplay.filter_condition),"所持" if world.s.profile.has_key else "なし"])
	return "\n".join(lines)

func _status_text() -> String:
	var values := Vitals.values(world.s)
	var lines: Array[String]=[]
	for key in values:lines.append("%s %.1f/100（%s）"%[key,float(values[key]),Vitals.description(float(values[key]))])
	lines.append("食料 %.1f人日 / 飲料水 %.1fL / 雨水 %.1fL\n現金 %d円 / 銀行 %d円"%[float(world.s.food),float(world.s.water),float(world.s.rain_water),int(world.s.cash),int(world.s.bank)])
	var warning:=Vitals.warning(world.s)
	if not warning.is_empty():lines.append(warning)
	return "\n".join(lines)

func _save() -> String:
	if not world.validate_state(world.s):return "世界データが不正なため保存を中止した。"
	var payload := {"save_version":SAVE_VERSION,"location":location,"world":world.s,"log":log_entries,"known_events":known_events,"observed_news":observed_news,"world_exact":Marshalls.raw_to_base64(var_to_bytes(world.s))}
	var temp := SAVE_PATH + ".tmp"
	var file := FileAccess.open(temp, FileAccess.WRITE)
	if file == null: return "保存できなかった。"
	file.store_string(JSON.stringify(payload, "", true, true))
	file.flush()
	file.close()
	var err := DirAccess.rename_absolute(ProjectSettings.globalize_path(temp), ProjectSettings.globalize_path(SAVE_PATH))
	return "保存した。" if err == OK else "保存ファイルを確定できなかった。"

func _load() -> String:
	if not FileAccess.file_exists(SAVE_PATH): return "保存データが見つからない。"
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if not (parsed is Dictionary): return "保存データが壊れている。"
	var data: Dictionary = parsed
	if not (data.get("save_version") is int or data.get("save_version") is float): return "セーブ形式が不正。"
	if int(data.get("save_version",-1)) != SAVE_VERSION: return "対応していないセーブ形式。"
	if not data.get("world") is Dictionary or not data.get("log") is Array: return "保存データが不正。"
	if not ROOM_LINKS.has(str(data.get("location",""))): return "保存位置が不正。"
	# New saves preserve the exact Variant numeric types and IEEE float values.
	# Decode with objects disabled; old JSON-only v5 saves remain importable.
	if data.has("world_exact"):
		if not data.world_exact is String or data.world_exact.length() > 4000000: return "精密保存データが不正。"
		var exact = bytes_to_var(Marshalls.base64_to_raw(data.world_exact))
		if not exact is Dictionary: return "精密保存データが壊れている。"
		data.world = exact
	if int(data["world"].get("version",-1)) in [15, 16, 17, 18, 19, 20, 21, 22]:
		var migrated: Dictionary = world.migrate_legacy(data["world"])
		if migrated.is_empty(): return "旧セーブの移行に失敗した。"
		data["world"] = migrated
	if not world.validate_state(data["world"]): return "世界データが不正。"
	if data["log"].size() > 100: return "記録データが大きすぎる。"
	var loaded_log: Array[String] = []
	for line in data["log"]:
		if not line is String or line.length() > 16000: return "記録データが不正。"
		for offset in range(0,maxi(1,line.length()),2000):loaded_log.append(line.substr(offset,2000))
	while loaded_log.size()>100:loaded_log.pop_front()
	var loaded_known: Array[String] = []
	if data.has("known_events"):
		if not data["known_events"] is Array or data["known_events"].size() > 240: return "既知イベントの記録が不正。"
		for id in data["known_events"]:
			if not id is String or id.length() > 100: return "既知イベントの記録が不正。"
			loaded_known.append(id)
	if not data.get("observed_news", "まだ確認していない") is String: return "報道記録が不正。"
	world.s = data["world"]
	if not world.s.longplay.has("orders"):
		world.s.longplay.orders = []
	observed_news = str(data.get("observed_news", "まだ確認していない"))
	known_events = loaded_known
	location = str(data["location"])
	visual_focus = ""
	_sync_player_position()
	event_visual = ""
	log_entries = loaded_log.slice(maxi(0, loaded_log.size()-100))
	story.text = "\n\n".join(log_entries)
	call_deferred("_scroll_log_to_end")
	return "保存データを読み込んだ。"

func _utility(key: String) -> void:
	if intro_active or is_instance_valid(title_screen): return
	if advancing: return
	match key:
		"save": _append(_save())
		"load": _append(_load())
		"status": _append(_status_text())
	_refresh()
