#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != Darwin ]]; then
  echo 'The iOS compile stage requires macOS and Xcode.' >&2
  exit 1
fi
mkdir -p build
touch build/.gdignore
SDK_VERSION="$(xcrun --sdk iphoneos --show-sdk-version)"
if [[ "${SDK_VERSION%%.*}" -lt 26 ]]; then
  CHOSEN="$(python3 - <<'PY'
from pathlib import Path
import subprocess,re
candidates=[]
for p in Path('/Applications').glob('Xcode*.app/Contents/Developer'):
    r=subprocess.run(['env','DEVELOPER_DIR='+str(p),'xcrun','--sdk','iphoneos','--show-sdk-version'],capture_output=True,text=True)
    if r.returncode==0:
        v=tuple(map(int,re.findall(r'\d+',r.stdout)))
        if v and v[0]>=26:candidates.append((v,str(p)))
if candidates:print(max(candidates)[1])
PY
)"
  if [[ -z "$CHOSEN" ]]; then echo 'No installed Xcode with iOS 26 SDK or newer.' >&2; exit 1; fi
  export DEVELOPER_DIR="$CHOSEN"
fi
if [[ -n "${DEVELOPER_DIR:-}" && -n "${GITHUB_ENV:-}" ]]; then printf 'DEVELOPER_DIR=%s\n' "$DEVELOPER_DIR" >> "$GITHUB_ENV"; fi
xcodebuild -version | tee build/xcode-version.log
xcrun --sdk iphoneos --show-sdk-version | tee build/sdk-version.log
GODOT_RELEASE=4.6.3-stable
mkdir -p build/tools build/ios build/stage/Payload
TOOLS="$PWD/build/tools"
BASE="https://github.com/godotengine/godot/releases/download/$GODOT_RELEASE"
MAC="Godot_v${GODOT_RELEASE}_macos.universal.zip"
TEMPLATES="Godot_v${GODOT_RELEASE}_export_templates.tpz"
for NAME in "$MAC" "$TEMPLATES" SHA512-SUMS.txt; do
  if [[ ! -f "$TOOLS/$NAME" ]]; then
    curl --fail --location --retry 3 "$BASE/$NAME" -o "$TOOLS/$NAME"
  fi
done
(cd "$TOOLS" && grep -E 'Godot_v4[.]6[.]3-stable_(macos[.]universal[.]zip|export_templates[.]tpz)$' SHA512-SUMS.txt > selected-checksums.txt && test "$(wc -l < selected-checksums.txt | tr -d ' ')" = 2 && shasum -a 512 -c selected-checksums.txt)
unzip -oq "$TOOLS/$MAC" -d "$TOOLS"
GODOT="$TOOLS/Godot.app/Contents/MacOS/Godot"
TEMPLATE_DIR="$HOME/Library/Application Support/Godot/export_templates/4.6.3.stable"
mkdir -p "$TEMPLATE_DIR"
unzip -p "$TOOLS/$TEMPLATES" templates/ios.zip > "$TEMPLATE_DIR/ios.zip"
test -s "$TEMPLATE_DIR/ios.zip"
bash build_scripts/ios_bridge/build.sh 2>&1 | tee build/bridge.log
"$GODOT" --headless --editor --path "$PWD" --import --quit
GODOT="$GODOT" python3 tests/run_all.py "$PWD/build/test-results" 2>&1 | tee build/tests.log
"$GODOT" --headless --path "$PWD" --export-release 'iOS unsigned project' "$PWD/build/ios/DeadCityJapan.zip" 2>&1 | tee build/export.log
grep -rl --include='*.m' --include='*.cpp' --include='*.mm' --include='*.h' 'dcj_apple_plugin_init' build/ios || {
  echo 'The iOS exporter did not include the Apple AI plugin.' >&2
  exit 1
}
# Team ID in export_presets.cfg is an exporter-only placeholder. The compiler
# is explicitly unsigned and receives an empty DEVELOPMENT_TEAM override.
xcodebuild -project build/ios/DeadCityJapan.xcodeproj -scheme DeadCityJapan \
  -configuration Release -destination 'generic/platform=iOS' -sdk iphoneos \
  -derivedDataPath "$PWD/build/DerivedData" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= \
  DEVELOPMENT_TEAM= ARCHS=arm64 ONLY_ACTIVE_ARCH=NO build 2>&1 | tee build/xcodebuild.log
APP="$PWD/build/DerivedData/Build/Products/Release-iphoneos/DeadCityJapan.app"
test -d "$APP"
xcrun otool -L "$APP/DeadCityJapan" > build/native-frameworks.log
grep -q '/FoundationModels.framework/FoundationModels' build/native-frameworks.log
xcrun otool -l "$APP/DeadCityJapan" > build/native-load-commands.log
grep -A6 'cmd LC_LOAD_WEAK_DYLIB' build/native-load-commands.log | grep -q '/FoundationModels.framework/FoundationModels'
mkdir -p "$APP/Frameworks"
xcrun swift-stdlib-tool --copy --platform iphoneos --scan-executable "$APP/DeadCityJapan" \
  --destination "$APP/Frameworks"
rmdir "$APP/Frameworks" 2>/dev/null || true
# Embedded runtime binaries may retain vendor ad-hoc signatures. Remove every
# existing bundle signature so SideStore receives a consistently unsigned IPA.
while IFS= read -r -d '' BINARY; do
  if file "$BINARY" | grep -q 'Mach-O'; then
    if codesign -d "$BINARY" >/dev/null 2>&1; then codesign --remove-signature "$BINARY"; fi
  fi
done < <(find "$APP" -type f -print0)
find "$APP" -type d -name _CodeSignature -prune -exec rm -rf {} +
find "$APP" -name embedded.mobileprovision -delete
xcrun lipo "$APP/DeadCityJapan" -verify_arch arm64
python3 - "$APP" <<'PY'
import plistlib,sys
from pathlib import Path
p=Path(sys.argv[1]);info=plistlib.loads((p/'Info.plist').read_bytes())
assert info['CFBundleSupportedPlatforms']==['iPhoneOS']
assert info['CFBundleIdentifier']=='com.deadcityjapan.prototype'
assert str(info['CFBundleVersion']) == '26'
assert info['CFBundleShortVersionString'] == '0.26.0'
assert any(p.rglob('*.pck')), 'Missing game data'
PY
ditto "$APP" build/stage/Payload/DeadCityJapan.app
OUTPUT="$PWD/build/DeadCityJapan-v26-unsigned.ipa"
(cd build/stage && zip -qry "$OUTPUT" Payload)
unzip -t "$OUTPUT"
shasum -a 256 "$OUTPUT" > build/SHA256SUMS.txt
